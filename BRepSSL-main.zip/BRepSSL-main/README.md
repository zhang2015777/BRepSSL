# BRepSSL

BRepSSL learns B-Rep representations through self-supervised graph pretraining
and transfers the shared backbone to machining-feature recognition. This
repository publishes the core algorithms, data loaders, training engines,
and core regression checks. It does not include raw STEP preprocessing
programs or experimental datasets. Users must prepare preprocessed data that
satisfy the existing loading protocols before training.

## Method and core network

### Geometry encoding

`BRepGeometryEncoder` encodes face attributes and UV grids together with
physical-edge attributes, curve samples, and face-side p-curve information.
Faces are nodes in the BRepGraph representation. Each physical edge produces
two directed messages in the order `2*i=forward, 2*i+1=reverse`; geometry
standardization and message construction remain part of the retained input
path.

### GCD-MPNN and graph message passing

The existing graph message-passing implementation is retained in
`models/layers.py` and `models/iba_dmp.py`. Its code interfaces are `EdgeMPNN`,
`IBADMPBlock`, and `IBADMPStack`. The backbone uses three IBA-DMP blocks with
directed physical-edge messages and continuity/boundary routing. These
implementation names and their registered model attributes are unchanged.

### Graph RD and attention refinement

The graph diffusion component is retained in `models/damped_diffusion.py` as
`DampedHeatDiffusionGraphPropagation`. It propagates latent node features using
directed messages. `AttentionRefinementLayer` in `models/attention_refinement.py`
provides GATv2 attention refinement. The shared backbone combines geometry
encoding, message passing, layer normalization, diffusion, attention, graph
pooling, and local/global features.

### Self-supervised pretraining

`BRepPhysicalMessageMaskedPretrainer` uses centered graph-region structured
masking, masked node-embedding reconstruction, physical-edge embedding
reconstruction, and topology reconstruction. Reconstruction targets come
from the shared geometry encoder under `no_grad`, with no separate teacher
backbone or EMA teacher. The existing mask strategy, losses, and checkpoint
formats are retained.

### Three downstream tasks

`BRepPhysicalMessageQualitySegmentor` provides:

- Semantic segmentation of machining-feature faces.
- Instance segmentation through pairwise face relations.
- Roughing/finishing process classification from normalized roughness and
  tolerance inputs.

Semantic and instance branches retain their separate task adapters and heads.
The process loss does not backpropagate into the graph backbone.

## Core code

| Location | Purpose |
| --- | --- |
| `models/` | Geometry encoder, GCD-MPNN/message passing, Graph RD, attention, masking, reconstruction, and task heads |
| `dataloader/brep_pretrain.py` | Shared graph store, pretraining Dataset, samples, batches, collate, pinning, and device transfer |
| `dataloader/mfinstseg_physical_message.py` | Supervised Dataset and batches |
| `dataloader/mfinstseg_protocol.py` | Supervised-label and quality-statistics loading |
| `dataset/mfinstseg_label_protocol.py` | Existing label validation and class mapping |
| `utils/brep_data_io.py` | Graph JSON and statistics reading |
| `utils/graph_json_stream.py` | Streaming graph-record IO |
| `utils/brep_model_input_view.py` | Label-free model input views |
| `utils/physical_edge_message_adapter.py` | Physical-edge to directed-message conversion |
| `utils/message_edge_standardization.py` | Directed-message geometry standardization |
| `engine/pretrain_brep_mask.py` | Self-supervised pretraining entry point |
| `engine/inst_trainer.py` | Downstream multi-task training entry point |
| `configs/main_experiment_config.py` | Paths, protocols, and formal experiment configuration |
| `dataset/quality_export/` | Retained model, input, training, streaming, and runtime checks |

## Required preprocessed data

The dataset is external to the repository. Prepare this existing layout:

```text
<dataset_root>/
  brep_graph/
    graphs.json
    attr_stat.json
    uv_stat.json
    quality_stat.json
  labels/
    <part_id>.json
  MFInstseg_partition/
    train.txt
    eval.txt
    test.txt
    partition_info.json
```

Pretraining reads graphs, geometry statistics, and partitions without reading
supervised labels. Downstream training also requires labels and quality
statistics. Raw STEP files are not required by these training data loaders.

### Existing graph input format

`graphs.json` is a top-level JSON array of `[part_id, graph_data]` records. For
a part with `N` faces and `E` physical edges, the existing required fields are:

| Field | Shape or content |
| --- | --- |
| `graph` | `num_nodes` and `edges=[src,dst]`, preserving physical-edge order |
| `graph_face_attr` | `[N,16]` |
| `graph_face_grid` | `[N,11,5,5]` |
| `graph_edge_attr` | `[E,16]` |
| `graph_edge_grid` | `[E,16,5]` |
| `graph_edge_face_uv` | `[E,2,5,2]` |
| `graph_edge_face_uv_valid` | Boolean `[E,2,5]` |

Geometry values, face/edge order, directions, and validity masks must satisfy
the existing readers and message conversion logic. Dataset views share one
read-only, on-demand DGL graph store per process.

### Labels, statistics, and partitions

Each label file uses `[[part_id, labels]]`. Required label fields are `seg`,
`inst`, `process_type`, `roughness`, and `tolerance`; their validation and class
mapping are defined by `dataset/mfinstseg_label_protocol.py`. Face mappings
use stringified face indices, and instance labels form an `[N,N]` matrix.

Statistics must carry the existing metadata and dimensions. Attribute and UV
statistics use `brep_graph_attr_stat_v2` and `brep_graph_uv_stat_v1` respectively.
Quality statistics contain `mean_quality` and `std_quality` for the two quality
inputs, with the existing train-valid-machining-face scope. Partition counts,
IDs, split metadata, and training-ID hashes must agree across the provided
files. The formal split protocol remains `train_eval_test_80_10_10_seed42`.

The repository does not generate these artifacts or provide a custom dataset
adapter. Users of another dataset are responsible for preparing it in this
existing format. Training does not replace preprocessing.

## Environment and paths

Core training dependencies include PyTorch with CUDA, DGL, NumPy,
`torch_ema`, `torchmetrics`, and `tqdm`. The formal engines require CUDA and do
not provide a CPU fallback. Use compatible versions for the target GPU; this
repository does not contain a complete pinned environment specification.

The project root is determined from the location of
`configs/main_experiment_config.py`, independently of the terminal working
directory. `BREPSSL_DATA_ROOT` specifies the dataset path relative to that
project root and defaults to `../data3`. Absolute and empty values are rejected.

Linux:

```bash
export BREPSSL_DATA_ROOT=../data3
```

Windows PowerShell:

```powershell
$env:BREPSSL_DATA_ROOT = "..\path\to\data3"
```

Use a relative path appropriate to the local filesystem. Outputs remain
under `outputs/data3_physical_message_5090/` in the project root.

## Training entry points

Run the following commands from the project root after preparing compatible
preprocessed graph data, statistics, labels, and partition files.

Pretrain the shared backbone:

```bash
python -u engine/pretrain_brep_mask.py
```

Fine-tune the three-task model; this example uses the formal 0.1% setting:

```bash
python -u engine/inst_trainer.py --train_percent 0.1 --run_dir outputs/data3_physical_message_5090/finetune/percent_0p1 --pretrained_backbone outputs/data3_physical_message_5090/pretrain/checkpoints/best_backbone.pth
```

The formal training percentages remain `0.1`, `0.5`, `1`, `2`, and `5`; use a
separate run directory for each setting. All other settings remain defined in
`configs/main_experiment_config.py`, including seed 42, 400 pretraining and
400 fine-tuning epochs, batch size 256, mask ratio 0.6, and the original
learning rates, loss weights, and backbone-freeze schedule.

Checkpoint metadata remains strict: `brep_physical_message_backbone_v1`,
`brep_physical_message_pretrainer_v3`, and
`brep_physical_message_finetune_v1`. Model weights, datasets, outputs, logs,
and personal development settings are excluded by `.gitignore`.

## License

See [LICENSE](LICENSE).
