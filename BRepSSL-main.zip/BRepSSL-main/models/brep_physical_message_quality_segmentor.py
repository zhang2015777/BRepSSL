

from pathlib import Path

import dgl
import torch
from torch import nn

from dataloader.mfinstseg_physical_message import (
    BRepSupervisedModelInputBatch,
)
from models.brep_physical_message_backbone import (
    BRepPhysicalMessageBackbone,
)
from models.task_heads import (
    QualityProcessHead,
    TaskResidualAdapter,
)
from models.decoders import InnerProductDecoder
from models.layers import MLP


class BRepPhysicalMessageQualitySegmentor(nn.Module):
    

    def __init__(
        self,
        num_classes=13,
        head_hidden_dim=256,
        quality_hidden_dim=128,
        quality_drop=0.3,
        process_head_depth=3,
        use_task_adapters=True,
        task_adapter_hidden_dim=256,
        task_adapter_depth=2,
        task_adapter_drop=0.3,
        task_adapter_init_scale=0.1,
    ):
        super().__init__()
        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes must be a positive integer")
        if not isinstance(head_hidden_dim, int) or head_hidden_dim <= 0:
            raise ValueError("head_hidden_dim must be a positive integer")
        self.num_classes = num_classes
        self.backbone = BRepPhysicalMessageBackbone()
        feature_dim = 256

        self.semantic_adapter = TaskResidualAdapter(
            feat_dim=feature_dim,
            hidden_dim=task_adapter_hidden_dim,
            depth=task_adapter_depth,
            drop=task_adapter_drop,
            init_scale=task_adapter_init_scale,
            enabled=use_task_adapters,
        )
        self.instance_adapter = TaskResidualAdapter(
            feat_dim=feature_dim,
            hidden_dim=task_adapter_hidden_dim,
            depth=task_adapter_depth,
            drop=task_adapter_drop,
            init_scale=task_adapter_init_scale,
            enabled=use_task_adapters,
        )
        self.seg_head = MLP(
            num_layers=2,
            input_dim=feature_dim,
            hidden_dim=head_hidden_dim,
            output_dim=num_classes,
            norm=nn.LayerNorm,
            act=nn.Mish,
        )
        query_projection = MLP(
            num_layers=2,
            input_dim=feature_dim,
            hidden_dim=head_hidden_dim,
            output_dim=head_hidden_dim,
            norm=nn.LayerNorm,
            last_norm=True,
            act=nn.Mish,
        )
        key_projection = MLP(
            num_layers=2,
            input_dim=feature_dim,
            hidden_dim=head_hidden_dim,
            output_dim=head_hidden_dim,
            norm=nn.LayerNorm,
            last_norm=True,
            act=nn.Mish,
        )
        self.inst_head = InnerProductDecoder(
            query_projection,
            key_projection,
        )
        self.process_head = QualityProcessHead(
            quality_hidden_dim=quality_hidden_dim,
            depth=process_head_depth,
            drop=quality_drop,
        )

    @staticmethod
    def _validate_forward_input(batch):
        if not isinstance(batch, BRepSupervisedModelInputBatch):
            raise TypeError(
                "batch must be a BRepSupervisedModelInputBatch"
            )
        topology = batch.physical_topology_graph
        if not isinstance(topology, dgl.DGLGraph):
            raise TypeError("physical_topology_graph must be a DGLGraph")
        if len(topology.ndata) or len(topology.edata):
            raise ValueError(
                "physical_topology_graph must contain topology only"
            )
        model_input = batch.model_input
        if model_input.physical_num_nodes != topology.num_nodes():
            raise ValueError(
                "model_input and physical topology node counts differ"
            )
        if model_input.physical_num_edges != topology.num_edges():
            raise ValueError(
                "model_input and physical topology edge counts differ"
            )
        quality = batch.quality
        if (
            not isinstance(quality, torch.Tensor)
            or quality.dtype != torch.float32
            or quality.shape != (topology.num_nodes(), 2)
        ):
            raise ValueError(
                "quality must be float32 with shape [physical_nodes,2]"
            )
        if quality.device != topology.device:
            raise ValueError("quality and topology devices differ")
        if model_input.node_attr.device != topology.device:
            raise ValueError("model_input and topology devices differ")
        if not torch.all(torch.isfinite(quality)):
            raise ValueError("quality contains NaN or Inf")
        return topology, model_input, quality

    def forward(self, batch):
        topology, model_input, quality = self._validate_forward_input(batch)
        process_out = self.process_head(quality)
        backbone_out = self.backbone.forward_full(model_input)
        local_global_feat = backbone_out.local_global_feat
        if local_global_feat.shape != (topology.num_nodes(), 256):
            raise ValueError(
                "Backbone local_global_feat must have shape [N,256]"
            )

        semantic_feat = self.semantic_adapter(local_global_feat)
        instance_feat = self.instance_adapter(local_global_feat)
        seg_out = self.seg_head(semantic_feat)
        inst_out, _ = self.inst_head(topology, instance_feat)
        expected_batch = topology.batch_num_nodes().numel()
        max_nodes = (
            int(topology.batch_num_nodes().max().item())
            if expected_batch
            else 0
        )
        if seg_out.shape != (topology.num_nodes(), self.num_classes):
            raise ValueError("Semantic output shape mismatch")
        if inst_out.shape != (expected_batch, max_nodes, max_nodes):
            raise ValueError("Instance output shape mismatch")
        if process_out.shape != (topology.num_nodes(), 2):
            raise ValueError("Process output shape mismatch")
        for name, value in (
            ("seg_out", seg_out),
            ("inst_out", inst_out),
            ("process_out", process_out),
        ):
            if not torch.all(torch.isfinite(value)):
                raise ValueError(f"{name} contains NaN or Inf")
        return seg_out, inst_out, process_out

    def load_pretrained_backbone(self, path, strict=True):
        path = Path(path)
        if not path.is_file():
            raise FileNotFoundError(
                f"Pretrained backbone file does not exist: {path}"
            )
        return self.backbone.load_backbone(path, strict=strict)

    def freeze_backbone(self):
        for parameter in self.backbone.parameters():
            parameter.requires_grad = False
        self.backbone.eval()

    def unfreeze_backbone(self):
        for parameter in self.backbone.parameters():
            parameter.requires_grad = True
        self.backbone.train()

    def backbone_parameters(self):
        return self.backbone.parameters()

    def non_backbone_parameters(self):
        backbone_ids = {
            id(parameter) for parameter in self.backbone.parameters()
        }
        return [
            parameter
            for parameter in self.parameters()
            if id(parameter) not in backbone_ids
        ]

    def count_trainable_parameters(self):
        return sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )

    def count_total_parameters(self):
        return sum(parameter.numel() for parameter in self.parameters())
