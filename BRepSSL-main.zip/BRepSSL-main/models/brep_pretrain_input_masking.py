

from dataclasses import dataclass
import hashlib
import json

import dgl
import torch

from dataloader.brep_pretrain import BRepPretrainModelInputBatch
from models.graph_masking import sample_centered_region_mask
from utils.brep_model_input_view import BRepModelInputView
from utils.physical_edge_message_adapter import PhysicalEdgeMessageView


FACE_ATTR_DIM = 16
FACE_GRID_SHAPE = (11, 5, 5)
EDGE_ATTR_DIM = 16
EDGE_GRID_SHAPE = (16, 5)
EDGE_FACE_UV_SHAPE = (2, 5, 2)
EDGE_FACE_UV_VALID_SHAPE = (2, 5)
EDGE_CANDIDATE_POLICY = "unique_nonself_physical_edges_v1"


@dataclass(frozen=True)
class BRepPretrainMaskPlan:
    node_mask: torch.Tensor
    eligible_physical_edge_mask: torch.Tensor
    physical_edge_mask: torch.Tensor
    message_edge_mask: torch.Tensor
    message_source_side_node_mask: torch.Tensor
    message_destination_side_node_mask: torch.Tensor
    masked_node_indices: torch.Tensor
    eligible_physical_edge_indices: torch.Tensor
    masked_physical_edge_indices: torch.Tensor
    masked_message_edge_indices: torch.Tensor
    kept_message_edge_indices: torch.Tensor
    center_node_indices: torch.Tensor
    positive_edge_src: torch.Tensor
    positive_edge_dst: torch.Tensor
    positive_physical_edge_ids: torch.Tensor
    positive_edge_graph_ids: torch.Tensor
    negative_edge_src: torch.Tensor
    negative_edge_dst: torch.Tensor
    negative_edge_graph_ids: torch.Tensor
    masked_node_graph_ids: torch.Tensor
    masked_physical_edge_graph_ids: torch.Tensor
    physical_batch_num_nodes: torch.Tensor
    physical_batch_num_edges: torch.Tensor
    edge_candidate_policy: str
    batch_signature: str
    num_graphs: int
    num_candidate_nodes: int
    num_candidate_physical_edges: int
    physical_num_edges: int


@dataclass(frozen=True)
class BRepMaskedStudentInput:
    node_attr: torch.Tensor
    node_grid: torch.Tensor
    message_graph: dgl.DGLGraph
    message_edge_attr: torch.Tensor
    message_edge_grid: torch.Tensor
    message_edge_face_uv: torch.Tensor
    message_edge_face_uv_valid: torch.Tensor
    message_to_physical_edge: torch.Tensor
    message_is_reverse: torch.Tensor
    message_is_self_loop: torch.Tensor
    kept_original_message_indices: torch.Tensor
    physical_num_nodes: int
    physical_num_edges: int
    physical_batch_num_nodes: torch.Tensor
    physical_batch_num_edges: torch.Tensor


def _require_tensor(
    name,
    value,
    *,
    shape,
    dtype,
    device,
    finite=False,
):
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor")
    if tuple(value.shape) != tuple(shape):
        raise ValueError(
            f"{name} must have shape {tuple(shape)}, "
            f"got {tuple(value.shape)}"
        )
    if value.dtype != dtype:
        raise TypeError(
            f"{name} must have dtype={dtype}, got {value.dtype}"
        )
    if value.device != device:
        raise ValueError(
            f"{name} device={value.device} does not match batch device={device}"
        )
    if finite and not torch.all(torch.isfinite(value)):
        raise ValueError(f"{name} contains NaN or Inf")
    return value


def _require_sorted_unique_indices(name, value, upper_bound, device):
    _require_tensor(
        name,
        value,
        shape=(value.numel(),) if isinstance(value, torch.Tensor) else (),
        dtype=torch.int64,
        device=device,
    )
    if value.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    if value.numel():
        if torch.any(value < 0) or torch.any(value >= upper_bound):
            raise ValueError(
                f"{name} contains indices outside [0,{upper_bound})"
            )
        if value.numel() > 1 and torch.any(value[1:] <= value[:-1]):
            raise ValueError(f"{name} must be sorted and unique")
    return value


def _require_graph_ids(name, value, length, num_graphs, device):
    _require_tensor(
        name,
        value,
        shape=(length,),
        dtype=torch.int64,
        device=device,
    )
    if value.numel() and (
        torch.any(value < 0) or torch.any(value >= num_graphs)
    ):
        raise ValueError(
            f"{name} contains graph IDs outside [0,{num_graphs})"
        )
    return value


def _batch_assignments(counts, total_count, device, name):
    if not isinstance(counts, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor")
    if counts.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    if counts.device != device:
        raise ValueError(f"{name} must be on {device}")
    if counts.dtype not in (torch.int32, torch.int64):
        raise TypeError(f"{name} must have an integer dtype")
    counts64 = counts.to(dtype=torch.int64)
    if torch.any(counts64 < 0):
        raise ValueError(f"{name} contains negative counts")
    if int(counts64.sum().item()) != total_count:
        raise ValueError(
            f"{name} sums to {int(counts64.sum().item())}, "
            f"expected {total_count}"
        )
    graph_ids = torch.arange(
        counts64.numel(),
        dtype=torch.int64,
        device=device,
    )
    return torch.repeat_interleave(graph_ids, counts64)


def _validate_uv(name, uv, valid):
    invalid_uv = uv[~valid]
    if invalid_uv.numel() and torch.any(invalid_uv != 0):
        raise ValueError(f"{name} must be exactly [0,0] at invalid positions")


def _validate_batch(batch):
    if not isinstance(batch, BRepPretrainModelInputBatch):
        raise TypeError("batch must be a BRepPretrainModelInputBatch")
    topology = batch.physical_topology_graph
    model_input = batch.model_input
    if not isinstance(topology, dgl.DGLGraph):
        raise TypeError("batch.physical_topology_graph must be a DGLGraph")
    if not isinstance(model_input, BRepModelInputView):
        raise TypeError("batch.model_input must be a BRepModelInputView")
    if len(topology.ndata) or len(topology.edata):
        raise ValueError(
            "physical_topology_graph must not contain node or edge data"
        )

    device = topology.device
    node_count = topology.num_nodes()
    physical_edge_count = topology.num_edges()
    physical_batch_num_nodes = topology.batch_num_nodes().to(device)
    physical_batch_num_edges = topology.batch_num_edges().to(device)
    node_graph_ids = _batch_assignments(
        physical_batch_num_nodes,
        node_count,
        device,
        "physical_topology_graph.batch_num_nodes()",
    )
    physical_edge_graph_ids = _batch_assignments(
        physical_batch_num_edges,
        physical_edge_count,
        device,
        "physical_topology_graph.batch_num_edges()",
    )
    num_graphs = int(physical_batch_num_nodes.numel())
    if physical_batch_num_edges.numel() != num_graphs:
        raise ValueError(
            "Physical batch node and edge count metadata lengths differ"
        )
    if len(batch.part_ids) != num_graphs:
        raise ValueError(
            "batch.part_ids length does not match physical batch size"
        )
    if any(
        not isinstance(part_id, str) or not part_id
        for part_id in batch.part_ids
    ):
        raise ValueError("batch.part_ids must contain non-empty strings")
    if len(set(batch.part_ids)) != len(batch.part_ids):
        raise ValueError("batch.part_ids must be unique and ordered")

    if model_input.physical_num_nodes != node_count:
        raise ValueError(
            "model_input physical node count does not match topology graph"
        )
    if model_input.physical_num_edges != physical_edge_count:
        raise ValueError(
            "model_input physical edge count does not match topology graph"
        )
    if not torch.equal(
        model_input.physical_batch_num_nodes.to(device),
        physical_batch_num_nodes,
    ):
        raise ValueError("model_input physical batch node counts mismatch")
    if not torch.equal(
        model_input.physical_batch_num_edges.to(device),
        physical_batch_num_edges,
    ):
        raise ValueError("model_input physical batch edge counts mismatch")

    _require_tensor(
        "model_input.node_attr",
        model_input.node_attr,
        shape=(node_count, FACE_ATTR_DIM),
        dtype=torch.float32,
        device=device,
        finite=True,
    )
    _require_tensor(
        "model_input.node_grid",
        model_input.node_grid,
        shape=(node_count,) + FACE_GRID_SHAPE,
        dtype=torch.float32,
        device=device,
        finite=True,
    )

    message_view = model_input.message_view
    if not isinstance(message_view, PhysicalEdgeMessageView):
        raise TypeError(
            "model_input.message_view must be a PhysicalEdgeMessageView"
        )
    message_graph = message_view.message_graph
    if not isinstance(message_graph, dgl.DGLGraph):
        raise TypeError("message_view.message_graph must be a DGLGraph")
    if message_graph.device != device:
        raise ValueError("Message graph and physical topology devices differ")
    if len(message_graph.ndata) or len(message_graph.edata):
        raise ValueError("Full message graph must be an empty data container")
    message_edge_count = message_graph.num_edges()
    if message_graph.num_nodes() != node_count:
        raise ValueError("Message graph node count does not match topology")
    if message_edge_count != 2 * physical_edge_count:
        raise ValueError(
            "Full message edge count must equal twice the physical edge count"
        )
    if not torch.equal(
        message_graph.batch_num_nodes().to(device),
        physical_batch_num_nodes,
    ):
        raise ValueError("Message graph batch node counts mismatch")
    expected_message_batch_edges = physical_batch_num_edges * 2
    if not torch.equal(
        message_graph.batch_num_edges().to(device),
        expected_message_batch_edges,
    ):
        raise ValueError(
            "Message graph batch edge counts are not twice physical counts"
        )

    _require_tensor(
        "message_edge_attr",
        message_view.message_edge_attr,
        shape=(message_edge_count, EDGE_ATTR_DIM),
        dtype=torch.float32,
        device=device,
        finite=True,
    )
    _require_tensor(
        "message_edge_grid",
        message_view.message_edge_grid,
        shape=(message_edge_count,) + EDGE_GRID_SHAPE,
        dtype=torch.float32,
        device=device,
        finite=True,
    )
    message_uv = _require_tensor(
        "message_edge_face_uv",
        message_view.message_edge_face_uv,
        shape=(message_edge_count,) + EDGE_FACE_UV_SHAPE,
        dtype=torch.float32,
        device=device,
        finite=True,
    )
    message_uv_valid = _require_tensor(
        "message_edge_face_uv_valid",
        message_view.message_edge_face_uv_valid,
        shape=(message_edge_count,) + EDGE_FACE_UV_VALID_SHAPE,
        dtype=torch.bool,
        device=device,
    )
    _validate_uv("message_edge_face_uv", message_uv, message_uv_valid)

    expected_mapping = torch.arange(
        physical_edge_count,
        dtype=torch.int64,
        device=device,
    ).repeat_interleave(2)
    mapping = _require_tensor(
        "message_to_physical_edge",
        message_view.message_to_physical_edge,
        shape=(message_edge_count,),
        dtype=torch.int64,
        device=device,
    )
    if mapping.numel() and (
        torch.any(mapping < 0)
        or torch.any(mapping >= physical_edge_count)
    ):
        raise ValueError("message_to_physical_edge contains invalid IDs")
    if not torch.equal(mapping, expected_mapping):
        raise ValueError(
            "message_to_physical_edge does not follow interleaved 2*i mapping"
        )

    expected_reverse = torch.tensor(
        [False, True],
        dtype=torch.bool,
        device=device,
    ).repeat(physical_edge_count)
    message_is_reverse = _require_tensor(
        "message_is_reverse",
        message_view.message_is_reverse,
        shape=(message_edge_count,),
        dtype=torch.bool,
        device=device,
    )
    if not torch.equal(message_is_reverse, expected_reverse):
        raise ValueError("message_is_reverse does not follow forward/reverse order")
    _require_tensor(
        "message_is_self_loop",
        message_view.message_is_self_loop,
        shape=(message_edge_count,),
        dtype=torch.bool,
        device=device,
    )
    expected_forward = torch.arange(
        physical_edge_count,
        dtype=torch.int64,
        device=device,
    ) * 2
    if not torch.equal(
        message_view.physical_to_forward_message,
        expected_forward,
    ):
        raise ValueError("physical_to_forward_message mapping is invalid")
    if not torch.equal(
        message_view.physical_to_reverse_message,
        expected_forward + 1,
    ):
        raise ValueError("physical_to_reverse_message mapping is invalid")

    physical_src, physical_dst = topology.edges(order="eid")
    message_src, message_dst = message_graph.edges(order="eid")
    if not torch.equal(message_src[0::2], physical_src):
        raise ValueError("Forward message sources do not match physical sources")
    if not torch.equal(message_dst[0::2], physical_dst):
        raise ValueError(
            "Forward message destinations do not match physical destinations"
        )
    if not torch.equal(message_src[1::2], physical_dst):
        raise ValueError("Reverse message sources do not match physical destinations")
    if not torch.equal(message_dst[1::2], physical_src):
        raise ValueError(
            "Reverse message destinations do not match physical sources"
        )
    expected_self_loop = (message_src == message_dst)
    if not torch.equal(
        message_view.message_is_self_loop,
        expected_self_loop,
    ):
        raise ValueError("message_is_self_loop does not match message topology")

    return {
        "device": device,
        "num_graphs": num_graphs,
        "node_count": node_count,
        "physical_edge_count": physical_edge_count,
        "message_edge_count": message_edge_count,
        "physical_batch_num_nodes": physical_batch_num_nodes,
        "physical_batch_num_edges": physical_batch_num_edges,
        "node_graph_ids": node_graph_ids,
        "physical_edge_graph_ids": physical_edge_graph_ids,
        "physical_src": physical_src,
        "physical_dst": physical_dst,
        "message_src": message_src,
        "message_dst": message_dst,
    }


def _eligible_unique_nonself_physical_edges(physical_src, physical_dst):
    edge_count = physical_src.numel()
    device = physical_src.device
    pair_counts = {}
    pairs = []
    for src_value, dst_value in zip(
        physical_src.detach().cpu().tolist(),
        physical_dst.detach().cpu().tolist(),
    ):
        src = int(src_value)
        dst = int(dst_value)
        pair = (min(src, dst), max(src, dst))
        pairs.append(pair)
        pair_counts[pair] = pair_counts.get(pair, 0) + 1
    eligible_values = [
        src != dst and pair_counts[pair] == 1
        for src, dst, pair in zip(
            physical_src.detach().cpu().tolist(),
            physical_dst.detach().cpu().tolist(),
            pairs,
        )
    ]
    if len(eligible_values) != edge_count:
        raise RuntimeError("Eligible physical edge mask length mismatch")
    return torch.tensor(
        eligible_values,
        dtype=torch.bool,
        device=device,
    )


def compute_brep_pretrain_batch_signature(batch):
    
    batch_info = _validate_batch(batch)
    message_view = batch.model_input.message_view
    payload = {
        "part_ids": list(batch.part_ids),
        "physical_batch_num_nodes": (
            batch_info["physical_batch_num_nodes"]
            .detach()
            .cpu()
            .to(torch.int64)
            .tolist()
        ),
        "physical_batch_num_edges": (
            batch_info["physical_batch_num_edges"]
            .detach()
            .cpu()
            .to(torch.int64)
            .tolist()
        ),
        "physical_edge_src": (
            batch_info["physical_src"].detach().cpu().to(torch.int64).tolist()
        ),
        "physical_edge_dst": (
            batch_info["physical_dst"].detach().cpu().to(torch.int64).tolist()
        ),
        "message_to_physical_edge": (
            message_view.message_to_physical_edge
            .detach()
            .cpu()
            .to(torch.int64)
            .tolist()
        ),
        "message_is_reverse": (
            message_view.message_is_reverse.detach().cpu().tolist()
        ),
    }
    serialized = json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(serialized).hexdigest()


def _sorted_mask_info_indices(mask_info, key, upper_bound, device):
    if key not in mask_info:
        raise KeyError(f"Mask sampler result is missing {key!r}")
    value = mask_info[key]
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"mask_info[{key!r}] must be a tensor")
    if value.dtype != torch.int64 or value.ndim != 1:
        raise TypeError(f"mask_info[{key!r}] must be one-dimensional int64")
    if value.device != device:
        raise ValueError(f"mask_info[{key!r}] is on the wrong device")
    if value.numel() and (
        torch.any(value < 0) or torch.any(value >= upper_bound)
    ):
        raise ValueError(f"mask_info[{key!r}] contains out-of-range indices")
    if torch.unique(value).numel() != value.numel():
        raise ValueError(f"mask_info[{key!r}] contains duplicate indices")
    return torch.sort(value).values


def _mask_info_vector(mask_info, key, device):
    if key not in mask_info:
        raise KeyError(f"Mask sampler result is missing {key!r}")
    value = mask_info[key]
    if (
        not isinstance(value, torch.Tensor)
        or value.dtype != torch.int64
        or value.ndim != 1
    ):
        raise TypeError(f"mask_info[{key!r}] must be one-dimensional int64")
    if value.device != device:
        raise ValueError(f"mask_info[{key!r}] is on the wrong device")
    return value.clone()


def sample_brep_pretrain_mask_plan(
    batch,
    *,
    node_mask_ratio,
    edge_mask_ratio,
    negative_edge_ratio,
    generator=None,
    min_mask_nodes=1,
    min_mask_edges=1,
):
    
    batch_info = _validate_batch(batch)
    if generator is not None and not isinstance(generator, torch.Generator):
        raise TypeError("generator must be a torch.Generator or None")
    eligible_physical_edge_mask = (
        _eligible_unique_nonself_physical_edges(
            batch_info["physical_src"],
            batch_info["physical_dst"],
        )
    )
    eligible_physical_edge_indices = torch.nonzero(
        eligible_physical_edge_mask,
        as_tuple=False,
    ).flatten()

    mask_info = sample_centered_region_mask(
        batch.physical_topology_graph,
        node_mask_ratio=node_mask_ratio,
        edge_mask_ratio=edge_mask_ratio,
        negative_edge_ratio=negative_edge_ratio,
        generator=generator,
        min_mask_nodes=min_mask_nodes,
        min_mask_edges=min_mask_edges,
        directed_edges=False,
        eligible_edge_mask=eligible_physical_edge_mask,
    )
    if mask_info.get("directed_edges") is not False:
        raise RuntimeError("Physical mask sampler did not preserve directed_edges=False")
    if mask_info.get("num_graphs") != batch_info["num_graphs"]:
        raise ValueError("Mask sampler num_graphs does not match batch")
    if mask_info.get("num_candidate_nodes") != batch_info["node_count"]:
        raise ValueError("Mask sampler candidate node count does not match batch")
    if (
        mask_info.get("num_candidate_edges")
        != eligible_physical_edge_indices.numel()
    ):
        raise ValueError(
            "Mask sampler candidate edge count does not match eligible "
            "physical edges"
        )
    candidate_edges = _sorted_mask_info_indices(
        mask_info,
        "candidate_edge_indices",
        batch_info["physical_edge_count"],
        batch_info["device"],
    )
    if not torch.equal(candidate_edges, eligible_physical_edge_indices):
        raise ValueError(
            "Mask sampler candidate edge IDs do not match eligibility policy"
        )

    device = batch_info["device"]
    masked_nodes = _sorted_mask_info_indices(
        mask_info,
        "masked_node_indices",
        batch_info["node_count"],
        device,
    )
    masked_physical_edges = _sorted_mask_info_indices(
        mask_info,
        "masked_edge_indices",
        batch_info["physical_edge_count"],
        device,
    )
    node_mask = torch.zeros(
        batch_info["node_count"],
        dtype=torch.bool,
        device=device,
    )
    physical_edge_mask = torch.zeros(
        batch_info["physical_edge_count"],
        dtype=torch.bool,
        device=device,
    )
    node_mask[masked_nodes] = True
    physical_edge_mask[masked_physical_edges] = True
    if masked_physical_edges.numel() and not torch.all(
        eligible_physical_edge_mask[masked_physical_edges]
    ):
        raise RuntimeError("Mask sampler selected an ineligible physical edge")

    message_mapping = batch.model_input.message_view.message_to_physical_edge
    message_edge_mask = physical_edge_mask[message_mapping]
    masked_message_edges = torch.nonzero(
        message_edge_mask,
        as_tuple=False,
    ).flatten()
    kept_message_edges = torch.nonzero(
        ~message_edge_mask,
        as_tuple=False,
    ).flatten()
    if not torch.equal(
        message_edge_mask[0::2],
        physical_edge_mask,
    ) or not torch.equal(
        message_edge_mask[1::2],
        physical_edge_mask,
    ):
        raise RuntimeError(
            "Physical edge masks did not map to both message directions"
        )

    message_src = batch_info["message_src"]
    message_dst = batch_info["message_dst"]
    source_side_node_mask = node_mask[message_src]
    destination_side_node_mask = node_mask[message_dst]

    node_graph_ids = batch_info["node_graph_ids"]
    physical_edge_graph_ids = batch_info["physical_edge_graph_ids"]
    masked_node_graph_ids = node_graph_ids[masked_nodes]
    masked_physical_edge_graph_ids = physical_edge_graph_ids[
        masked_physical_edges
    ]
    positive_src = batch_info["physical_src"][masked_physical_edges]
    positive_dst = batch_info["physical_dst"][masked_physical_edges]

    raw_masked_node_ids = mask_info["masked_node_indices"]
    raw_masked_node_graph_ids = mask_info["masked_node_graph_ids"]
    node_order = torch.argsort(raw_masked_node_ids)
    if not torch.equal(
        raw_masked_node_graph_ids[node_order],
        masked_node_graph_ids,
    ):
        raise ValueError("Mask sampler masked node graph IDs are inconsistent")
    raw_masked_edge_ids = mask_info["masked_edge_indices"]
    raw_masked_edge_graph_ids = mask_info["masked_edge_graph_ids"]
    edge_order = torch.argsort(raw_masked_edge_ids)
    if not torch.equal(
        raw_masked_edge_graph_ids[edge_order],
        masked_physical_edge_graph_ids,
    ):
        raise ValueError("Mask sampler masked edge graph IDs are inconsistent")

    raw_positive_ids = mask_info["positive_edge_ids"]
    positive_order = torch.argsort(raw_positive_ids)
    if not torch.equal(
        raw_positive_ids[positive_order],
        masked_physical_edges,
    ):
        raise ValueError("Positive physical edge IDs do not match masked edges")
    if not torch.equal(
        mask_info["positive_edge_src"][positive_order],
        positive_src,
    ) or not torch.equal(
        mask_info["positive_edge_dst"][positive_order],
        positive_dst,
    ):
        raise ValueError("Positive edge endpoints do not match physical topology")
    positive_graph_ids = masked_physical_edge_graph_ids
    if not torch.equal(
        mask_info["positive_edge_graph_ids"][positive_order],
        positive_graph_ids,
    ):
        raise ValueError("Positive edge graph IDs are inconsistent")

    center_nodes = _sorted_mask_info_indices(
        mask_info,
        "center_node_indices",
        batch_info["node_count"],
        device,
    )
    if center_nodes.numel() != batch_info["num_graphs"]:
        raise ValueError("Mask plan must contain one center node per graph")
    if not torch.equal(
        node_graph_ids[center_nodes],
        torch.arange(
            batch_info["num_graphs"],
            dtype=torch.int64,
            device=device,
        ),
    ):
        raise ValueError("Center nodes do not align with batch graph order")

    negative_src = _mask_info_vector(
        mask_info,
        "negative_edge_src",
        device,
    )
    negative_dst = _mask_info_vector(
        mask_info,
        "negative_edge_dst",
        device,
    )
    negative_graph_ids = _mask_info_vector(
        mask_info,
        "negative_edge_graph_ids",
        device,
    )
    if not (
        negative_src.numel()
        == negative_dst.numel()
        == negative_graph_ids.numel()
    ):
        raise ValueError("Negative edge result lengths do not match")
    if negative_src.numel():
        if (
            torch.any(negative_src < 0)
            or torch.any(negative_src >= batch_info["node_count"])
            or torch.any(negative_dst < 0)
            or torch.any(negative_dst >= batch_info["node_count"])
        ):
            raise ValueError("Negative edge endpoints are out of range")
        if not torch.equal(
            node_graph_ids[negative_src],
            negative_graph_ids,
        ) or not torch.equal(
            node_graph_ids[negative_dst],
            negative_graph_ids,
        ):
            raise ValueError("Negative edge endpoints cross batch graphs")

    return BRepPretrainMaskPlan(
        node_mask=node_mask,
        eligible_physical_edge_mask=eligible_physical_edge_mask,
        physical_edge_mask=physical_edge_mask,
        message_edge_mask=message_edge_mask,
        message_source_side_node_mask=source_side_node_mask,
        message_destination_side_node_mask=destination_side_node_mask,
        masked_node_indices=masked_nodes,
        eligible_physical_edge_indices=eligible_physical_edge_indices,
        masked_physical_edge_indices=masked_physical_edges,
        masked_message_edge_indices=masked_message_edges,
        kept_message_edge_indices=kept_message_edges,
        center_node_indices=center_nodes,
        positive_edge_src=positive_src,
        positive_edge_dst=positive_dst,
        positive_physical_edge_ids=masked_physical_edges.clone(),
        positive_edge_graph_ids=positive_graph_ids,
        negative_edge_src=negative_src,
        negative_edge_dst=negative_dst,
        negative_edge_graph_ids=negative_graph_ids,
        masked_node_graph_ids=masked_node_graph_ids,
        masked_physical_edge_graph_ids=masked_physical_edge_graph_ids,
        physical_batch_num_nodes=batch_info[
            "physical_batch_num_nodes"
        ].clone(),
        physical_batch_num_edges=batch_info[
            "physical_batch_num_edges"
        ].clone(),
        edge_candidate_policy=EDGE_CANDIDATE_POLICY,
        batch_signature=compute_brep_pretrain_batch_signature(batch),
        num_graphs=batch_info["num_graphs"],
        num_candidate_nodes=batch_info["node_count"],
        num_candidate_physical_edges=eligible_physical_edge_indices.numel(),
        physical_num_edges=batch_info["physical_edge_count"],
    )


def _validate_mask_plan(batch, mask_plan):
    batch_info = _validate_batch(batch)
    if not isinstance(mask_plan, BRepPretrainMaskPlan):
        raise TypeError("mask_plan must be a BRepPretrainMaskPlan")
    if mask_plan.edge_candidate_policy != EDGE_CANDIDATE_POLICY:
        raise ValueError(
            "mask_plan edge_candidate_policy does not match the formal policy"
        )
    if (
        not isinstance(mask_plan.batch_signature, str)
        or len(mask_plan.batch_signature) != 64
    ):
        raise ValueError("mask_plan batch_signature must be a SHA-256 hex string")
    current_signature = compute_brep_pretrain_batch_signature(batch)
    if mask_plan.batch_signature != current_signature:
        raise ValueError("mask_plan batch_signature does not match batch")
    device = batch_info["device"]
    node_count = batch_info["node_count"]
    physical_edge_count = batch_info["physical_edge_count"]
    message_edge_count = batch_info["message_edge_count"]
    num_graphs = batch_info["num_graphs"]

    for name, value, length in (
        ("node_mask", mask_plan.node_mask, node_count),
        (
            "eligible_physical_edge_mask",
            mask_plan.eligible_physical_edge_mask,
            physical_edge_count,
        ),
        (
            "physical_edge_mask",
            mask_plan.physical_edge_mask,
            physical_edge_count,
        ),
        (
            "message_edge_mask",
            mask_plan.message_edge_mask,
            message_edge_count,
        ),
        (
            "message_source_side_node_mask",
            mask_plan.message_source_side_node_mask,
            message_edge_count,
        ),
        (
            "message_destination_side_node_mask",
            mask_plan.message_destination_side_node_mask,
            message_edge_count,
        ),
    ):
        _require_tensor(
            name,
            value,
            shape=(length,),
            dtype=torch.bool,
            device=device,
        )

    masked_nodes = _require_sorted_unique_indices(
        "masked_node_indices",
        mask_plan.masked_node_indices,
        node_count,
        device,
    )
    eligible_physical_edges = _require_sorted_unique_indices(
        "eligible_physical_edge_indices",
        mask_plan.eligible_physical_edge_indices,
        physical_edge_count,
        device,
    )
    masked_physical_edges = _require_sorted_unique_indices(
        "masked_physical_edge_indices",
        mask_plan.masked_physical_edge_indices,
        physical_edge_count,
        device,
    )
    masked_messages = _require_sorted_unique_indices(
        "masked_message_edge_indices",
        mask_plan.masked_message_edge_indices,
        message_edge_count,
        device,
    )
    kept_messages = _require_sorted_unique_indices(
        "kept_message_edge_indices",
        mask_plan.kept_message_edge_indices,
        message_edge_count,
        device,
    )
    center_nodes = _require_sorted_unique_indices(
        "center_node_indices",
        mask_plan.center_node_indices,
        node_count,
        device,
    )
    positive_ids = _require_sorted_unique_indices(
        "positive_physical_edge_ids",
        mask_plan.positive_physical_edge_ids,
        physical_edge_count,
        device,
    )
    if center_nodes.numel() != num_graphs:
        raise ValueError("mask_plan must have one center node per graph")

    for name, value, length in (
        (
            "positive_edge_src",
            mask_plan.positive_edge_src,
            positive_ids.numel(),
        ),
        (
            "positive_edge_dst",
            mask_plan.positive_edge_dst,
            positive_ids.numel(),
        ),
        (
            "negative_edge_src",
            mask_plan.negative_edge_src,
            mask_plan.negative_edge_src.numel(),
        ),
        (
            "negative_edge_dst",
            mask_plan.negative_edge_dst,
            mask_plan.negative_edge_src.numel(),
        ),
    ):
        _require_tensor(
            name,
            value,
            shape=(length,),
            dtype=torch.int64,
            device=device,
        )
        if value.numel() and (
            torch.any(value < 0) or torch.any(value >= node_count)
        ):
            raise ValueError(f"{name} contains out-of-range node indices")

    _require_graph_ids(
        "positive_edge_graph_ids",
        mask_plan.positive_edge_graph_ids,
        positive_ids.numel(),
        num_graphs,
        device,
    )
    _require_graph_ids(
        "negative_edge_graph_ids",
        mask_plan.negative_edge_graph_ids,
        mask_plan.negative_edge_src.numel(),
        num_graphs,
        device,
    )
    _require_graph_ids(
        "masked_node_graph_ids",
        mask_plan.masked_node_graph_ids,
        masked_nodes.numel(),
        num_graphs,
        device,
    )
    _require_graph_ids(
        "masked_physical_edge_graph_ids",
        mask_plan.masked_physical_edge_graph_ids,
        masked_physical_edges.numel(),
        num_graphs,
        device,
    )
    _require_tensor(
        "physical_batch_num_nodes",
        mask_plan.physical_batch_num_nodes,
        shape=(num_graphs,),
        dtype=torch.int64,
        device=device,
    )
    _require_tensor(
        "physical_batch_num_edges",
        mask_plan.physical_batch_num_edges,
        shape=(num_graphs,),
        dtype=torch.int64,
        device=device,
    )
    if not torch.equal(
        mask_plan.physical_batch_num_nodes,
        batch_info["physical_batch_num_nodes"].to(torch.int64),
    ) or not torch.equal(
        mask_plan.physical_batch_num_edges,
        batch_info["physical_batch_num_edges"].to(torch.int64),
    ):
        raise ValueError("mask_plan physical batch metadata does not match batch")
    if (
        mask_plan.num_graphs != num_graphs
        or mask_plan.num_candidate_nodes != node_count
        or mask_plan.num_candidate_physical_edges
        != eligible_physical_edges.numel()
        or mask_plan.physical_num_edges != physical_edge_count
    ):
        raise ValueError("mask_plan count metadata does not match batch")

    expected_node_mask = torch.zeros_like(mask_plan.node_mask)
    expected_node_mask[masked_nodes] = True
    expected_eligible_mask = _eligible_unique_nonself_physical_edges(
        batch_info["physical_src"],
        batch_info["physical_dst"],
    )
    expected_physical_mask = torch.zeros_like(mask_plan.physical_edge_mask)
    expected_physical_mask[masked_physical_edges] = True
    mapping = batch.model_input.message_view.message_to_physical_edge
    expected_message_mask = expected_physical_mask[mapping]
    if not torch.equal(mask_plan.node_mask, expected_node_mask):
        raise ValueError("node_mask does not match masked_node_indices")
    if not torch.equal(
        mask_plan.eligible_physical_edge_mask,
        expected_eligible_mask,
    ):
        raise ValueError(
            "eligible_physical_edge_mask does not match physical topology"
        )
    if not torch.equal(
        eligible_physical_edges,
        torch.nonzero(expected_eligible_mask, as_tuple=False).flatten(),
    ):
        raise ValueError(
            "eligible_physical_edge_indices do not match eligibility mask"
        )
    if not torch.equal(
        mask_plan.physical_edge_mask,
        expected_physical_mask,
    ):
        raise ValueError(
            "physical_edge_mask does not match masked physical edge indices"
        )
    if masked_physical_edges.numel() and not torch.all(
        expected_eligible_mask[masked_physical_edges]
    ):
        raise ValueError("masked physical edges must be eligible")
    if not torch.equal(mask_plan.message_edge_mask, expected_message_mask):
        raise ValueError("message_edge_mask does not match physical edge mapping")
    if not torch.equal(
        masked_messages,
        torch.nonzero(expected_message_mask, as_tuple=False).flatten(),
    ):
        raise ValueError("masked_message_edge_indices do not match mask")
    if not torch.equal(
        kept_messages,
        torch.nonzero(~expected_message_mask, as_tuple=False).flatten(),
    ):
        raise ValueError("kept_message_edge_indices do not match mask")

    expected_source_mask = expected_node_mask[batch_info["message_src"]]
    expected_destination_mask = expected_node_mask[
        batch_info["message_dst"]
    ]
    if not torch.equal(
        mask_plan.message_source_side_node_mask,
        expected_source_mask,
    ):
        raise ValueError("Source-side node mask does not match message sources")
    if not torch.equal(
        mask_plan.message_destination_side_node_mask,
        expected_destination_mask,
    ):
        raise ValueError(
            "Destination-side node mask does not match message destinations"
        )

    if not torch.equal(positive_ids, masked_physical_edges):
        raise ValueError("Positive physical IDs must equal masked physical IDs")
    if not torch.equal(
        mask_plan.positive_edge_src,
        batch_info["physical_src"][positive_ids],
    ) or not torch.equal(
        mask_plan.positive_edge_dst,
        batch_info["physical_dst"][positive_ids],
    ):
        raise ValueError("Positive edge endpoints do not match physical topology")
    expected_masked_node_graph_ids = batch_info["node_graph_ids"][
        masked_nodes
    ]
    expected_masked_edge_graph_ids = batch_info[
        "physical_edge_graph_ids"
    ][masked_physical_edges]
    if not torch.equal(
        mask_plan.masked_node_graph_ids,
        expected_masked_node_graph_ids,
    ):
        raise ValueError("masked_node_graph_ids do not match batch")
    if not torch.equal(
        mask_plan.masked_physical_edge_graph_ids,
        expected_masked_edge_graph_ids,
    ):
        raise ValueError("masked_physical_edge_graph_ids do not match batch")
    if not torch.equal(
        mask_plan.positive_edge_graph_ids,
        expected_masked_edge_graph_ids,
    ):
        raise ValueError("positive_edge_graph_ids do not match batch")
    if not torch.equal(
        batch_info["node_graph_ids"][center_nodes],
        torch.arange(num_graphs, dtype=torch.int64, device=device),
    ):
        raise ValueError("Center nodes do not match batch graph order")

    negative_src = mask_plan.negative_edge_src
    negative_dst = mask_plan.negative_edge_dst
    negative_graph_ids = mask_plan.negative_edge_graph_ids
    if negative_src.numel():
        if not torch.equal(
            batch_info["node_graph_ids"][negative_src],
            negative_graph_ids,
        ) or not torch.equal(
            batch_info["node_graph_ids"][negative_dst],
            negative_graph_ids,
        ):
            raise ValueError("Negative edge endpoints cross batch graphs")
        negative_pairs = torch.stack((negative_src, negative_dst), dim=1)
        if torch.unique(negative_pairs, dim=0).shape[0] != negative_pairs.shape[0]:
            raise ValueError("Negative edge pairs contain duplicates")
    return batch_info


def build_masked_brep_student_input(batch, mask_plan):
    
    batch_info = _validate_mask_plan(batch, mask_plan)
    model_input = batch.model_input
    message_view = model_input.message_view

    node_attr = model_input.node_attr.clone()
    node_grid = model_input.node_grid.clone()
    node_attr[mask_plan.node_mask] = 0
    node_grid[mask_plan.node_mask] = 0

    edge_attr = message_view.message_edge_attr.clone()
    edge_grid = message_view.message_edge_grid.clone()
    face_uv = message_view.message_edge_face_uv.clone()
    face_uv_valid = message_view.message_edge_face_uv_valid.clone()

    source_side_mask = mask_plan.message_source_side_node_mask
    destination_side_mask = mask_plan.message_destination_side_node_mask
    edge_grid[source_side_mask, 6:9, :] = 0
    edge_grid[source_side_mask, 14, :] = 0
    face_uv[source_side_mask, 0, :, :] = 0
    face_uv_valid[source_side_mask, 0, :] = False

    edge_grid[destination_side_mask, 9:12, :] = 0
    edge_grid[destination_side_mask, 15, :] = 0
    face_uv[destination_side_mask, 1, :, :] = 0
    face_uv_valid[destination_side_mask, 1, :] = False

    incident_to_masked_node = source_side_mask | destination_side_mask
    edge_attr[incident_to_masked_node, 0:3] = 0
    edge_grid[incident_to_masked_node, 13, :] = 0

    kept = mask_plan.kept_message_edge_indices
    original_message_graph = message_view.message_graph
    message_src, message_dst = original_message_graph.edges(order="eid")
    student_message_graph = dgl.graph(
        (
            message_src.index_select(0, kept),
            message_dst.index_select(0, kept),
        ),
        num_nodes=original_message_graph.num_nodes(),
        idtype=original_message_graph.idtype,
        device=original_message_graph.device,
    )
    masked_per_graph = torch.bincount(
        mask_plan.masked_physical_edge_graph_ids,
        minlength=batch_info["num_graphs"],
    )
    student_batch_num_edges = (
        original_message_graph.batch_num_edges().to(batch_info["device"])
        - 2 * masked_per_graph
    )
    if torch.any(student_batch_num_edges < 0):
        raise RuntimeError("Student message batch edge count became negative")
    if int(student_batch_num_edges.sum().item()) != kept.numel():
        raise RuntimeError(
            "Student message batch edge counts do not sum to kept messages"
        )
    student_message_graph.set_batch_num_nodes(
        original_message_graph.batch_num_nodes().to(batch_info["device"])
    )
    student_message_graph.set_batch_num_edges(student_batch_num_edges)
    if len(student_message_graph.ndata) or len(student_message_graph.edata):
        raise RuntimeError("Student message graph must be an empty data container")

    student_edge_attr = edge_attr.index_select(0, kept)
    student_edge_grid = edge_grid.index_select(0, kept)
    student_face_uv = face_uv.index_select(0, kept)
    student_face_uv_valid = face_uv_valid.index_select(0, kept)
    student_mapping = message_view.message_to_physical_edge.index_select(
        0,
        kept,
    )
    student_is_reverse = message_view.message_is_reverse.index_select(
        0,
        kept,
    )
    student_is_self_loop = message_view.message_is_self_loop.index_select(
        0,
        kept,
    )

    for name, value in (
        ("student node_attr", node_attr),
        ("student node_grid", node_grid),
        ("student message_edge_attr", student_edge_attr),
        ("student message_edge_grid", student_edge_grid),
        ("student message_edge_face_uv", student_face_uv),
    ):
        if not torch.all(torch.isfinite(value)):
            raise ValueError(f"{name} contains NaN or Inf")
    _validate_uv(
        "student message_edge_face_uv",
        student_face_uv,
        student_face_uv_valid,
    )

    return BRepMaskedStudentInput(
        node_attr=node_attr,
        node_grid=node_grid,
        message_graph=student_message_graph,
        message_edge_attr=student_edge_attr,
        message_edge_grid=student_edge_grid,
        message_edge_face_uv=student_face_uv,
        message_edge_face_uv_valid=student_face_uv_valid,
        message_to_physical_edge=student_mapping,
        message_is_reverse=student_is_reverse,
        message_is_self_loop=student_is_self_loop,
        kept_original_message_indices=kept.clone(),
        physical_num_nodes=model_input.physical_num_nodes,
        physical_num_edges=model_input.physical_num_edges,
        physical_batch_num_nodes=model_input.physical_batch_num_nodes.clone(),
        physical_batch_num_edges=model_input.physical_batch_num_edges.clone(),
    )
