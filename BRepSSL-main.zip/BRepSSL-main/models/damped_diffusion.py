






import torch
import torch.nn.functional as F
from torch import nn

import dgl


EDGE_DIRECTION_MODES = (
    "legacy_physical_edges",
    "directed_messages",
)


def _init_raw_bounded(value: float, max_value: float) -> torch.Tensor:
    
    if value <= 0:
        raise ValueError(f"value must be greater than 0, got {value}.")
    if value >= max_value:
        raise ValueError(
            f"value must be smaller than max_value={max_value}, got {value}."
        )
    ratio = torch.tensor(float(value) / float(max_value), dtype=torch.float32)
    return torch.logit(ratio)


class DampedHeatDiffusionGraphPropagation(nn.Module):
    

    def __init__(
        self,
        feat_dim: int = 128,
        edge_dim: int = 128,
        steps: int = 2,
        dt: float = 0.1,
        alpha_init: float = 0.5,
        damping_init: float = 0.1,
        source_init: float = 0.1,
        res_scale_init: float = 0.1,
        edge_hidden_dim: int = 64,
        drop: float = 0.0,
        eps: float = 1e-6,
        edge_direction_mode: str = "legacy_physical_edges",
    ) -> None:
        super().__init__()
        if feat_dim <= 0:
            raise ValueError(f"feat_dim must be positive, got {feat_dim}.")
        if edge_dim <= 0:
            raise ValueError(f"edge_dim must be positive, got {edge_dim}.")
        if steps < 0:
            raise ValueError(f"steps must be non-negative, got {steps}.")
        if dt <= 0:
            raise ValueError(f"dt must be positive, got {dt}.")
        if edge_hidden_dim <= 0:
            raise ValueError(
                f"edge_hidden_dim must be positive, got {edge_hidden_dim}."
            )
        if drop < 0 or drop >= 1:
            raise ValueError(f"drop must be in [0, 1), got {drop}.")
        if eps <= 0:
            raise ValueError(f"eps must be positive, got {eps}.")
        if edge_direction_mode not in EDGE_DIRECTION_MODES:
            raise ValueError(
                f"edge_direction_mode must be one of {EDGE_DIRECTION_MODES}, "
                f"got {edge_direction_mode!r}."
            )

        self.feat_dim = int(feat_dim)
        self.edge_dim = int(edge_dim)
        self.steps = int(steps)
        self.dt = float(dt)
        self.edge_hidden_dim = int(edge_hidden_dim)
        self.drop = float(drop)
        self.eps = float(eps)
        self.edge_direction_mode = edge_direction_mode

        self.alpha_max = 1.0
        self.damping_max = 1.0
        self.source_max = 1.0
        self.res_scale_max = 1.0

        self.raw_alpha = nn.Parameter(
            _init_raw_bounded(alpha_init, self.alpha_max)
        )
        self.raw_damping = nn.Parameter(
            _init_raw_bounded(damping_init, self.damping_max)
        )
        self.raw_source = nn.Parameter(
            _init_raw_bounded(source_init, self.source_max)
        )
        self.raw_res_scale = nn.Parameter(
            _init_raw_bounded(res_scale_init, self.res_scale_max)
        )

        self.edge_score = nn.Sequential(
            nn.LayerNorm(self.edge_dim),
            nn.Linear(self.edge_dim, self.edge_hidden_dim),
            nn.Mish(),
            nn.Dropout(self.drop),
            nn.Linear(self.edge_hidden_dim, 1),
        )

    @property
    def alpha(self) -> torch.Tensor:
        return self.alpha_max * torch.sigmoid(self.raw_alpha)

    @property
    def damping(self) -> torch.Tensor:
        return self.damping_max * torch.sigmoid(self.raw_damping)

    @property
    def source_strength(self) -> torch.Tensor:
        return self.source_max * torch.sigmoid(self.raw_source)

    @property
    def res_scale(self) -> torch.Tensor:
        return self.res_scale_max * torch.sigmoid(self.raw_res_scale)

    def _check_inputs(
        self,
        graph: dgl.DGLGraph,
        h: torch.Tensor,
        edge_feat: torch.Tensor,
    ) -> None:
        if not torch.is_tensor(h) or h.dim() != 2:
            actual = tuple(h.shape) if torch.is_tensor(h) else type(h).__name__
            raise ValueError(
                f"Expected h to be a 2D Tensor [N, {self.feat_dim}], got {actual}."
            )
        if not torch.is_tensor(edge_feat) or edge_feat.dim() != 2:
            actual = (
                tuple(edge_feat.shape)
                if torch.is_tensor(edge_feat)
                else type(edge_feat).__name__
            )
            raise ValueError(
                "Expected edge_feat to be a 2D Tensor "
                f"[E, {self.edge_dim}], got {actual}."
            )
        if h.size(1) != self.feat_dim:
            raise ValueError(
                f"Expected h shape [N, {self.feat_dim}], got {tuple(h.shape)}."
            )
        if edge_feat.size(1) != self.edge_dim:
            raise ValueError(
                "Expected edge_feat shape "
                f"[E, {self.edge_dim}], got {tuple(edge_feat.shape)}."
            )
        if edge_feat.size(0) != graph.num_edges():
            raise ValueError(
                "edge_feat edge count does not match graph.num_edges(): "
                f"edge_feat shape={tuple(edge_feat.shape)}, "
                f"graph.num_edges()={graph.num_edges()}."
            )
        if graph.num_nodes() != h.size(0):
            raise ValueError(
                "h node count does not match graph.num_nodes(): "
                f"h shape={tuple(h.shape)}, "
                f"graph.num_nodes()={graph.num_nodes()}."
            )
        if edge_feat.device != h.device:
            raise ValueError(
                "h and edge_feat must be on the same device, got "
                f"h.device={h.device}, edge_feat.device={edge_feat.device}."
            )

    def _compute_diffusion(
        self,
        h: torch.Tensor,
        bi_src: torch.Tensor,
        bi_dst: torch.Tensor,
        edge_weight: torch.Tensor,
    ) -> torch.Tensor:
        src_feat = h.index_select(0, bi_src)
        dst_feat = h.index_select(0, bi_dst)
        messages = edge_weight * (src_feat - dst_feat)
        diffusion = torch.zeros_like(h)
        diffusion.index_add_(0, bi_dst, messages)
        return diffusion

    def forward(
        self,
        graph: dgl.DGLGraph,
        h: torch.Tensor,
        edge_feat: torch.Tensor,
    ) -> torch.Tensor:
        self._check_inputs(graph, h, edge_feat)
        if graph.num_nodes() == 0:
            return h

        h0 = h
        u = h
        propagation_src = None
        propagation_dst = None
        edge_weight = None

        if graph.num_edges() > 0:
            src, dst = graph.edges(order="eid")
            src = src.to(device=h.device)
            dst = dst.to(device=h.device)
            if self.edge_direction_mode == "legacy_physical_edges":
                propagation_src = torch.cat([src, dst], dim=0)
                propagation_dst = torch.cat([dst, src], dim=0)
                propagation_edge_feat = torch.cat(
                    [edge_feat, edge_feat],
                    dim=0,
                )
            else:
                propagation_src = src
                propagation_dst = dst
                propagation_edge_feat = edge_feat

            score = self.edge_score(propagation_edge_feat)
            positive_score = F.softplus(score) + self.eps
            denominator = positive_score.new_zeros((graph.num_nodes(), 1))
            denominator.index_add_(0, propagation_dst, positive_score)
            edge_weight = positive_score / (
                denominator.index_select(0, propagation_dst) + self.eps
            )

        alpha = self.alpha
        damping = self.damping
        source = self.source_strength
        res_scale = self.res_scale

        for _ in range(self.steps):
            if edge_weight is None:
                diffusion = torch.zeros_like(u)
            else:
                diffusion = self._compute_diffusion(
                    u,
                    propagation_src,
                    propagation_dst,
                    edge_weight,
                )
            u = u + self.dt * (
                alpha * diffusion - damping * u + source * h0
            )

        return h0 + res_scale * (u - h0)

    def extra_repr(self) -> str:
        return (
            f"feat_dim={self.feat_dim}, edge_dim={self.edge_dim}, "
            f"steps={self.steps}, dt={self.dt}, "
            f"edge_hidden_dim={self.edge_hidden_dim}, drop={self.drop}, "
            f"edge_direction_mode={self.edge_direction_mode!r}"
        )
