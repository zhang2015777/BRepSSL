

from dataclasses import dataclass
from pathlib import Path
from collections.abc import Mapping

import dgl
import torch
from torch import nn

from models.brep_geometry_encoder import (
    BRepGeometryEncoder,
    BRepGeometryEncoding,
)
from models.brep_pretrain_input_masking import BRepMaskedStudentInput
from models.attention_refinement import AttentionRefinementLayer
from models.damped_diffusion import DampedHeatDiffusionGraphPropagation
from models.iba_dmp import IBADMPStack
from utils.brep_model_input_view import BRepModelInputView


FEATURE_DIM = 128
BACKBONE_CHECKPOINT_FORMAT = "brep_physical_message_backbone_v1"
BACKBONE_ARCHITECTURE = "BRepPhysicalMessageBackbone"
INPUT_PROTOCOL = "physical_message_v1"
FEATURE_PROTOCOL = {
    "face_attr_dim": 16,
    "face_grid_channels": 11,
    "edge_attr_dim": 16,
    "edge_grid_channels": 16,
    "edge_face_uv_shape": [2, 5, 2],
    "edge_face_uv_valid_shape": [2, 5],
}
MESSAGE_PROTOCOL = {
    "physical_edge_records": 1,
    "directed_messages_per_physical_edge": 2,
    "message_order": "2*i=forward,2*i+1=reverse",
}
BACKBONE_ORDER = [
    "BRepGeometryEncoder",
    "IBADMPStackx3",
    "PostLayerNorm",
    "DirectedDHDGP",
    "GATv2ARL",
    "AvgPooling",
]


@dataclass(frozen=True)
class BRepPhysicalMessageBackboneOutput:
    node_emb: torch.Tensor
    graph_emb: torch.Tensor
    local_global_feat: torch.Tensor
    message_edge_emb: torch.Tensor
    route_gate: torch.Tensor


class BRepPhysicalMessageBackbone(nn.Module):
    

    def __init__(self):
        super().__init__()
        self.geometry_encoder = BRepGeometryEncoder()
        self.iba_dmp = IBADMPStack(num_layers=3, drop=0.3)
        self.post_norm = nn.LayerNorm(128)
        self.damped_diffusion = DampedHeatDiffusionGraphPropagation(
            feat_dim=128,
            edge_dim=128,
            drop=0.3,
            edge_direction_mode="directed_messages",
        )
        self.attention_refiner = AttentionRefinementLayer(
            feat_dim=128,
            num_heads=8,
            drop=0.3,
            attn_drop=0.3,
        )
        self.pool = dgl.nn.AvgPooling()
        self.global_projection = nn.Sequential(
            nn.Linear(128, 128),
            nn.LayerNorm(128),
            nn.Mish(),
        )

    @staticmethod
    def checkpoint_metadata():
        return {
            "checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
            "architecture": BACKBONE_ARCHITECTURE,
            "input_protocol": INPUT_PROTOCOL,
            "feature_protocol": dict(FEATURE_PROTOCOL),
            "message_protocol": dict(MESSAGE_PROTOCOL),
            "backbone_order": list(BACKBONE_ORDER),
        }

    @classmethod
    def _validate_checkpoint_payload(cls, payload):
        if not isinstance(payload, Mapping):
            raise TypeError("Backbone checkpoint must be a mapping")
        required = {
            "checkpoint_format",
            "architecture",
            "input_protocol",
            "feature_protocol",
            "message_protocol",
            "backbone_order",
            "state_dict",
        }
        missing = sorted(required.difference(payload))
        if missing:
            raise ValueError(
                "Not a B-Rep physical-message backbone checkpoint; missing "
                f"fields: {missing}"
            )
        expected = cls.checkpoint_metadata()
        for key in (
            "checkpoint_format",
            "architecture",
            "input_protocol",
            "feature_protocol",
            "message_protocol",
            "backbone_order",
        ):
            if payload[key] != expected[key]:
                raise ValueError(
                    f"Backbone checkpoint {key} does not match the formal "
                    "physical-message protocol"
                )
        if not isinstance(payload["state_dict"], Mapping):
            raise TypeError("Backbone checkpoint state_dict must be a mapping")

    def save_backbone(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = self.checkpoint_metadata()
        payload["state_dict"] = self.state_dict()
        torch.save(payload, path)

    def load_backbone(self, path, strict=True):
        path = Path(path)
        if not path.is_file():
            raise FileNotFoundError(f"Backbone checkpoint not found: {path}")
        payload = torch.load(
            path,
            map_location=self.post_norm.weight.device,
        )
        self._validate_checkpoint_payload(payload)
        return self.load_state_dict(payload["state_dict"], strict=strict)

    def encode_full_geometry(self, model_input):
        if not isinstance(model_input, BRepModelInputView):
            raise TypeError("model_input must be a BRepModelInputView")
        return self.geometry_encoder.encode_full(model_input)

    def forward_full(self, model_input):
        geometry = self.encode_full_geometry(model_input)
        return self.forward_encoded(
            model_input.message_view.message_graph,
            geometry,
        )

    def forward_student(self, student_input, node_mask):
        if not isinstance(student_input, BRepMaskedStudentInput):
            raise TypeError("student_input must be a BRepMaskedStudentInput")
        geometry = self.geometry_encoder.encode_student(
            student_input,
            node_mask,
        )
        return self.forward_encoded(
            student_input.message_graph,
            geometry,
        )

    def _validate_encoded_inputs(self, message_graph, geometry_encoding):
        if not isinstance(message_graph, dgl.DGLGraph):
            raise TypeError("message_graph must be a dgl.DGLGraph")
        if len(message_graph.ndata) or len(message_graph.edata):
            raise ValueError("message_graph must be an empty data container")
        if not isinstance(geometry_encoding, BRepGeometryEncoding):
            raise TypeError(
                "geometry_encoding must be a BRepGeometryEncoding"
            )
        node_feat = geometry_encoding.node_feat
        edge_feat = geometry_encoding.message_edge_feat
        if node_feat.shape != (message_graph.num_nodes(), FEATURE_DIM):
            raise ValueError(
                "geometry node_feat must have shape "
                f"[{message_graph.num_nodes()},128]"
            )
        if edge_feat.shape != (message_graph.num_edges(), FEATURE_DIM):
            raise ValueError(
                "geometry message_edge_feat must have shape "
                f"[{message_graph.num_edges()},128]"
            )
        if node_feat.dtype != torch.float32:
            raise TypeError("geometry node_feat must have dtype=torch.float32")
        if edge_feat.dtype != torch.float32:
            raise TypeError(
                "geometry message_edge_feat must have dtype=torch.float32"
            )
        if node_feat.device != message_graph.device:
            raise ValueError("geometry node_feat device does not match graph")
        if edge_feat.device != message_graph.device:
            raise ValueError(
                "geometry message_edge_feat device does not match graph"
            )
        if self.post_norm.weight.device != message_graph.device:
            raise ValueError("Backbone parameters and message graph devices differ")
        if not torch.all(torch.isfinite(node_feat)):
            raise ValueError("geometry node_feat contains NaN or Inf")
        if not torch.all(torch.isfinite(edge_feat)):
            raise ValueError("geometry message_edge_feat contains NaN or Inf")

        batch_num_nodes = message_graph.batch_num_nodes().to(
            message_graph.device
        )
        batch_num_edges = message_graph.batch_num_edges().to(
            message_graph.device
        )
        if int(batch_num_nodes.sum().item()) != message_graph.num_nodes():
            raise ValueError("batch_num_nodes does not sum to graph nodes")
        if int(batch_num_edges.sum().item()) != message_graph.num_edges():
            raise ValueError("batch_num_edges does not sum to graph edges")
        if batch_num_nodes.numel() != batch_num_edges.numel():
            raise ValueError("Batch node and edge metadata lengths differ")
        return node_feat, edge_feat, batch_num_nodes

    def forward_encoded(self, message_graph, geometry_encoding):
        node_feat, edge_feat, batch_num_nodes = (
            self._validate_encoded_inputs(
                message_graph,
                geometry_encoding,
            )
        )
        iba_output = self.iba_dmp(
            message_graph,
            node_feat,
            edge_feat,
        )
        base_local = self.post_norm(iba_output.node_feat)
        diffused = self.damped_diffusion(
            message_graph,
            base_local,
            iba_output.message_edge_feat,
        )
        local_feat = self.attention_refiner(
            message_graph,
            diffused,
        )
        graph_feat = self.global_projection(
            self.pool(message_graph, local_feat)
        )
        graph_feat_per_node = graph_feat.repeat_interleave(
            batch_num_nodes.to(torch.int64),
            dim=0,
        )
        local_global_feat = torch.cat(
            (local_feat, graph_feat_per_node),
            dim=1,
        )
        route_gate = iba_output.route_gate
        if route_gate.shape != (message_graph.num_edges(), 1):
            raise ValueError("IBA-DMP route gate shape mismatch")
        if not torch.all(torch.isfinite(route_gate)):
            raise ValueError("IBA-DMP route gate contains NaN or Inf")
        if route_gate.numel() and (
            torch.any(route_gate < 0) or torch.any(route_gate > 1)
        ):
            raise ValueError("IBA-DMP route gate is outside [0,1]")
        expected_shapes = (
            ("node_emb", local_feat, (message_graph.num_nodes(), 128)),
            (
                "graph_emb",
                graph_feat,
                (batch_num_nodes.numel(), 128),
            ),
            (
                "local_global_feat",
                local_global_feat,
                (message_graph.num_nodes(), 256),
            ),
            (
                "message_edge_emb",
                iba_output.message_edge_feat,
                (message_graph.num_edges(), 128),
            ),
        )
        for name, value, shape in expected_shapes:
            if value.shape != shape:
                raise ValueError(
                    f"{name} must have shape {shape}, got {tuple(value.shape)}"
                )
            if not torch.all(torch.isfinite(value)):
                raise ValueError(f"{name} contains NaN or Inf")
        return BRepPhysicalMessageBackboneOutput(
            node_emb=local_feat,
            graph_emb=graph_feat,
            local_global_feat=local_global_feat,
            message_edge_emb=iba_output.message_edge_feat,
            route_gate=route_gate,
        )
