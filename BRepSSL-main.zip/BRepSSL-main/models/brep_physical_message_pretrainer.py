

from __future__ import annotations

from typing import Any

import torch
from torch import nn
import torch.nn.functional as F

from dataloader.brep_pretrain import BRepPretrainModelInputBatch
from models.brep_physical_message_backbone import (
    BRepPhysicalMessageBackbone,
)
from models.brep_pretrain_input_masking import (
    BRepPretrainMaskPlan,
    build_masked_brep_student_input,
    sample_brep_pretrain_mask_plan,
)


PRETRAINER_CHECKPOINT_FORMAT = "brep_physical_message_pretrainer_v3"
PRETRAIN_METHOD = (
    "physical_message_structured_mask_embedding_reconstruction_v1"
)
INPUT_PROTOCOL = "physical_message_v1"
MASK_POLICY = "centered_graph_region_node_edge_mask"


def _decoder(in_dim: int, hidden_dim: int, out_dim: int, drop: float):
    return nn.Sequential(
        nn.Linear(in_dim, hidden_dim),
        nn.LayerNorm(hidden_dim),
        nn.Mish(),
        nn.Dropout(drop),
        nn.Linear(hidden_dim, out_dim),
    )


def _differentiable_zero(reference: torch.Tensor):
    return reference.sum() * 0.0


class BRepPhysicalMessageMaskedPretrainer(nn.Module):
    

    def __init__(
        self,
        *,
        node_mask_ratio: float = 0.6,
        edge_mask_ratio: float = 0.6,
        negative_edge_ratio: float = 1.0,
        min_mask_nodes: int = 1,
        min_mask_edges: int = 1,
        node_loss_weight: float = 1.0,
        edge_loss_weight: float = 1.0,
        topology_loss_weight: float = 0.5,
        decoder_drop: float = 0.3,
        smooth_l1_beta: float = 1.0,
    ):
        super().__init__()
        for name, value in (
            ("node_mask_ratio", node_mask_ratio),
            ("edge_mask_ratio", edge_mask_ratio),
        ):
            if not 0.0 <= float(value) <= 1.0:
                raise ValueError(f"{name} must be in [0,1]")
        if float(negative_edge_ratio) < 0:
            raise ValueError("negative_edge_ratio must be non-negative")
        if min_mask_nodes < 0 or min_mask_edges < 0:
            raise ValueError("minimum mask counts must be non-negative")
        for name, value in (
            ("node_loss_weight", node_loss_weight),
            ("edge_loss_weight", edge_loss_weight),
            ("topology_loss_weight", topology_loss_weight),
        ):
            if float(value) < 0:
                raise ValueError(f"{name} must be non-negative")
        if float(smooth_l1_beta) <= 0:
            raise ValueError("smooth_l1_beta must be positive")

        self.node_mask_ratio = float(node_mask_ratio)
        self.edge_mask_ratio = float(edge_mask_ratio)
        self.negative_edge_ratio = float(negative_edge_ratio)
        self.min_mask_nodes = int(min_mask_nodes)
        self.min_mask_edges = int(min_mask_edges)
        self.node_loss_weight = float(node_loss_weight)
        self.edge_loss_weight = float(edge_loss_weight)
        self.topology_loss_weight = float(topology_loss_weight)
        self.embedding_smooth_l1_beta = float(smooth_l1_beta)

        self.backbone = BRepPhysicalMessageBackbone()
        self.node_embedding_decoder = _decoder(
            256,
            256,
            128,
            decoder_drop,
        )

        self.masked_edge_query = nn.Parameter(torch.empty(1, 128))
        nn.init.trunc_normal_(self.masked_edge_query, std=0.02)
        self.edge_relation_trunk = nn.Sequential(
            nn.Linear(768, 512),
            nn.LayerNorm(512),
            nn.Mish(),
            nn.Dropout(decoder_drop),
            nn.Linear(512, 256),
            nn.LayerNorm(256),
            nn.Mish(),
        )
        self.edge_embedding_decoder = nn.Linear(256, 128)
        self.topology_decoder = nn.Sequential(
            nn.Linear(640, 256),
            nn.LayerNorm(256),
            nn.Mish(),
            nn.Dropout(decoder_drop),
            nn.Linear(256, 1),
        )

    def _sample_plan(self, batch, generator):
        return sample_brep_pretrain_mask_plan(
            batch,
            node_mask_ratio=self.node_mask_ratio,
            edge_mask_ratio=self.edge_mask_ratio,
            negative_edge_ratio=self.negative_edge_ratio,
            generator=generator,
            min_mask_nodes=self.min_mask_nodes,
            min_mask_edges=self.min_mask_edges,
        )

    def _decode_edge_embeddings(self, backbone_out, mask_plan):
        src = mask_plan.positive_edge_src
        dst = mask_plan.positive_edge_dst
        h_src = backbone_out.node_emb[src]
        h_dst = backbone_out.node_emb[dst]
        graph_feat = backbone_out.graph_emb[
            mask_plan.positive_edge_graph_ids
        ]
        query = self.masked_edge_query.expand(src.numel(), -1)
        relation_input = torch.cat(
            (
                h_src,
                h_dst,
                h_src * h_dst,
                torch.abs(h_src - h_dst),
                graph_feat,
                query,
            ),
            dim=1,
        )
        relation = self.edge_relation_trunk(relation_input)
        return self.edge_embedding_decoder(relation)

    def _decode_topology(self, backbone_out, mask_plan):
        src = torch.cat(
            (mask_plan.positive_edge_src, mask_plan.negative_edge_src)
        )
        dst = torch.cat(
            (mask_plan.positive_edge_dst, mask_plan.negative_edge_dst)
        )
        graph_ids = torch.cat(
            (
                mask_plan.positive_edge_graph_ids,
                mask_plan.negative_edge_graph_ids,
            )
        )
        h_src = backbone_out.node_emb[src]
        h_dst = backbone_out.node_emb[dst]
        pair = torch.cat(
            (
                h_src,
                h_dst,
                h_src * h_dst,
                torch.abs(h_src - h_dst),
                backbone_out.graph_emb[graph_ids],
            ),
            dim=1,
        )
        logits = self.topology_decoder(pair).flatten()
        labels = torch.cat(
            (
                torch.ones(
                    mask_plan.positive_edge_src.numel(),
                    device=logits.device,
                    dtype=logits.dtype,
                ),
                torch.zeros(
                    mask_plan.negative_edge_src.numel(),
                    device=logits.device,
                    dtype=logits.dtype,
                ),
            )
        )
        return logits, labels

    @staticmethod
    def _route_statistics(route_gate, reference):
        if route_gate.numel() == 0:
            zero = _differentiable_zero(reference).detach()
            return {
                "route_gate_mean": zero,
                "route_gate_std": zero,
                "route_gate_min": zero,
                "route_gate_max": zero,
                "route_gate_fraction_below_0_1": zero,
                "route_gate_fraction_above_0_9": zero,
            }
        values = route_gate.detach()
        return {
            "route_gate_mean": values.mean(),
            "route_gate_std": values.std(unbiased=False),
            "route_gate_min": values.min(),
            "route_gate_max": values.max(),
            "route_gate_fraction_below_0_1": (
                values < 0.1
            ).to(values.dtype).mean(),
            "route_gate_fraction_above_0_9": (
                values > 0.9
            ).to(values.dtype).mean(),
        }

    def forward(
        self,
        batch,
        *,
        mask_plan=None,
        generator=None,
        return_predictions=False,
    ):
        if not isinstance(batch, BRepPretrainModelInputBatch):
            raise TypeError("batch must be a BRepPretrainModelInputBatch")
        if mask_plan is not None and generator is not None:
            raise ValueError("mask_plan and generator cannot both be supplied")
        if mask_plan is not None and not isinstance(
            mask_plan, BRepPretrainMaskPlan
        ):
            raise TypeError("mask_plan must be a BRepPretrainMaskPlan")
        if mask_plan is None:
            mask_plan = self._sample_plan(batch, generator)

        with torch.no_grad():
            full_geometry_target = self.backbone.encode_full_geometry(
                batch.model_input
            )

        student_input = build_masked_brep_student_input(batch, mask_plan)
        backbone_out = self.backbone.forward_student(
            student_input,
            mask_plan.node_mask,
        )
        zero = _differentiable_zero(backbone_out.node_emb)

        node_ids = mask_plan.masked_node_indices
        target_node_embedding = full_geometry_target.node_feat[
            node_ids
        ].detach()
        pred_node_embedding = self.node_embedding_decoder(
            backbone_out.local_global_feat[node_ids]
        )
        if node_ids.numel():
            loss_node_embedding = F.smooth_l1_loss(
                pred_node_embedding,
                target_node_embedding,
                beta=self.embedding_smooth_l1_beta,
            )
        else:
            loss_node_embedding = zero

        physical_ids = mask_plan.masked_physical_edge_indices
        forward_message_ids = (
            batch.model_input.message_view.physical_to_forward_message[
                physical_ids
            ]
        )
        if not torch.equal(forward_message_ids, 2 * physical_ids):
            raise ValueError(
                "Canonical physical-edge targets must use message 2*i"
            )
        target_edge_embedding = (
            full_geometry_target.message_edge_feat[
                forward_message_ids
            ].detach()
        )
        pred_edge_embedding = self._decode_edge_embeddings(
            backbone_out,
            mask_plan,
        )
        if physical_ids.numel():
            loss_edge_embedding = F.smooth_l1_loss(
                pred_edge_embedding,
                target_edge_embedding,
                beta=self.embedding_smooth_l1_beta,
            )
        else:
            loss_edge_embedding = zero

        topology_logits, topology_labels = self._decode_topology(
            backbone_out,
            mask_plan,
        )
        if topology_logits.numel():
            loss_topology = F.binary_cross_entropy_with_logits(
                topology_logits,
                topology_labels,
            )
        else:
            loss_topology = zero

        loss_total = zero
        if node_ids.numel():
            loss_total = (
                loss_total
                + self.node_loss_weight * loss_node_embedding
            )
        if physical_ids.numel():
            loss_total = (
                loss_total
                + self.edge_loss_weight * loss_edge_embedding
            )
        if topology_logits.numel():
            loss_total = (
                loss_total
                + self.topology_loss_weight * loss_topology
            )

        device = backbone_out.node_emb.device
        float_dtype = backbone_out.node_emb.dtype

        def count(value):
            return torch.tensor(
                int(value),
                dtype=torch.int64,
                device=device,
            )

        output: dict[str, Any] = {
            "loss": loss_total,
            "loss_total": loss_total,
            "loss_node_embedding": loss_node_embedding,
            "loss_edge_embedding": loss_edge_embedding,
            "loss_node": loss_node_embedding,
            "loss_edge": loss_edge_embedding,
            "loss_topology": loss_topology,
            "num_mask_nodes": count(node_ids.numel()),
            "num_mask_physical_edges": count(physical_ids.numel()),
            "num_mask_message_edges": count(
                mask_plan.masked_message_edge_indices.numel()
            ),
            "num_candidate_nodes": count(mask_plan.num_candidate_nodes),
            "num_candidate_physical_edges": count(
                mask_plan.num_candidate_physical_edges
            ),
            "num_topology_pos": count(
                mask_plan.positive_edge_src.numel()
            ),
            "num_topology_neg": count(
                mask_plan.negative_edge_src.numel()
            ),
            "num_graphs": count(mask_plan.num_graphs),
            "node_mask_ratio_actual": torch.tensor(
                node_ids.numel() / max(mask_plan.num_candidate_nodes, 1),
                dtype=float_dtype,
                device=device,
            ),
            "edge_mask_ratio_actual": torch.tensor(
                physical_ids.numel()
                / max(mask_plan.num_candidate_physical_edges, 1),
                dtype=float_dtype,
                device=device,
            ),
        }
        output.update(
            self._route_statistics(backbone_out.route_gate, loss_total)
        )
        if return_predictions:
            output.update(
                {
                    "pred_node_embedding": pred_node_embedding,
                    "target_node_embedding": target_node_embedding,
                    "pred_edge_embedding": pred_edge_embedding,
                    "target_edge_embedding": target_edge_embedding,
                    "topology_logits": topology_logits,
                    "topology_labels": topology_labels,
                    "forward_message_ids": forward_message_ids,
                    "mask_plan": mask_plan,
                    "student_input": student_input,
                    "backbone_out": backbone_out,
                }
            )
        return output
