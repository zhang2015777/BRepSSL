

from dataclasses import dataclass

import dgl
import torch
from torch import nn

from models.layers import EdgeMPNN


FEATURE_DIM = 128
EDGE_MPNN_MLP_RATIO = 2
EDGE_MPNN_DROP = 0.3
EDGE_MPNN_DROP_PATH = 0.3


@dataclass(frozen=True)
class IBADMPEncoding:
    node_feat: torch.Tensor
    message_edge_feat: torch.Tensor
    route_gate: torch.Tensor


def _validate_graph_features(graph, node_feat, message_edge_feat):
    if not isinstance(graph, dgl.DGLGraph):
        raise TypeError("graph must be a dgl.DGLGraph")
    if len(graph.ndata) or len(graph.edata):
        raise ValueError("IBA-DMP graph must be an empty data container")
    if not isinstance(node_feat, torch.Tensor):
        raise TypeError("node_feat must be a torch.Tensor")
    if not isinstance(message_edge_feat, torch.Tensor):
        raise TypeError("message_edge_feat must be a torch.Tensor")
    if node_feat.shape != (graph.num_nodes(), FEATURE_DIM):
        raise ValueError(
            "node_feat must have shape "
            f"[{graph.num_nodes()},{FEATURE_DIM}], got {tuple(node_feat.shape)}"
        )
    if message_edge_feat.shape != (graph.num_edges(), FEATURE_DIM):
        raise ValueError(
            "message_edge_feat must have shape "
            f"[{graph.num_edges()},{FEATURE_DIM}], "
            f"got {tuple(message_edge_feat.shape)}"
        )
    if node_feat.dtype != torch.float32:
        raise TypeError("node_feat must have dtype=torch.float32")
    if message_edge_feat.dtype != torch.float32:
        raise TypeError("message_edge_feat must have dtype=torch.float32")
    if node_feat.device != graph.device:
        raise ValueError("node_feat device does not match graph device")
    if message_edge_feat.device != graph.device:
        raise ValueError("message_edge_feat device does not match graph device")
    if not torch.all(torch.isfinite(node_feat)):
        raise ValueError("node_feat contains NaN or Inf")
    if not torch.all(torch.isfinite(message_edge_feat)):
        raise ValueError("message_edge_feat contains NaN or Inf")

    batch_nodes = graph.batch_num_nodes().to(graph.device)
    batch_edges = graph.batch_num_edges().to(graph.device)
    if int(batch_nodes.sum().item()) != graph.num_nodes():
        raise ValueError("graph.batch_num_nodes() does not sum to num_nodes")
    if int(batch_edges.sum().item()) != graph.num_edges():
        raise ValueError("graph.batch_num_edges() does not sum to num_edges")
    if batch_nodes.numel() != batch_edges.numel():
        raise ValueError("graph batch node and edge metadata lengths differ")
    if graph.num_edges():
        node_graph_ids = torch.repeat_interleave(
            torch.arange(
                batch_nodes.numel(),
                dtype=torch.int64,
                device=graph.device,
            ),
            batch_nodes.to(torch.int64),
        )
        src, dst = graph.edges(order="eid")
        if not torch.equal(node_graph_ids[src], node_graph_ids[dst]):
            raise ValueError("IBA-DMP graph contains cross-subgraph messages")


def _incoming_mean(messages, destinations, node_count):
    aggregated = messages.new_zeros((node_count, FEATURE_DIM))
    counts = messages.new_zeros((node_count, 1))
    if messages.shape[0]:
        aggregated.index_add_(0, destinations, messages)
        counts.index_add_(
            0,
            destinations,
            torch.ones(
                (messages.shape[0], 1),
                dtype=messages.dtype,
                device=messages.device,
            ),
        )
    mean = aggregated / counts.clamp_min(1.0)
    return torch.where(counts > 0, mean, torch.zeros_like(mean))


class IBADMPBlock(nn.Module):
    

    def __init__(
        self,
        node_dim=FEATURE_DIM,
        edge_dim=FEATURE_DIM,
        drop=0.3,
    ):
        super().__init__()
        if node_dim != FEATURE_DIM or edge_dim != FEATURE_DIM:
            raise ValueError("IBA-DMP formally supports node_dim=edge_dim=128")
        if drop < 0 or drop >= 1:
            raise ValueError(f"drop must be in [0,1), got {drop}")
        self.node_dim = FEATURE_DIM
        self.edge_dim = FEATURE_DIM
        self.drop = float(drop)

        self.edge_mpnn = EdgeMPNN(
            node_dim=node_dim,
            edge_dim=edge_dim,
            mlp_ratio=EDGE_MPNN_MLP_RATIO,
            drop=EDGE_MPNN_DROP,
            drop_path=EDGE_MPNN_DROP_PATH,
        )
        self.route_network = nn.Sequential(
            nn.Linear(512, 128),
            nn.LayerNorm(128),
            nn.Mish(),
            nn.Linear(128, 64),
            nn.Mish(),
            nn.Linear(64, 1),
            nn.Sigmoid(),
        )
        self.continuity_message_network = nn.Sequential(
            nn.Linear(256, 128),
            nn.LayerNorm(128),
            nn.Mish(),
            nn.Linear(128, 128),
        )
        self.boundary_message_network = nn.Sequential(
            nn.Linear(384, 128),
            nn.LayerNorm(128),
            nn.Mish(),
            nn.Linear(128, 128),
        )
        self.node_update_network = nn.Sequential(
            nn.Linear(384, 256),
            nn.LayerNorm(256),
            nn.Mish(),
            nn.Dropout(self.drop),
            nn.Linear(256, 128),
        )
        self.node_output_norm = nn.LayerNorm(128)
        self.node_residual_scale = nn.Parameter(torch.tensor(0.1))

    def forward(self, graph, node_feat, message_edge_feat):
        _validate_graph_features(graph, node_feat, message_edge_feat)
        new_edge_feat = self.edge_mpnn(
            graph,
            node_feat,
            message_edge_feat,
        )
        message_count = graph.num_edges()
        if message_count:
            message_src, message_dst = graph.edges(order="eid")
            source_feat = node_feat.index_select(0, message_src)
            destination_feat = node_feat.index_select(0, message_dst)
            difference = source_feat - destination_feat
            absolute_difference = torch.abs(difference)
            route_gate = self.route_network(
                torch.cat(
                    (
                        source_feat,
                        destination_feat,
                        absolute_difference,
                        new_edge_feat,
                    ),
                    dim=1,
                )
            )
            raw_continuity = self.continuity_message_network(
                torch.cat((source_feat, new_edge_feat), dim=1)
            )
            raw_boundary = self.boundary_message_network(
                torch.cat(
                    (
                        difference,
                        absolute_difference,
                        new_edge_feat,
                    ),
                    dim=1,
                )
            )
            continuity_message = route_gate * raw_continuity
            boundary_message = (1.0 - route_gate) * raw_boundary
            incoming_continuity = _incoming_mean(
                continuity_message,
                message_dst,
                graph.num_nodes(),
            )
            incoming_boundary = _incoming_mean(
                boundary_message,
                message_dst,
                graph.num_nodes(),
            )
        else:
            route_gate = message_edge_feat.new_zeros((0, 1))
            incoming_continuity = node_feat.new_zeros(
                (graph.num_nodes(), FEATURE_DIM)
            )
            incoming_boundary = node_feat.new_zeros(
                (graph.num_nodes(), FEATURE_DIM)
            )

        node_update = self.node_update_network(
            torch.cat(
                (
                    node_feat,
                    incoming_continuity,
                    incoming_boundary,
                ),
                dim=1,
            )
        )
        new_node_feat = self.node_output_norm(
            node_feat + self.node_residual_scale * node_update
        )
        if not torch.all(torch.isfinite(new_node_feat)):
            raise ValueError("IBA-DMP node output contains NaN or Inf")
        if not torch.all(torch.isfinite(new_edge_feat)):
            raise ValueError("IBA-DMP edge output contains NaN or Inf")
        if not torch.all(torch.isfinite(route_gate)):
            raise ValueError("IBA-DMP route gate contains NaN or Inf")
        if route_gate.numel() and (
            torch.any(route_gate < 0) or torch.any(route_gate > 1)
        ):
            raise ValueError("IBA-DMP route gate is outside [0,1]")
        return IBADMPEncoding(
            node_feat=new_node_feat,
            message_edge_feat=new_edge_feat,
            route_gate=route_gate,
        )


class IBADMPStack(nn.Module):
    

    def __init__(
        self,
        num_layers=3,
        drop=0.3,
        node_dim=FEATURE_DIM,
        edge_dim=FEATURE_DIM,
    ):
        super().__init__()
        if not isinstance(num_layers, int) or num_layers < 1:
            raise ValueError("num_layers must be an integer >= 1")
        if node_dim != FEATURE_DIM or edge_dim != FEATURE_DIM:
            raise ValueError("IBA-DMP formally supports node_dim=edge_dim=128")
        self.num_layers = num_layers
        self.drop = float(drop)
        self.layers = nn.ModuleList(
            [
                IBADMPBlock(
                    node_dim=node_dim,
                    edge_dim=edge_dim,
                    drop=drop,
                )
                for _ in range(num_layers)
            ]
        )

    def forward(self, graph, node_feat, message_edge_feat):
        _validate_graph_features(graph, node_feat, message_edge_feat)
        current_node = node_feat
        current_edge = message_edge_feat
        final_gate = message_edge_feat.new_zeros((graph.num_edges(), 1))
        for layer in self.layers:
            output = layer(graph, current_node, current_edge)
            current_node = output.node_feat
            current_edge = output.message_edge_feat
            final_gate = output.route_gate
        return IBADMPEncoding(
            node_feat=current_node,
            message_edge_feat=current_edge,
            route_gate=final_gate,
        )
