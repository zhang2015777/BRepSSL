import torch
import torch.nn as nn

try:
    from dgl.nn import GATv2Conv
except ImportError as exc:
    GATv2Conv = None
    _GATV2_IMPORT_ERROR = exc
else:
    _GATV2_IMPORT_ERROR = None


class AttentionRefinementLayer(nn.Module):
    def __init__(self, feat_dim: int, num_heads: int = 8, drop: float = 0.3, attn_drop: float = 0.3):
        super().__init__()
        if GATv2Conv is None:
            raise ImportError(
                "Current DGL version does not support GATv2Conv, so "
                "AttentionRefinementLayer cannot be enabled."
            ) from _GATV2_IMPORT_ERROR
        if num_heads <= 0:
            raise ValueError(f"num_heads must be positive, got {num_heads}.")
        if feat_dim % num_heads != 0:
            raise ValueError(
                f"feat_dim must be divisible by num_heads, got feat_dim={feat_dim}, "
                f"num_heads={num_heads}."
            )

        self.feat_dim = feat_dim
        self.num_heads = num_heads
        self.head_dim = feat_dim // num_heads
        self.norm = nn.LayerNorm(feat_dim)
        self.attn = GATv2Conv(
            in_feats=feat_dim,
            out_feats=self.head_dim,
            num_heads=num_heads,
            feat_drop=drop,
            attn_drop=attn_drop,
            negative_slope=0.2,
            residual=False,
            activation=None,
            allow_zero_in_degree=True,
        )
        self.out_proj = nn.Linear(feat_dim, feat_dim)
        self.drop = nn.Dropout(drop)
        self.res_scale = nn.Parameter(torch.tensor(0.1))

    def forward(self, graph, h):
        if h.dim() != 2 or h.shape[1] != self.feat_dim:
            raise ValueError(
                f"Expected h shape [N, {self.feat_dim}], got {tuple(h.shape)}."
            )
        residual = h
        attn_out = self.attn(graph, self.norm(h)).flatten(1)
        attn_out = self.out_proj(attn_out)
        attn_out = self.drop(attn_out)
        return residual + self.res_scale * attn_out
