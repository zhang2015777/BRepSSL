

from dataclasses import dataclass

import dgl
import torch
from torch import nn
from torch.nn import functional as F

from models.brep_pretrain_input_masking import BRepMaskedStudentInput
from utils.brep_model_input_view import BRepModelInputView


FACE_ATTR_DIM = 16
FACE_GRID_SHAPE = (11, 5, 5)
EDGE_ATTR_DIM = 16
EDGE_GRID_SHAPE = (16, 5)
EDGE_FACE_UV_SHAPE = (2, 5, 2)
EDGE_FACE_UV_VALID_SHAPE = (2, 5)
OUTPUT_DIM = 128
UV_BOUND_TOLERANCE = 1e-6


@dataclass(frozen=True)
class BRepGeometryEncoding:
    node_feat: torch.Tensor
    message_edge_feat: torch.Tensor


def _masked_mean(sequence, valid):
    if sequence.ndim != 3 or valid.ndim != 2:
        raise ValueError("masked mean expects [B,C,L] and [B,L]")
    if sequence.shape[0] != valid.shape[0] or sequence.shape[2] != valid.shape[1]:
        raise ValueError("masked mean sequence and mask shapes do not align")
    weights = valid.to(dtype=sequence.dtype).unsqueeze(1)
    weighted_sum = (sequence * weights).sum(dim=2)
    count = weights.sum(dim=2)
    mean = weighted_sum / count.clamp_min(1.0)
    return torch.where(count > 0, mean, torch.zeros_like(mean))


class BRepGeometryEncoder(nn.Module):
    

    def __init__(self):
        super().__init__()
        self.face_attr_encoder = nn.Sequential(
            nn.Linear(16, 64),
            nn.LayerNorm(64),
            nn.Mish(),
            nn.Linear(64, 64),
            nn.LayerNorm(64),
            nn.Mish(),
        )
        self.face_grid_encoder = nn.Sequential(
            nn.Conv2d(11, 32, kernel_size=3, padding=1),
            nn.GroupNorm(8, 32),
            nn.Mish(),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.GroupNorm(8, 64),
            nn.Mish(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.GroupNorm(8, 64),
            nn.Mish(),
        )
        self.node_base_projection = nn.Sequential(
            nn.Linear(128, 128),
            nn.LayerNorm(128),
            nn.Mish(),
        )

        self.edge_attr_encoder = nn.Sequential(
            nn.Linear(16, 64),
            nn.LayerNorm(64),
            nn.Mish(),
            nn.Linear(64, 64),
            nn.LayerNorm(64),
            nn.Mish(),
        )
        self.edge_curve_encoder = nn.Sequential(
            nn.Conv1d(16, 64, kernel_size=3, padding=1),
            nn.GroupNorm(8, 64),
            nn.Mish(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.GroupNorm(8, 64),
            nn.Mish(),
        )
        self.side_sample_projection = nn.Sequential(
            nn.Conv1d(64, 32, kernel_size=1),
            nn.GroupNorm(8, 32),
            nn.Mish(),
        )
        self.edge_sample_fusion = nn.Sequential(
            nn.Conv1d(130, 128, kernel_size=1),
            nn.GroupNorm(8, 128),
            nn.Mish(),
            nn.Conv1d(128, 64, kernel_size=1),
            nn.GroupNorm(8, 64),
            nn.Mish(),
        )
        self.edge_output_projection = nn.Sequential(
            nn.Linear(128, 128),
            nn.LayerNorm(128),
            nn.Mish(),
        )

        self.incoming_edge_projection = nn.Linear(128, 128)
        self.node_context_update = nn.Sequential(
            nn.Linear(256, 128),
            nn.LayerNorm(128),
            nn.Mish(),
        )
        self.node_output_norm = nn.LayerNorm(128)
        self.context_scale = nn.Parameter(torch.tensor(0.1))
        self.node_mask_token = nn.Parameter(torch.empty(1, 128))
        nn.init.trunc_normal_(self.node_mask_token, std=0.02)

    def encode_full(self, model_input):
        if not isinstance(model_input, BRepModelInputView):
            raise TypeError("model_input must be a BRepModelInputView")
        message_view = model_input.message_view
        if model_input.node_attr.shape[0] != model_input.physical_num_nodes:
            raise ValueError("Full model input physical node count mismatch")
        if (
            message_view.message_graph.num_edges()
            != 2 * model_input.physical_num_edges
        ):
            raise ValueError(
                "Full model input must contain two messages per physical edge"
            )
        return self._encode(
            node_attr=model_input.node_attr,
            node_grid=model_input.node_grid,
            message_graph=message_view.message_graph,
            message_edge_attr=message_view.message_edge_attr,
            message_edge_grid=message_view.message_edge_grid,
            message_edge_face_uv=message_view.message_edge_face_uv,
            message_edge_face_uv_valid=(
                message_view.message_edge_face_uv_valid
            ),
            node_mask=None,
        )

    def encode_student(self, student_input, node_mask):
        if not isinstance(student_input, BRepMaskedStudentInput):
            raise TypeError("student_input must be a BRepMaskedStudentInput")
        if not isinstance(node_mask, torch.Tensor):
            raise TypeError("node_mask must be a torch.Tensor")
        node_count = student_input.node_attr.shape[0]
        if node_count != student_input.physical_num_nodes:
            raise ValueError("Student input physical node count mismatch")
        if node_mask.shape != (node_count,):
            raise ValueError(
                f"node_mask must have shape [{node_count}], "
                f"got {tuple(node_mask.shape)}"
            )
        if node_mask.dtype != torch.bool:
            raise TypeError("node_mask must have dtype=torch.bool")
        if node_mask.device != student_input.node_attr.device:
            raise ValueError("node_mask device does not match student input")
        if node_mask.any():
            if torch.any(student_input.node_attr[node_mask] != 0):
                raise ValueError(
                    "Masked student node attributes must already be all zero"
                )
            if torch.any(student_input.node_grid[node_mask] != 0):
                raise ValueError(
                    "Masked student node grids must already be all zero"
                )
        return self._encode(
            node_attr=student_input.node_attr,
            node_grid=student_input.node_grid,
            message_graph=student_input.message_graph,
            message_edge_attr=student_input.message_edge_attr,
            message_edge_grid=student_input.message_edge_grid,
            message_edge_face_uv=student_input.message_edge_face_uv,
            message_edge_face_uv_valid=(
                student_input.message_edge_face_uv_valid
            ),
            node_mask=node_mask,
        )

    def _require_float_tensor(self, name, value, shape, device):
        if not isinstance(value, torch.Tensor):
            raise TypeError(f"{name} must be a torch.Tensor")
        if value.shape != shape:
            raise ValueError(
                f"{name} must have shape {shape}, got {tuple(value.shape)}"
            )
        if value.dtype != torch.float32:
            raise TypeError(
                f"{name} must have dtype=torch.float32, got {value.dtype}"
            )
        if value.device != device:
            raise ValueError(f"{name} is on the wrong device")
        if not torch.all(torch.isfinite(value)):
            raise ValueError(f"{name} contains NaN or Inf")

    def _validate_inputs(
        self,
        node_attr,
        node_grid,
        message_graph,
        message_edge_attr,
        message_edge_grid,
        message_edge_face_uv,
        message_edge_face_uv_valid,
    ):
        if not isinstance(message_graph, dgl.DGLGraph):
            raise TypeError("message_graph must be a DGLGraph")
        if len(message_graph.ndata) or len(message_graph.edata):
            raise ValueError("message_graph must be an empty data container")
        device = message_graph.device
        parameter_device = self.node_mask_token.device
        if parameter_device != device:
            raise ValueError(
                f"Encoder parameters are on {parameter_device}, "
                f"but inputs are on {device}"
            )
        node_count = message_graph.num_nodes()
        message_count = message_graph.num_edges()
        self._require_float_tensor(
            "node_attr",
            node_attr,
            (node_count, FACE_ATTR_DIM),
            device,
        )
        self._require_float_tensor(
            "node_grid",
            node_grid,
            (node_count,) + FACE_GRID_SHAPE,
            device,
        )
        self._require_float_tensor(
            "message_edge_attr",
            message_edge_attr,
            (message_count, EDGE_ATTR_DIM),
            device,
        )
        self._require_float_tensor(
            "message_edge_grid",
            message_edge_grid,
            (message_count,) + EDGE_GRID_SHAPE,
            device,
        )
        self._require_float_tensor(
            "message_edge_face_uv",
            message_edge_face_uv,
            (message_count,) + EDGE_FACE_UV_SHAPE,
            device,
        )
        if not isinstance(message_edge_face_uv_valid, torch.Tensor):
            raise TypeError("message_edge_face_uv_valid must be a tensor")
        if message_edge_face_uv_valid.shape != (
            message_count,
        ) + EDGE_FACE_UV_VALID_SHAPE:
            raise ValueError(
                "message_edge_face_uv_valid must have shape "
                f"[{message_count},2,5]"
            )
        if message_edge_face_uv_valid.dtype != torch.bool:
            raise TypeError(
                "message_edge_face_uv_valid must have dtype=torch.bool"
            )
        if message_edge_face_uv_valid.device != device:
            raise ValueError("message_edge_face_uv_valid is on the wrong device")
        invalid_uv = message_edge_face_uv[~message_edge_face_uv_valid]
        if invalid_uv.numel() and torch.any(invalid_uv != 0):
            raise ValueError(
                "Invalid p-curve UV positions must be exactly [0,0]"
            )
        valid_uv = message_edge_face_uv[message_edge_face_uv_valid]
        if valid_uv.numel() and torch.any(
            torch.abs(valid_uv) > 1.0 + UV_BOUND_TOLERANCE
        ):
            raise ValueError("Valid p-curve UV coordinates must lie in [-1,1]")
        return node_count, message_count, device

    def _sample_face_feature_map(
        self,
        face_feature_map,
        message_nodes,
        uv,
        valid,
    ):
        message_count = message_nodes.numel()
        if message_count == 0:
            return face_feature_map.new_zeros((0, 64, uv.shape[1]))
        selected_face_maps = face_feature_map.index_select(0, message_nodes)
        sample_grid = uv.unsqueeze(1)
        samples = F.grid_sample(
            selected_face_maps,
            sample_grid,
            mode="bilinear",
            padding_mode="zeros",
            align_corners=True,
        ).squeeze(2)
        return samples * valid.unsqueeze(1).to(samples.dtype)

    def _encode(
        self,
        *,
        node_attr,
        node_grid,
        message_graph,
        message_edge_attr,
        message_edge_grid,
        message_edge_face_uv,
        message_edge_face_uv_valid,
        node_mask,
    ):
        node_count, message_count, device = self._validate_inputs(
            node_attr,
            node_grid,
            message_graph,
            message_edge_attr,
            message_edge_grid,
            message_edge_face_uv,
            message_edge_face_uv_valid,
        )

        face_attr_feat = self.face_attr_encoder(node_attr)
        face_feature_map = self.face_grid_encoder(node_grid)
        inside = node_grid[:, 10:11]
        face_grid_feat = _masked_mean(
            face_feature_map.flatten(2),
            (inside.flatten(2).squeeze(1) > 0.5),
        )
        node_base_feat = self.node_base_projection(
            torch.cat((face_attr_feat, face_grid_feat), dim=1)
        )
        if node_mask is None:
            node_base_or_mask_token = node_base_feat
        else:
            expanded_token = self.node_mask_token.expand(node_count, -1)
            node_base_or_mask_token = torch.where(
                node_mask.unsqueeze(1),
                expanded_token,
                node_base_feat,
            )

        if message_count == 0:
            message_edge_feat = node_attr.new_zeros((0, OUTPUT_DIM))
        else:
            edge_attr_feat = self.edge_attr_encoder(message_edge_attr)
            curve_valid = (
                torch.linalg.vector_norm(
                    message_edge_grid[:, 3:6, :],
                    dim=1,
                )
                > 1e-12
            )
            edge_curve_sequence = self.edge_curve_encoder(
                message_edge_grid
            )
            edge_curve_sequence = (
                edge_curve_sequence
                * curve_valid.unsqueeze(1).to(edge_curve_sequence.dtype)
            )

            message_src, message_dst = message_graph.edges(order="eid")
            src_uv_valid = message_edge_face_uv_valid[:, 0, :]
            dst_uv_valid = message_edge_face_uv_valid[:, 1, :]
            src_face_samples = self._sample_face_feature_map(
                face_feature_map,
                message_src,
                message_edge_face_uv[:, 0, :, :],
                src_uv_valid,
            )
            dst_face_samples = self._sample_face_feature_map(
                face_feature_map,
                message_dst,
                message_edge_face_uv[:, 1, :, :],
                dst_uv_valid,
            )
            src_projected = self.side_sample_projection(src_face_samples)
            dst_projected = self.side_sample_projection(dst_face_samples)
            src_projected = (
                src_projected
                * src_uv_valid.unsqueeze(1).to(src_projected.dtype)
            )
            dst_projected = (
                dst_projected
                * dst_uv_valid.unsqueeze(1).to(dst_projected.dtype)
            )
            fused_valid = curve_valid | src_uv_valid | dst_uv_valid
            fusion_input = torch.cat(
                (
                    edge_curve_sequence,
                    src_projected,
                    dst_projected,
                    src_uv_valid.unsqueeze(1).to(node_attr.dtype),
                    dst_uv_valid.unsqueeze(1).to(node_attr.dtype),
                ),
                dim=1,
            )
            fused_edge_sequence = self.edge_sample_fusion(fusion_input)
            fused_edge_sequence = (
                fused_edge_sequence
                * fused_valid.unsqueeze(1).to(fused_edge_sequence.dtype)
            )
            edge_grid_uv_feat = _masked_mean(
                fused_edge_sequence,
                fused_valid,
            )
            message_edge_feat = self.edge_output_projection(
                torch.cat((edge_attr_feat, edge_grid_uv_feat), dim=1)
            )

        incoming_context = node_attr.new_zeros((node_count, OUTPUT_DIM))
        incoming_count = node_attr.new_zeros((node_count, 1))
        if message_count:
            _, message_dst = message_graph.edges(order="eid")
            projected_edge_context = self.incoming_edge_projection(
                message_edge_feat
            )
            incoming_context.index_add_(
                0,
                message_dst,
                projected_edge_context.to(dtype=incoming_context.dtype),
            )
            incoming_count.index_add_(
                0,
                message_dst,
                torch.ones(
                    (message_count, 1),
                    dtype=node_attr.dtype,
                    device=device,
                ),
            )
        incoming_context = incoming_context / incoming_count.clamp_min(1.0)
        incoming_context = torch.where(
            incoming_count > 0,
            incoming_context,
            torch.zeros_like(incoming_context),
        )
        update = self.node_context_update(
            torch.cat((node_base_or_mask_token, incoming_context), dim=1)
        )
        node_feat = self.node_output_norm(
            node_base_or_mask_token + self.context_scale * update
        )
        if not torch.all(torch.isfinite(node_feat)):
            raise ValueError("Encoded node features contain NaN or Inf")
        if not torch.all(torch.isfinite(message_edge_feat)):
            raise ValueError("Encoded message edge features contain NaN or Inf")
        return BRepGeometryEncoding(
            node_feat=node_feat,
            message_edge_feat=message_edge_feat,
        )
