

import torch
from torch import nn


class _ResidualBlock(nn.Module):
    def __init__(self, dim, hidden_dim=None, drop=0.3):
        super().__init__()
        hidden_dim = hidden_dim if hidden_dim is not None else dim * 2
        self.norm = nn.LayerNorm(dim)
        self.fc1 = nn.Linear(dim, hidden_dim)
        self.act = nn.Mish()
        self.drop1 = nn.Dropout(drop)
        self.fc2 = nn.Linear(hidden_dim, dim)
        self.drop2 = nn.Dropout(drop)

    def forward(self, value):
        update = self.fc2(
            self.drop1(self.act(self.fc1(self.norm(value))))
        )
        return value + self.drop2(update)


class QualityProcessHead(nn.Module):
    

    def __init__(
        self,
        quality_dim=2,
        quality_hidden_dim=128,
        depth=3,
        drop=0.3,
    ):
        super().__init__()
        if depth < 1:
            raise ValueError("depth must be positive")
        if quality_hidden_dim <= 0:
            raise ValueError("quality_hidden_dim must be positive")
        if not 0 <= drop < 1:
            raise ValueError("drop must be in [0,1)")
        self.quality_dim = quality_dim
        layers = [
            nn.Linear(quality_dim, quality_hidden_dim),
            nn.LayerNorm(quality_hidden_dim),
            nn.Mish(),
            nn.Dropout(drop),
        ]
        for _ in range(depth - 1):
            layers.append(
                _ResidualBlock(
                    quality_hidden_dim,
                    quality_hidden_dim * 2,
                    drop,
                )
            )
        layers.extend(
            [
                nn.LayerNorm(quality_hidden_dim),
                nn.Linear(quality_hidden_dim, 2),
            ]
        )
        self.net = nn.Sequential(*layers)

    def forward(self, quality):
        if quality.dim() != 2 or quality.shape[1] != self.quality_dim:
            raise ValueError(
                f"quality must have shape [N,{self.quality_dim}]"
            )
        return self.net(quality)


class TaskResidualAdapter(nn.Module):
    def __init__(
        self,
        feat_dim=256,
        hidden_dim=512,
        depth=2,
        drop=0.3,
        init_scale=0.1,
        enabled=True,
    ):
        super().__init__()
        if depth < 0 or hidden_dim <= 0:
            raise ValueError("invalid adapter depth or hidden_dim")
        if not 0 <= drop < 1 or init_scale < 0:
            raise ValueError("invalid adapter drop or init_scale")
        self.feat_dim = feat_dim
        self.enabled = enabled
        self.res_scale = nn.Parameter(torch.tensor(float(init_scale)))
        layers = [
            nn.LayerNorm(feat_dim),
            nn.Linear(feat_dim, hidden_dim),
            nn.Mish(),
            nn.Dropout(drop),
        ]
        for _ in range(depth):
            layers.append(
                _ResidualBlock(hidden_dim, hidden_dim * 2, drop)
            )
        layers.extend(
            [nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, feat_dim)]
        )
        self.adapter = nn.Sequential(*layers)

    def forward(self, value):
        if value.dim() != 2 or value.shape[1] != self.feat_dim:
            raise ValueError(f"value must have shape [N,{self.feat_dim}]")
        if not self.enabled:
            return value
        return value + self.res_scale * self.adapter(value)
