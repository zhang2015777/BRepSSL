






from collections import deque

import torch


MASK_POLICY = "centered_graph_region_node_edge_mask"
MASK_SCOPE = "centered_region"
SINGLE_TOPOLOGY_CACHE_ATTR = "_brep_single_topology_cache"
BATCH_TOPOLOGY_CACHE_ATTR = "_brep_batch_topology_cache"

_INDEX_FIELDS = (
    "center_node_indices",
    "candidate_node_indices",
    "candidate_node_graph_ids",
    "candidate_edge_indices",
    "candidate_edge_graph_ids",
    "masked_node_indices",
    "masked_node_graph_ids",
    "masked_edge_indices",
    "masked_edge_graph_ids",
    "positive_edge_src",
    "positive_edge_dst",
    "positive_edge_ids",
    "positive_edge_graph_ids",
    "negative_edge_src",
    "negative_edge_dst",
    "negative_edge_graph_ids",
)


def _empty_long(device):
    return torch.empty(0, dtype=torch.long, device=device)


def _validate_mask_args(
    node_mask_ratio,
    edge_mask_ratio,
    negative_edge_ratio,
    min_mask_nodes,
    min_mask_edges,
):
    if node_mask_ratio < 0 or node_mask_ratio > 1:
        raise ValueError(
            f"node_mask_ratio must be in [0, 1], got {node_mask_ratio}."
        )
    if edge_mask_ratio < 0 or edge_mask_ratio > 1:
        raise ValueError(
            f"edge_mask_ratio must be in [0, 1], got {edge_mask_ratio}."
        )
    if negative_edge_ratio < 0:
        raise ValueError(
            "negative_edge_ratio must be non-negative, got "
            f"{negative_edge_ratio}."
        )
    if min_mask_nodes < 0:
        raise ValueError(
            f"min_mask_nodes must be non-negative, got {min_mask_nodes}."
        )
    if min_mask_edges < 0:
        raise ValueError(
            f"min_mask_edges must be non-negative, got {min_mask_edges}."
        )


def _graph_device(batched_graph):
    device = getattr(batched_graph, "device", None)
    return torch.device("cpu") if device is None else torch.device(device)


def _count_list(counts, name):
    if torch.is_tensor(counts):
        values = counts.detach().cpu().reshape(-1).tolist()
    else:
        try:
            values = list(counts)
        except TypeError as exc:
            raise ValueError(f"{name} must return a one-dimensional count sequence.") from exc

    result = [int(value) for value in values]
    if any(value < 0 for value in result):
        raise ValueError(f"{name} returned negative counts: {result}.")
    return result


def _offsets_from_counts(counts):
    offsets = []
    offset = 0
    for count in counts:
        offsets.append(offset)
        offset += count
    return offsets


def _random_device(generator):
    if generator is None:
        return torch.device("cpu")
    device = getattr(generator, "device", None)
    return torch.device("cpu") if device is None else torch.device(device)


def _random_index(length, generator):
    if length <= 0:
        raise ValueError("length must be positive.")
    index = torch.randint(
        length,
        (1,),
        generator=generator,
        device=_random_device(generator),
    )
    return int(index.item())


def _rand_choice(values, count, generator):
    count = min(max(int(count), 0), len(values))
    if count == 0:
        return []
    permutation = torch.randperm(
        len(values),
        generator=generator,
        device=_random_device(generator),
    )
    selected = permutation[:count].detach().cpu().tolist()
    return [values[index] for index in selected]


def _shuffle_values(values, generator):
    return _rand_choice(values, len(values), generator)


def _mask_count(item_count, ratio, minimum):
    if item_count == 0:
        return 0
    count = int(round(item_count * ratio))
    count = max(count, int(minimum))
    return min(count, item_count)


def _pair_key(src, dst):
    return (src, dst) if src <= dst else (dst, src)


def _build_undirected_adjacency(graph_nodes, graph_edge_pairs):
    adjacency = {node: set() for node in graph_nodes}
    for src, dst in graph_edge_pairs:
        if src == dst:
            continue
        if src not in adjacency or dst not in adjacency:
            continue
        adjacency[src].add(dst)
        adjacency[dst].add(src)
    return adjacency


def _edge_lists_from_graph(graph, num_edges):
    edges_fn = getattr(graph, "edges", None)
    if not callable(edges_fn):
        raise ValueError("graph must provide edges(order='eid').")
    if num_edges == 0:
        return [], []

    src_tensor, dst_tensor = edges_fn(order="eid")
    if src_tensor.numel() != num_edges or dst_tensor.numel() != num_edges:
        raise ValueError(
            "edges(order='eid') returned {} sources and {} destinations, "
            "expected {} of each.".format(
                src_tensor.numel(),
                dst_tensor.numel(),
                num_edges,
            )
        )
    src_list = [int(value) for value in src_tensor.detach().cpu().tolist()]
    dst_list = [int(value) for value in dst_tensor.detach().cpu().tolist()]
    return src_list, dst_list


def _build_topology_components(graph_nodes, graph_edge_ids, graph_edge_pairs):
    if len(graph_edge_ids) != len(graph_edge_pairs):
        raise ValueError(
            "graph_edge_ids and graph_edge_pairs must have the same length."
        )

    pair_to_edge_ids = {}
    for edge_id, (src, dst) in zip(graph_edge_ids, graph_edge_pairs):
        pair_to_edge_ids.setdefault(_pair_key(src, dst), []).append(edge_id)
    adjacency = _build_undirected_adjacency(graph_nodes, graph_edge_pairs)
    existing_undirected_pairs = {
        _pair_key(src, dst)
        for src, dst in graph_edge_pairs
        if src != dst
    }
    return pair_to_edge_ids, adjacency, existing_undirected_pairs


def _validate_single_topology_cache(cache):
    required_fields = (
        "num_nodes",
        "num_edges",
        "src_list",
        "dst_list",
        "graph_nodes",
        "graph_edge_ids",
        "graph_edge_pairs",
        "pair_to_edge_ids",
        "adjacency",
        "existing_undirected_pairs",
    )
    if not isinstance(cache, dict):
        raise TypeError("Single-graph topology cache must be a dict.")
    missing = [field for field in required_fields if field not in cache]
    if missing:
        raise ValueError(f"Single-graph topology cache is missing fields: {missing}.")

    num_nodes = int(cache["num_nodes"])
    num_edges = int(cache["num_edges"])
    if num_nodes < 0 or num_edges < 0:
        raise ValueError("Single-graph topology cache contains negative counts.")

    expected_nodes = list(range(num_nodes))
    expected_edge_ids = list(range(num_edges))
    if cache["graph_nodes"] != expected_nodes:
        raise ValueError("Single-graph cached node IDs are not local contiguous IDs.")
    if cache["graph_edge_ids"] != expected_edge_ids:
        raise ValueError("Single-graph cached edge IDs are not local contiguous IDs.")

    src_list = cache["src_list"]
    dst_list = cache["dst_list"]
    if len(src_list) != num_edges or len(dst_list) != num_edges:
        raise ValueError("Single-graph cached endpoint counts do not match num_edges.")
    expected_edge_pairs = list(zip(src_list, dst_list))
    if cache["graph_edge_pairs"] != expected_edge_pairs:
        raise ValueError("Single-graph cached edge pairs do not match src/dst lists.")
    for edge_id, (src, dst) in enumerate(expected_edge_pairs):
        if not (0 <= src < num_nodes and 0 <= dst < num_nodes):
            raise ValueError(
                "Single-graph edge {} has endpoints ({}, {}) outside [0, {}).".format(
                    edge_id,
                    src,
                    dst,
                    num_nodes,
                )
            )

    expected_pair_to_edge_ids, expected_adjacency, expected_existing_pairs = (
        _build_topology_components(
            expected_nodes,
            expected_edge_ids,
            expected_edge_pairs,
        )
    )
    if cache["pair_to_edge_ids"] != expected_pair_to_edge_ids:
        raise ValueError("Single-graph cached pair_to_edge_ids is inconsistent.")
    if cache["adjacency"] != expected_adjacency:
        raise ValueError("Single-graph cached adjacency is inconsistent.")
    if cache["existing_undirected_pairs"] != expected_existing_pairs:
        raise ValueError(
            "Single-graph cached existing_undirected_pairs is inconsistent."
        )


def _validate_single_topology_cache_metadata(graph, cache):
    if not isinstance(cache, dict):
        raise TypeError("Single-graph topology cache must be a dict.")
    required_fields = (
        "num_nodes",
        "num_edges",
        "graph_nodes",
        "graph_edge_ids",
        "graph_edge_pairs",
        "pair_to_edge_ids",
        "adjacency",
        "existing_undirected_pairs",
    )
    missing = [field for field in required_fields if field not in cache]
    if missing:
        raise ValueError(f"Single-graph topology cache is missing fields: {missing}.")
    num_nodes_fn = getattr(graph, "num_nodes", None)
    num_edges_fn = getattr(graph, "num_edges", None)
    if not callable(num_nodes_fn) or not callable(num_edges_fn):
        raise ValueError("graph must provide num_nodes() and num_edges().")
    if int(cache.get("num_nodes", -1)) != int(num_nodes_fn()):
        raise ValueError("Single-graph topology cache node count does not match graph.")
    if int(cache.get("num_edges", -1)) != int(num_edges_fn()):
        raise ValueError("Single-graph topology cache edge count does not match graph.")


def build_single_graph_topology_cache(graph):
    
    num_nodes_fn = getattr(graph, "num_nodes", None)
    num_edges_fn = getattr(graph, "num_edges", None)
    if not callable(num_nodes_fn) or not callable(num_edges_fn):
        raise ValueError("graph must provide num_nodes() and num_edges().")

    num_nodes = int(num_nodes_fn())
    num_edges = int(num_edges_fn())
    src_list, dst_list = _edge_lists_from_graph(graph, num_edges)
    graph_nodes = list(range(num_nodes))
    graph_edge_ids = list(range(num_edges))
    graph_edge_pairs = list(zip(src_list, dst_list))
    pair_to_edge_ids, adjacency, existing_undirected_pairs = (
        _build_topology_components(
            graph_nodes,
            graph_edge_ids,
            graph_edge_pairs,
        )
    )
    cache = {
        "num_nodes": num_nodes,
        "num_edges": num_edges,
        "src_list": src_list,
        "dst_list": dst_list,
        "graph_nodes": graph_nodes,
        "graph_edge_ids": graph_edge_ids,
        "graph_edge_pairs": graph_edge_pairs,
        "pair_to_edge_ids": pair_to_edge_ids,
        "adjacency": adjacency,
        "existing_undirected_pairs": existing_undirected_pairs,
    }
    _validate_single_topology_cache(cache)
    return cache


def build_batch_topology_cache(graphs):
    
    batch_records = []
    node_offset = 0
    edge_offset = 0
    for graph_id, graph in enumerate(graphs):
        cache = getattr(graph, SINGLE_TOPOLOGY_CACHE_ATTR, None)
        if cache is None:
            cache = build_single_graph_topology_cache(graph)
            try:
                setattr(graph, SINGLE_TOPOLOGY_CACHE_ATTR, cache)
            except Exception as exc:
                raise TypeError(
                    "DGLGraph does not support the single-graph topology cache attribute."
                ) from exc
        _validate_single_topology_cache_metadata(graph, cache)

        node_count = int(cache["num_nodes"])
        edge_count = int(cache["num_edges"])
        graph_nodes = [node + node_offset for node in cache["graph_nodes"]]
        graph_edge_ids = [edge_id + edge_offset for edge_id in cache["graph_edge_ids"]]
        graph_edge_pairs = [
            (src + node_offset, dst + node_offset)
            for src, dst in cache["graph_edge_pairs"]
        ]
        pair_to_edge_ids = {
            _pair_key(src + node_offset, dst + node_offset): [
                edge_id + edge_offset for edge_id in edge_ids
            ]
            for (src, dst), edge_ids in cache["pair_to_edge_ids"].items()
        }
        adjacency = {
            node + node_offset: {
                neighbor + node_offset for neighbor in neighbors
            }
            for node, neighbors in cache["adjacency"].items()
        }
        existing_undirected_pairs = {
            _pair_key(src + node_offset, dst + node_offset)
            for src, dst in cache["existing_undirected_pairs"]
        }
        batch_records.append(
            {
                "graph_id": graph_id,
                "node_offset": node_offset,
                "edge_offset": edge_offset,
                "node_count": node_count,
                "edge_count": edge_count,
                "graph_nodes": graph_nodes,
                "graph_edge_ids": graph_edge_ids,
                "graph_edge_pairs": graph_edge_pairs,
                "pair_to_edge_ids": pair_to_edge_ids,
                "adjacency": adjacency,
                "existing_undirected_pairs": existing_undirected_pairs,
            }
        )
        node_offset += node_count
        edge_offset += edge_count
    return batch_records


def _validate_batch_topology_cache(batch_records, node_counts, edge_counts):
    if not isinstance(batch_records, (list, tuple)):
        raise TypeError("Batch topology cache must be a list or tuple of records.")
    if len(batch_records) != len(node_counts):
        raise ValueError(
            "Batch topology cache has {} records, expected {}.".format(
                len(batch_records),
                len(node_counts),
            )
        )

    node_offsets = _offsets_from_counts(node_counts)
    edge_offsets = _offsets_from_counts(edge_counts)
    required_fields = (
        "graph_id",
        "node_offset",
        "edge_offset",
        "node_count",
        "edge_count",
        "graph_nodes",
        "graph_edge_ids",
        "graph_edge_pairs",
        "pair_to_edge_ids",
        "adjacency",
        "existing_undirected_pairs",
    )
    for graph_id, record in enumerate(batch_records):
        if not isinstance(record, dict):
            raise TypeError(f"Batch topology record {graph_id} must be a dict.")
        missing = [field for field in required_fields if field not in record]
        if missing:
            raise ValueError(
                f"Batch topology record {graph_id} is missing fields: {missing}."
            )

        node_offset = node_offsets[graph_id]
        edge_offset = edge_offsets[graph_id]
        node_count = node_counts[graph_id]
        edge_count = edge_counts[graph_id]
        expected_metadata = {
            "graph_id": graph_id,
            "node_offset": node_offset,
            "edge_offset": edge_offset,
            "node_count": node_count,
            "edge_count": edge_count,
        }
        for field, expected_value in expected_metadata.items():
            if int(record[field]) != expected_value:
                raise ValueError(
                    "Batch topology record {} has {}={}, expected {}.".format(
                        graph_id,
                        field,
                        record[field],
                        expected_value,
                    )
                )

        node_end = node_offset + node_count
        edge_end = edge_offset + edge_count
        graph_nodes = record["graph_nodes"]
        graph_edge_ids = record["graph_edge_ids"]
        if len(graph_nodes) != node_count or any(
            node != node_offset + index
            for index, node in enumerate(graph_nodes)
        ):
            raise ValueError(
                f"Batch topology record {graph_id} has invalid global node IDs."
            )
        if len(graph_edge_ids) != edge_count or any(
            edge_id != edge_offset + index
            for index, edge_id in enumerate(graph_edge_ids)
        ):
            raise ValueError(
                f"Batch topology record {graph_id} has invalid global edge IDs."
            )
        if len(record["graph_edge_pairs"]) != edge_count:
            raise ValueError(
                f"Batch topology record {graph_id} edge-pair count is inconsistent."
            )
        for src, dst in record["graph_edge_pairs"]:
            if not (
                node_offset <= src < node_end
                and node_offset <= dst < node_end
            ):
                raise ValueError(
                    "Batch topology record {} contains cross-graph edge ({}, {}).".format(
                        graph_id,
                        src,
                        dst,
                    )
                )

        for pair in record["existing_undirected_pairs"]:
            if (
                not isinstance(pair, tuple)
                or len(pair) != 2
                or pair[0] == pair[1]
                or pair != _pair_key(pair[0], pair[1])
                or pair[0] < node_offset
                or pair[1] >= node_end
            ):
                raise ValueError(
                    f"Batch topology record {graph_id} has an invalid existing pair."
                )
        if len(record["adjacency"]) != node_count or any(
            node < node_offset or node >= node_end
            for node in record["adjacency"].keys()
        ):
            raise ValueError(
                f"Batch topology record {graph_id} has invalid adjacency keys."
            )
        for node, neighbors in record["adjacency"].items():
            if any(neighbor < node_offset or neighbor >= node_end for neighbor in neighbors):
                raise ValueError(
                    f"Batch topology record {graph_id} adjacency crosses graphs."
                )

        mapped_edge_ids = set()
        for pair, edge_ids in record["pair_to_edge_ids"].items():
            if (
                not isinstance(pair, tuple)
                or len(pair) != 2
                or pair != _pair_key(pair[0], pair[1])
                or pair[0] < node_offset
                or pair[1] >= node_end
            ):
                raise ValueError(
                    f"Batch topology record {graph_id} pair key crosses graphs."
                )
            for edge_id in edge_ids:
                if edge_id < edge_offset or edge_id >= edge_end:
                    raise ValueError(
                        f"Batch topology record {graph_id} maps an out-of-range edge ID."
                    )
                local_index = edge_id - edge_offset
                src, dst = record["graph_edge_pairs"][local_index]
                if _pair_key(src, dst) != pair:
                    raise ValueError(
                        f"Batch topology record {graph_id} pair mapping is inconsistent."
                    )
                if edge_id in mapped_edge_ids:
                    raise ValueError(
                        f"Batch topology record {graph_id} maps an edge more than once."
                    )
                mapped_edge_ids.add(edge_id)
        if len(mapped_edge_ids) != edge_count:
            raise ValueError(
                f"Batch topology record {graph_id} does not map every edge exactly once."
            )

    return list(batch_records)


def _bfs_distances(graph_nodes, adjacency, center_node):
    distances = {node: None for node in graph_nodes}
    distances[center_node] = 0
    queue = deque([center_node])
    while queue:
        node = queue.popleft()
        next_distance = distances[node] + 1
        for neighbor in adjacency[node]:
            if distances[neighbor] is not None:
                continue
            distances[neighbor] = next_distance
            queue.append(neighbor)
    return distances


def _distance_sort_key(distance):
    if distance is None:
        return (1, 0)
    return (0, int(distance))


def _order_by_distance(distance_value_pairs, generator):
    groups = {}
    for distance, value in distance_value_pairs:
        groups.setdefault(distance, []).append(value)

    ordered = []
    for distance in sorted(groups.keys(), key=_distance_sort_key):
        ordered.extend(_shuffle_values(groups[distance], generator))
    return ordered


def _sample_negative_edges(
    graph_nodes,
    existing_undirected_pairs,
    positive_count,
    negative_edge_ratio,
    generator,
):
    target_count = int(round(positive_count * negative_edge_ratio))
    if target_count <= 0 or len(graph_nodes) < 2:
        return []

    negative_edges = []
    sampled_directed_pairs = set()
    max_attempts = max(100, target_count * 20, len(graph_nodes) * 4)
    attempts = 0
    while len(negative_edges) < target_count and attempts < max_attempts:
        attempts += 1
        src = graph_nodes[_random_index(len(graph_nodes), generator)]
        dst = graph_nodes[_random_index(len(graph_nodes), generator)]
        directed_pair = (src, dst)
        if src == dst:
            continue
        if _pair_key(src, dst) in existing_undirected_pairs:
            continue
        if directed_pair in sampled_directed_pairs:
            continue
        sampled_directed_pairs.add(directed_pair)
        negative_edges.append(directed_pair)

    remaining_count = target_count - len(negative_edges)
    if remaining_count > 0:
        candidates = []
        for src in graph_nodes:
            for dst in graph_nodes:
                directed_pair = (src, dst)
                if src == dst:
                    continue
                if _pair_key(src, dst) in existing_undirected_pairs:
                    continue
                if directed_pair in sampled_directed_pairs:
                    continue
                candidates.append(directed_pair)
        negative_edges.extend(
            _rand_choice(candidates, min(remaining_count, len(candidates)), generator)
        )

    graph_node_set = set(graph_nodes)
    if len(negative_edges) > target_count:
        raise RuntimeError("Negative edge sampler exceeded its target count.")
    if len(set(negative_edges)) != len(negative_edges):
        raise RuntimeError("Negative edge sampler produced duplicate directed pairs.")
    for src, dst in negative_edges:
        if src == dst:
            raise RuntimeError("Negative edge sampler produced a self-loop.")
        if src not in graph_node_set or dst not in graph_node_set:
            raise RuntimeError("Negative edge sampler produced a cross-graph endpoint.")
        if _pair_key(src, dst) in existing_undirected_pairs:
            raise RuntimeError("Negative edge sampler selected an existing edge pair.")
    return negative_edges


def _build_uncached_batch_topology(
    batched_graph,
    node_counts,
    edge_counts,
):
    total_edges = sum(edge_counts)
    all_src, all_dst = _edge_lists_from_graph(batched_graph, total_edges)
    node_offsets = _offsets_from_counts(node_counts)
    edge_offsets = _offsets_from_counts(edge_counts)
    batch_records = []
    for graph_id, (node_count, edge_count) in enumerate(
        zip(node_counts, edge_counts)
    ):
        node_offset = node_offsets[graph_id]
        edge_offset = edge_offsets[graph_id]
        node_end = node_offset + node_count
        edge_end = edge_offset + edge_count
        graph_nodes = list(range(node_offset, node_end))
        graph_edge_ids = list(range(edge_offset, edge_end))
        graph_edge_pairs = []
        for edge_id in graph_edge_ids:
            src = all_src[edge_id]
            dst = all_dst[edge_id]
            if not (
                node_offset <= src < node_end
                and node_offset <= dst < node_end
            ):
                raise ValueError(
                    "Graph {} edge {} has endpoints ({}, {}) outside node range "
                    "[{}, {}).".format(
                        graph_id,
                        edge_id,
                        src,
                        dst,
                        node_offset,
                        node_end,
                    )
                )
            graph_edge_pairs.append((src, dst))

        pair_to_edge_ids, adjacency, existing_undirected_pairs = (
            _build_topology_components(
                graph_nodes,
                graph_edge_ids,
                graph_edge_pairs,
            )
        )
        batch_records.append(
            {
                "graph_id": graph_id,
                "node_offset": node_offset,
                "edge_offset": edge_offset,
                "node_count": node_count,
                "edge_count": edge_count,
                "graph_nodes": graph_nodes,
                "graph_edge_ids": graph_edge_ids,
                "graph_edge_pairs": graph_edge_pairs,
                "pair_to_edge_ids": pair_to_edge_ids,
                "adjacency": adjacency,
                "existing_undirected_pairs": existing_undirected_pairs,
            }
        )
    return batch_records


def _empty_mask_result(
    device,
    num_graphs,
    node_mask_ratio,
    edge_mask_ratio,
    negative_edge_ratio,
    directed_edges,
):
    result = {name: _empty_long(device) for name in _INDEX_FIELDS}
    result.update(
        {
            "mask_policy": MASK_POLICY,
            "mask_scope": MASK_SCOPE,
            "num_graphs": int(num_graphs),
            "node_mask_ratio": float(node_mask_ratio),
            "edge_mask_ratio": float(edge_mask_ratio),
            "negative_edge_ratio": float(negative_edge_ratio),
            "directed_edges": bool(directed_edges),
            "num_candidate_nodes": 0,
            "num_candidate_edges": 0,
            "num_masked_nodes": 0,
            "num_masked_edges": 0,
        }
    )
    return result


def sample_centered_region_mask(
    batched_graph,
    node_mask_ratio: float = 0.5,
    edge_mask_ratio: float = 0.5,
    negative_edge_ratio: float = 1.0,
    generator=None,
    min_mask_nodes: int = 1,
    min_mask_edges: int = 1,
    directed_edges: bool = True,
    eligible_edge_mask=None,
):
    








    _validate_mask_args(
        node_mask_ratio,
        edge_mask_ratio,
        negative_edge_ratio,
        min_mask_nodes,
        min_mask_edges,
    )

    batch_num_nodes_fn = getattr(batched_graph, "batch_num_nodes", None)
    if not callable(batch_num_nodes_fn):
        raise ValueError("batched_graph must provide batch_num_nodes().")
    num_nodes_fn = getattr(batched_graph, "num_nodes", None)
    num_edges_fn = getattr(batched_graph, "num_edges", None)
    if not callable(num_nodes_fn) or not callable(num_edges_fn):
        raise ValueError("batched_graph must provide num_nodes() and num_edges().")

    device = _graph_device(batched_graph)
    node_counts = _count_list(batch_num_nodes_fn(), "batch_num_nodes()")
    num_graphs = len(node_counts)
    total_nodes = int(num_nodes_fn())
    if sum(node_counts) != total_nodes:
        raise ValueError(
            "batch_num_nodes() sums to {}, but batched_graph.num_nodes() is {}.".format(
                sum(node_counts),
                total_nodes,
            )
        )
    batch_num_edges_fn = getattr(batched_graph, "batch_num_edges", None)
    edges_fn = getattr(batched_graph, "edges", None)
    if not callable(batch_num_edges_fn) or not callable(edges_fn):
        raise ValueError(
            "batched_graph must provide batch_num_edges() and edges(order='eid')."
        )

    edge_counts = _count_list(batch_num_edges_fn(), "batch_num_edges()")
    if len(edge_counts) != num_graphs:
        raise ValueError(
            "batch_num_edges() returned {} graph counts, expected {}.".format(
                len(edge_counts),
                num_graphs,
            )
        )

    total_edges = int(num_edges_fn())
    if sum(edge_counts) != total_edges:
        raise ValueError(
            "batch_num_edges() sums to {}, but batched_graph.num_edges() is {}.".format(
                sum(edge_counts),
                total_edges,
            )
        )
    if eligible_edge_mask is not None:
        if not torch.is_tensor(eligible_edge_mask):
            raise TypeError("eligible_edge_mask must be a torch.Tensor.")
        if eligible_edge_mask.dtype != torch.bool:
            raise TypeError(
                "eligible_edge_mask must have dtype=torch.bool, got "
                f"{eligible_edge_mask.dtype}."
            )
        if eligible_edge_mask.shape != (total_edges,):
            raise ValueError(
                "eligible_edge_mask must have shape "
                f"[{total_edges}], got {tuple(eligible_edge_mask.shape)}."
            )
        if eligible_edge_mask.device != device:
            raise ValueError(
                "eligible_edge_mask device does not match batched_graph device."
            )

    if total_nodes == 0:
        if total_edges != 0:
            raise ValueError("A zero-node batch cannot contain edges.")
        return _empty_mask_result(
            device,
            num_graphs,
            node_mask_ratio,
            edge_mask_ratio,
            negative_edge_ratio,
            directed_edges,
        )

    batch_topology_cache = getattr(
        batched_graph,
        BATCH_TOPOLOGY_CACHE_ATTR,
        None,
    )
    if batch_topology_cache is None:
        batch_records = _build_uncached_batch_topology(
            batched_graph,
            node_counts,
            edge_counts,
        )
    else:
        batch_records = _validate_batch_topology_cache(
            batch_topology_cache,
            node_counts,
            edge_counts,
        )

    values = {name: [] for name in _INDEX_FIELDS}

    for graph_id, topology in enumerate(batch_records):
        node_count = topology["node_count"]
        edge_count = topology["edge_count"]
        if node_count == 0:
            if edge_count != 0:
                raise ValueError(
                    f"Graph {graph_id} has zero nodes but {edge_count} edges."
                )
            continue

        node_offset = topology["node_offset"]
        edge_offset = topology["edge_offset"]
        edge_end = edge_offset + edge_count
        graph_nodes = topology["graph_nodes"]
        graph_edge_ids = topology["graph_edge_ids"]
        graph_edge_pairs = topology["graph_edge_pairs"]
        pair_to_edge_ids = topology["pair_to_edge_ids"]
        adjacency = topology["adjacency"]
        existing_undirected_pairs = topology["existing_undirected_pairs"]
        if eligible_edge_mask is None:
            eligible_graph_edge_ids = list(graph_edge_ids)
        else:
            eligible_graph_edge_ids = [
                edge_id
                for edge_id in graph_edge_ids
                if bool(eligible_edge_mask[edge_id].item())
            ]
        center_node = graph_nodes[_random_index(len(graph_nodes), generator)]

        node_distances = _bfs_distances(graph_nodes, adjacency, center_node)
        ordered_nodes = _order_by_distance(
            [(node_distances[node], node) for node in graph_nodes],
            generator,
        )
        target_masked_nodes = _mask_count(
            node_count,
            node_mask_ratio,
            min_mask_nodes,
        )
        masked_nodes = ordered_nodes[:target_masked_nodes]

        target_masked_directed_edges = _mask_count(
            len(eligible_graph_edge_ids),
            edge_mask_ratio,
            min_mask_edges,
        )
        pair_distance_records = []
        for pair, directed_edge_ids in pair_to_edge_ids.items():
            eligible_pair_edge_ids = [
                edge_id
                for edge_id in directed_edge_ids
                if edge_id in eligible_graph_edge_ids
            ]
            if not eligible_pair_edge_ids:
                continue
            src, dst = pair
            src_distance = node_distances.get(src)
            dst_distance = node_distances.get(dst)
            if src_distance is None:
                edge_distance = dst_distance
            elif dst_distance is None:
                edge_distance = src_distance
            else:
                edge_distance = min(src_distance, dst_distance)
            pair_distance_records.append(
                (
                    edge_distance,
                    (pair, eligible_pair_edge_ids),
                )
            )
        ordered_edge_pairs = _order_by_distance(
            pair_distance_records,
            generator,
        )
        masked_edges = []
        for _, directed_edge_ids in ordered_edge_pairs:
            if len(masked_edges) >= target_masked_directed_edges:
                break
            masked_edges.extend(directed_edge_ids)

        if any(edge_id < edge_offset or edge_id >= edge_end for edge_id in masked_edges):
            raise RuntimeError(
                f"Masked edge IDs for graph {graph_id} escape the graph edge range."
            )
        negative_edges = _sample_negative_edges(
            graph_nodes,
            existing_undirected_pairs,
            len(masked_edges),
            negative_edge_ratio,
            generator,
        )

        values["center_node_indices"].append(center_node)
        values["candidate_node_indices"].extend(graph_nodes)
        values["candidate_node_graph_ids"].extend([graph_id] * len(graph_nodes))
        values["candidate_edge_indices"].extend(eligible_graph_edge_ids)
        values["candidate_edge_graph_ids"].extend(
            [graph_id] * len(eligible_graph_edge_ids)
        )
        values["masked_node_indices"].extend(masked_nodes)
        values["masked_node_graph_ids"].extend([graph_id] * len(masked_nodes))
        values["masked_edge_indices"].extend(masked_edges)
        values["masked_edge_graph_ids"].extend([graph_id] * len(masked_edges))

        positive_edge_pairs = [
            graph_edge_pairs[edge_id - edge_offset]
            for edge_id in masked_edges
        ]
        positive_src = [src for src, _ in positive_edge_pairs]
        positive_dst = [dst for _, dst in positive_edge_pairs]
        values["positive_edge_src"].extend(positive_src)
        values["positive_edge_dst"].extend(positive_dst)
        values["positive_edge_ids"].extend(masked_edges)
        values["positive_edge_graph_ids"].extend(
            [graph_id] * len(masked_edges)
        )
        values["negative_edge_src"].extend(
            src for src, _ in negative_edges
        )
        values["negative_edge_dst"].extend(
            dst for _, dst in negative_edges
        )
        values["negative_edge_graph_ids"].extend(
            [graph_id] * len(negative_edges)
        )

    result = {
        name: torch.tensor(items, dtype=torch.long, device=device)
        if items
        else _empty_long(device)
        for name, items in values.items()
    }
    result.update(
        {
            "mask_policy": MASK_POLICY,
            "mask_scope": MASK_SCOPE,
            "num_graphs": int(num_graphs),
            "node_mask_ratio": float(node_mask_ratio),
            "edge_mask_ratio": float(edge_mask_ratio),
            "negative_edge_ratio": float(negative_edge_ratio),
            "directed_edges": bool(directed_edges),
            "num_candidate_nodes": int(result["candidate_node_indices"].numel()),
            "num_candidate_edges": int(result["candidate_edge_indices"].numel()),
            "num_masked_nodes": int(result["masked_node_indices"].numel()),
            "num_masked_edges": int(result["masked_edge_indices"].numel()),
        }
    )
    return result
