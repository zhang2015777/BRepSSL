

import torch
from torch import nn


class DropPath(nn.Module):
    

    def __init__(self, drop_prob=0.0):
        super().__init__()
        if drop_prob < 0 or drop_prob >= 1:
            raise ValueError("drop_prob must be in [0,1)")
        self.drop_prob = float(drop_prob)

    def forward(self, value):
        if self.drop_prob == 0.0 or not self.training or value.numel() == 0:
            return value
        keep_prob = 1.0 - self.drop_prob
        shape = (value.shape[0],) + (1,) * (value.ndim - 1)
        keep_mask = value.new_empty(shape).bernoulli_(keep_prob)
        return value * keep_mask / keep_prob


class Scale(nn.Module):
    

    def __init__(self, dim, init_value=1.0, trainable=True):
        super().__init__()
        self.scale = nn.Parameter(
            init_value * torch.ones(dim),
            requires_grad=trainable,
        )

    def forward(self, value):
        return value * self.scale


class MLP(nn.Module):
    def __init__(
        self,
        num_layers,
        input_dim,
        hidden_dim,
        output_dim,
        norm=nn.LayerNorm,
        last_norm=False,
        act=nn.Mish,
    ):
        super().__init__()
        if num_layers < 1:
            raise ValueError("num_layers must be positive")
        self.num_layers = num_layers
        self.last_norm = last_norm
        self.activation = act()
        if num_layers == 1:
            self.linears = nn.ModuleList([nn.Linear(input_dim, output_dim)])
            self.norms = nn.ModuleList()
        else:
            self.linears = nn.ModuleList(
                [nn.Linear(input_dim, hidden_dim, bias=False)]
                + [
                    nn.Linear(hidden_dim, hidden_dim, bias=False)
                    for _ in range(num_layers - 2)
                ]
                + [nn.Linear(hidden_dim, output_dim)]
            )
            self.norms = nn.ModuleList(
                [norm(hidden_dim) for _ in range(num_layers - 1)]
            )
        self.post_norm = norm(output_dim) if last_norm else nn.Identity()
        self.apply(self._initialize)

    @staticmethod
    def _initialize(module):
        if isinstance(module, nn.Linear):
            torch.nn.init.kaiming_uniform_(module.weight)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)

    def forward(self, value):
        for index, linear in enumerate(self.linears[:-1]):
            value = self.activation(self.norms[index](linear(value)))
        value = self.linears[-1](value)
        return self.post_norm(value)


class EdgeMPNN(nn.Module):
    

    def __init__(
        self,
        node_dim,
        edge_dim,
        mlp_ratio=4,
        drop=0.0,
        drop_path=0.0,
    ):
        super().__init__()
        if node_dim <= 0 or edge_dim <= 0:
            raise ValueError("node_dim and edge_dim must be positive")
        if mlp_ratio <= 0:
            raise ValueError("mlp_ratio must be positive")
        if drop < 0 or drop >= 1:
            raise ValueError("drop must be in [0,1)")
        self.node_dim = int(node_dim)
        self.edge_dim = int(edge_dim)

        self.proj = MLP(1, node_dim, 0, edge_dim)
        self.norm_drop = nn.Sequential(
            nn.BatchNorm1d(edge_dim),
            nn.Dropout(drop),
        )
        self.norm1 = nn.LayerNorm(edge_dim)
        self.drop_path1 = (
            DropPath(drop_path) if drop_path > 0 else nn.Identity()
        )
        self.layer_scale1 = Scale(edge_dim)
        self.res_scale1 = Scale(edge_dim)
        self.norm2 = nn.LayerNorm(edge_dim)
        self.mlp = MLP(
            2,
            edge_dim,
            edge_dim * mlp_ratio,
            edge_dim,
            nn.LayerNorm,
            False,
            nn.Mish,
        )
        self.drop_path2 = (
            DropPath(drop_path) if drop_path > 0 else nn.Identity()
        )
        self.layer_scale2 = Scale(edge_dim)
        self.res_scale2 = Scale(edge_dim)

    def message_passing(self, graph, node_feat, edge_feat):
        source, destination = graph.edges(order="eid")
        projected_node = self.proj(node_feat)
        endpoint_message = projected_node.index_select(
            0, source
        ) + projected_node.index_select(0, destination)
        return self.norm_drop(edge_feat + endpoint_message)

    def forward(self, graph, node_feat, edge_feat):
        if node_feat.shape != (graph.num_nodes(), self.node_dim):
            raise ValueError("EdgeMPNN node feature shape mismatch")
        if edge_feat.shape != (graph.num_edges(), self.edge_dim):
            raise ValueError("EdgeMPNN edge feature shape mismatch")
        if graph.num_edges() == 0:
            return edge_feat.clone()

        edge_feat = self.res_scale1(edge_feat) + self.layer_scale1(
            self.drop_path1(
                self.message_passing(
                    graph,
                    node_feat,
                    self.norm1(edge_feat),
                )
            )
        )
        edge_feat = self.res_scale2(edge_feat) + self.layer_scale2(
            self.drop_path2(self.mlp(self.norm2(edge_feat)))
        )
        return edge_feat
