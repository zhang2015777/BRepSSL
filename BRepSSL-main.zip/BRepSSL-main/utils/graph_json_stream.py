import json
import hashlib
import os
from pathlib import Path


DEFAULT_CHUNK_SIZE = 1024 * 1024


class StreamingTopLevelJsonArrayWriter:
    

    def __init__(self, path, *, ensure_ascii=False):
        self.path = Path(path)
        self.ensure_ascii = bool(ensure_ascii)
        self._stream = None
        self._record_count = 0
        self._closed = False

    @property
    def record_count(self):
        return self._record_count

    def __enter__(self):
        if self._stream is not None or self._closed:
            raise RuntimeError("streaming JSON writer cannot be reopened")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._stream = self.path.open("w", encoding="utf-8", newline="\n")
        self._stream.write("[")
        return self

    def write(self, record):
        if self._stream is None or self._closed:
            raise RuntimeError("streaming JSON writer is not open")
        if self._record_count:
            self._stream.write(",")
        json.dump(
            record,
            self._stream,
            ensure_ascii=self.ensure_ascii,
            separators=(",", ":"),
            allow_nan=False,
        )
        self._record_count += 1

    def close(self):
        if self._closed:
            return
        if self._stream is None:
            raise RuntimeError("streaming JSON writer was not opened")
        self._stream.write("]")
        self._stream.flush()
        os.fsync(self._stream.fileno())
        self._stream.close()
        self._stream = None
        self._closed = True

    def __exit__(self, exc_type, exc, traceback):
        if exc_type is None:
            self.close()
            return False
        if self._stream is not None:
            self._stream.close()
            self._stream = None
        self._closed = True
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass
        return False


def write_top_level_json_array_streaming(
    path,
    records,
    *,
    ensure_ascii=False,
):
    
    with StreamingTopLevelJsonArrayWriter(
        path,
        ensure_ascii=ensure_ascii,
    ) as writer:
        for record in records:
            writer.write(record)
    return writer.record_count


def iter_top_level_json_array(path, chunk_size=DEFAULT_CHUNK_SIZE):
    
    path = Path(path)
    if chunk_size <= 0:
        raise ValueError(f"chunk_size must be positive, got {chunk_size}")
    if not path.is_file():
        raise FileNotFoundError(f"JSON file not found: {path}")

    decoder = json.JSONDecoder()
    buffer = ""
    position = 0
    eof = False

    with path.open("r", encoding="utf-8") as stream:
        def read_more():
            nonlocal buffer, eof
            chunk = stream.read(chunk_size)
            if chunk:
                buffer += chunk
                return True
            eof = True
            return False

        def compact():
            nonlocal buffer, position
            if position:
                buffer = buffer[position:]
                position = 0

        def skip_whitespace():
            nonlocal position
            while True:
                while position < len(buffer) and buffer[position].isspace():
                    position += 1
                if position < len(buffer) or eof:
                    return
                compact()
                read_more()

        read_more()
        skip_whitespace()
        if position >= len(buffer) or buffer[position] != "[":
            raise ValueError(f"{path}: top-level JSON value must be an array")
        position += 1
        expect_value = True
        allow_array_end = True

        while True:
            skip_whitespace()
            if position >= len(buffer):
                if eof:
                    raise ValueError(f"{path}: truncated JSON array")
                compact()
                read_more()
                continue

            current = buffer[position]
            if expect_value:
                if current == "]":
                    if not allow_array_end:
                        raise ValueError(
                            f"{path}: trailing comma is not valid JSON"
                        )
                    position += 1
                    break
                while True:
                    try:
                        item, end_position = decoder.raw_decode(buffer, position)
                        position = end_position
                        break
                    except json.JSONDecodeError as exc:
                        if eof:
                            raise ValueError(
                                f"{path}: invalid or truncated JSON item: {exc}"
                            ) from exc
                        compact()
                        read_more()
                yield item
                expect_value = False
                allow_array_end = True
            else:
                if current == ",":
                    position += 1
                    expect_value = True
                    allow_array_end = False
                elif current == "]":
                    position += 1
                    break
                else:
                    raise ValueError(
                        f"{path}: expected ',' or ']' after top-level item "
                        f"at decoded character {position}"
                    )

            if position > chunk_size:
                compact()

        while True:
            skip_whitespace()
            if position < len(buffer):
                raise ValueError(
                    f"{path}: unexpected content after top-level JSON array"
                )
            if eof:
                break
            compact()
            read_more()


def validate_graph_record(item, item_index, source):
    if not (
        isinstance(item, list)
        and len(item) == 2
        and isinstance(item[0], str)
        and isinstance(item[1], dict)
    ):
        raise ValueError(
            f"{source}: item {item_index} must be [part_id, graph_data], "
            f"actual_type={type(item).__name__}"
        )
    return item[0], item[1]


def iter_graph_records(path, chunk_size=DEFAULT_CHUNK_SIZE):
    seen_ids = set()
    for item_index, item in enumerate(
        iter_top_level_json_array(path, chunk_size=chunk_size)
    ):
        part_id, graph_data = validate_graph_record(item, item_index, path)
        if part_id in seen_ids:
            raise ValueError(
                f"{path}: duplicate part_id={part_id!r} at item {item_index}"
            )
        seen_ids.add(part_id)
        yield part_id, graph_data


def stream_graph_part_ids(path, chunk_size=DEFAULT_CHUNK_SIZE):
    return tuple(
        part_id
        for part_id, _ in iter_graph_records(path, chunk_size=chunk_size)
    )


def validate_graphs_json_streaming(
    path,
    *,
    expected_count,
    expected_part_ids,
    chunk_size=DEFAULT_CHUNK_SIZE,
):
    if (
        isinstance(expected_count, bool)
        or not isinstance(expected_count, int)
        or expected_count < 0
    ):
        raise ValueError("expected_count must be a non-negative integer")
    expected_ids = tuple(expected_part_ids)
    if len(expected_ids) != expected_count:
        raise ValueError(
            "expected_part_ids length must equal expected_count: "
            f"{len(expected_ids)} != {expected_count}"
        )
    if any(not isinstance(part_id, str) or not part_id for part_id in expected_ids):
        raise ValueError("expected_part_ids must contain non-empty strings")
    if len(expected_ids) != len(set(expected_ids)):
        raise ValueError("expected_part_ids must be unique")

    actual_count = 0
    for actual_count, (part_id, _) in enumerate(
        iter_graph_records(path, chunk_size=chunk_size),
        start=1,
    ):
        expected_index = actual_count - 1
        if expected_index >= expected_count:
            raise ValueError(
                f"{path}: contains more than {expected_count} graph records"
            )
        expected_part_id = expected_ids[expected_index]
        if part_id != expected_part_id:
            raise ValueError(
                f"{path}: part ID order mismatch at record {expected_index}: "
                f"expected={expected_part_id!r}, actual={part_id!r}"
            )
    if actual_count != expected_count:
        raise ValueError(
            f"{path}: graph record count mismatch: "
            f"expected={expected_count}, actual={actual_count}"
        )
    return actual_count


def write_graph_records_atomic(path, records, *, ensure_ascii=False):
    
    path = Path(path)
    temporary = Path(str(path) + ".tmp")
    part_ids = []
    try:
        with StreamingTopLevelJsonArrayWriter(
            temporary,
            ensure_ascii=ensure_ascii,
        ) as writer:
            for item_index, item in enumerate(records):
                part_id, graph_data = validate_graph_record(
                    item,
                    item_index,
                    records,
                )
                writer.write([part_id, graph_data])
                part_ids.append(part_id)
        validate_graphs_json_streaming(
            temporary,
            expected_count=len(part_ids),
            expected_part_ids=part_ids,
        )
        os.replace(temporary, path)
    except BaseException:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise
    return tuple(part_ids)


def sha256_part_ids(part_ids):
    digest = hashlib.sha256()
    for part_id in part_ids:
        if not isinstance(part_id, str) or not part_id:
            raise ValueError(f"part_id must be a non-empty string, got {part_id!r}")
        digest.update(part_id.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()
