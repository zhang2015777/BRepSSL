import argparse
import math
import warnings


DEFAULT_MASK_RATIO = 0.6
MASK_RATIO_DEPRECATION_WARNING = (
    "--node_mask_ratio and --edge_mask_ratio are deprecated; use --mask_ratio."
)


def add_mask_ratio_arguments(
    parser_or_group,
    *,
    default_text="0.6",
    help_text=None,
):
    if help_text is None:
        help_text = (
            "Unified node and directed-edge mask ratio, default "
            f"{default_text}."
        )
    parser_or_group.add_argument(
        "--mask_ratio",
        type=float,
        default=None,
        help=help_text,
    )
    parser_or_group.add_argument(
        "--node_mask_ratio",
        type=float,
        default=None,
        help=argparse.SUPPRESS,
    )
    parser_or_group.add_argument(
        "--edge_mask_ratio",
        type=float,
        default=None,
        help=argparse.SUPPRESS,
    )


def _is_close(left, right):
    return math.isclose(
        float(left),
        float(right),
        rel_tol=0.0,
        abs_tol=1e-12,
    )


def _validate_mask_ratio(value):
    value = float(value)
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"--mask_ratio must be in [0, 1], got {value}.")
    return value


def resolve_mask_ratio_args(
    args,
    *,
    raw_args=None,
    default_mask_ratio=DEFAULT_MASK_RATIO,
    warn_deprecated=True,
):
    source = raw_args if raw_args is not None else args
    new_value = getattr(source, "mask_ratio", None)
    node_value = getattr(source, "node_mask_ratio", None)
    edge_value = getattr(source, "edge_mask_ratio", None)

    new_provided = new_value is not None
    node_provided = node_value is not None
    edge_provided = edge_value is not None

    if new_provided and (node_provided or edge_provided):
        raise ValueError(
            "--mask_ratio cannot be used together with deprecated "
            "--node_mask_ratio or --edge_mask_ratio."
        )
    if node_provided != edge_provided:
        raise ValueError(
            "Deprecated --node_mask_ratio and --edge_mask_ratio must be "
            "provided together with the same value, or use --mask_ratio."
        )

    deprecated_used = False
    if node_provided and edge_provided:
        if not _is_close(node_value, edge_value):
            raise ValueError(
                "Deprecated --node_mask_ratio and --edge_mask_ratio must "
                "have the same value; use --mask_ratio for new runs."
            )
        resolved = _validate_mask_ratio(node_value)
        source_name = "deprecated_node_edge"
        deprecated_used = True
        if warn_deprecated:
            warnings.warn(
                MASK_RATIO_DEPRECATION_WARNING,
                RuntimeWarning,
                stacklevel=2,
            )
    elif new_provided:
        resolved = _validate_mask_ratio(new_value)
        source_name = "mask_ratio"
    else:
        resolved = _validate_mask_ratio(default_mask_ratio)
        source_name = "default"

    args.mask_ratio = resolved
    args.node_mask_ratio = resolved
    args.edge_mask_ratio = resolved
    args.mask_ratio_source = source_name
    args.deprecated_mask_ratio_args_used = deprecated_used
    return resolved


def ensure_unified_mask_ratio(args):
    mask_ratio = _validate_mask_ratio(getattr(args, "mask_ratio"))
    node_ratio = float(getattr(args, "node_mask_ratio"))
    edge_ratio = float(getattr(args, "edge_mask_ratio"))
    if not _is_close(node_ratio, mask_ratio):
        raise ValueError(
            "Internal node_mask_ratio must equal mask_ratio; got "
            f"{node_ratio} vs {mask_ratio}."
        )
    if not _is_close(edge_ratio, mask_ratio):
        raise ValueError(
            "Internal edge_mask_ratio must equal mask_ratio; got "
            f"{edge_ratio} vs {mask_ratio}."
        )
    args.mask_ratio = mask_ratio
    args.node_mask_ratio = mask_ratio
    args.edge_mask_ratio = mask_ratio
    return mask_ratio


def normalize_checkpoint_mask_config(
    config,
    *,
    default_mask_ratio=DEFAULT_MASK_RATIO,
    strict_unified=False,
):
    has_mask_ratio = config.get("mask_ratio") is not None
    has_node_ratio = config.get("node_mask_ratio") is not None
    has_edge_ratio = config.get("edge_mask_ratio") is not None

    if has_mask_ratio:
        mask_ratio = _validate_mask_ratio(config["mask_ratio"])
        for name in ("node_mask_ratio", "edge_mask_ratio"):
            value = config.get(name)
            if value is not None and not _is_close(value, mask_ratio):
                raise ValueError(
                    f"Checkpoint {name}={value} does not match "
                    f"mask_ratio={mask_ratio}."
                )
        config["mask_ratio"] = mask_ratio
        config["node_mask_ratio"] = mask_ratio
        config["edge_mask_ratio"] = mask_ratio
        config["mask_ratio_source"] = "checkpoint_mask_ratio"
        config["legacy_non_unified_mask_ratio"] = False
        return config

    if has_node_ratio and has_edge_ratio:
        node_ratio = _validate_mask_ratio(config["node_mask_ratio"])
        edge_ratio = _validate_mask_ratio(config["edge_mask_ratio"])
        if _is_close(node_ratio, edge_ratio):
            config["mask_ratio"] = node_ratio
            config["node_mask_ratio"] = node_ratio
            config["edge_mask_ratio"] = node_ratio
            config["mask_ratio_source"] = "legacy_equal_node_edge"
            config["legacy_non_unified_mask_ratio"] = False
            return config
        if strict_unified:
            raise ValueError(
                "Checkpoint uses legacy non-unified mask ratios: "
                f"node_mask_ratio={node_ratio}, edge_mask_ratio={edge_ratio}."
            )
        config["mask_ratio"] = None
        config["node_mask_ratio"] = node_ratio
        config["edge_mask_ratio"] = edge_ratio
        config["mask_ratio_source"] = "legacy_non_unified_node_edge"
        config["legacy_non_unified_mask_ratio"] = True
        return config

    if has_node_ratio != has_edge_ratio:
        raise ValueError(
            "Checkpoint mask metadata must include both node_mask_ratio and "
            "edge_mask_ratio, or a unified mask_ratio."
        )

    mask_ratio = _validate_mask_ratio(default_mask_ratio)
    config["mask_ratio"] = mask_ratio
    config["node_mask_ratio"] = mask_ratio
    config["edge_mask_ratio"] = mask_ratio
    config["mask_ratio_source"] = "default"
    config["legacy_non_unified_mask_ratio"] = False
    return config
