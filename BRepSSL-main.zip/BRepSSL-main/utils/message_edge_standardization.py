

from collections.abc import Mapping
from dataclasses import dataclass, replace

import torch

from utils.physical_edge_message_adapter import PhysicalEdgeMessageView


EDGE_ATTR_DIM = 16
MESSAGE_EDGE_GRID_SHAPE = (16, 5)
MESSAGE_EDGE_FACE_UV_SHAPE = (2, 5, 2)
MESSAGE_EDGE_FACE_UV_VALID_SHAPE = (2, 5)
EDGE_STANDARDIZED_CHANNELS = (12, 14, 15)
SAFE_STD_EPSILON = 1e-8
TANGENT_VALID_EPSILON = 1e-12


@dataclass(frozen=True)
class DirectedMessageEdgeStatistics:
    edge_attr_mean: torch.Tensor
    edge_attr_std: torch.Tensor
    raw_edge_attr_std: torch.Tensor
    curve_curvature_mean: torch.Tensor
    curve_curvature_std: torch.Tensor
    raw_curve_curvature_std: torch.Tensor
    side_normal_curvature_mean: torch.Tensor
    side_normal_curvature_std: torch.Tensor
    raw_side_normal_curvature_std: torch.Tensor
    curve_curvature_count: int
    src_count: int
    dst_count: int
    pooled_count: int


def _require_mapping(name, value):
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping")


def _float_vector(mapping, key, length, device):
    if key not in mapping:
        raise KeyError(f"Missing required statistics key {key!r}")
    try:
        value = torch.as_tensor(mapping[key]).detach().clone()
    except (TypeError, ValueError, RuntimeError) as exc:
        raise TypeError(f"{key} must contain numeric values") from exc
    if value.shape != (length,):
        raise ValueError(
            f"{key} must have shape [{length}], got {tuple(value.shape)}"
        )
    if value.dtype == torch.bool or not (
        value.dtype.is_floating_point
        or value.dtype
        in (
            torch.int8,
            torch.int16,
            torch.int32,
            torch.int64,
            torch.uint8,
        )
    ):
        raise TypeError(f"{key} must contain real numeric values")
    value = value.to(device=device, dtype=torch.float64)
    if not torch.all(torch.isfinite(value)):
        raise ValueError(f"{key} contains NaN or Inf")
    return value


def _positive_integer_counts(mapping, key, length):
    if key not in mapping:
        raise KeyError(f"Missing required statistics key {key!r}")
    try:
        value = torch.as_tensor(mapping[key]).detach().clone()
    except (TypeError, ValueError, RuntimeError) as exc:
        raise TypeError(f"{key} must contain integer counts") from exc
    if value.shape != (length,):
        raise ValueError(
            f"{key} must have shape [{length}], got {tuple(value.shape)}"
        )
    if value.dtype == torch.bool:
        raise TypeError(f"{key} must contain positive integers")
    value_float = value.to(dtype=torch.float64)
    if not torch.all(torch.isfinite(value_float)):
        raise ValueError(f"{key} contains NaN or Inf")
    if torch.any(value_float <= 0):
        raise ValueError(f"{key} values must be positive")
    if torch.any(value_float != torch.round(value_float)):
        raise ValueError(f"{key} values must be integers")
    return tuple(int(item) for item in value_float.tolist())


def _safe_std(raw_std):
    return torch.where(
        raw_std < SAFE_STD_EPSILON,
        torch.ones_like(raw_std),
        raw_std,
    )


def _resolve_raw_and_safe_std(
    mapping,
    safe_key,
    raw_key,
    length,
    device,
):
    safe_input = _float_vector(mapping, safe_key, length, device)
    if torch.any(safe_input < 0):
        raise ValueError(f"{safe_key} contains negative values")

    if raw_key not in mapping:
        raw_std = safe_input
        return raw_std, _safe_std(raw_std)

    raw_std = _float_vector(mapping, raw_key, length, device)
    if torch.any(raw_std < 0):
        raise ValueError(f"{raw_key} contains negative values")
    expected_safe_std = _safe_std(raw_std)
    if not torch.allclose(
        safe_input,
        expected_safe_std,
        rtol=1e-6,
        atol=1e-8,
    ):
        raise ValueError(
            f"{safe_key} is inconsistent with safe({raw_key}); "
            f"expected={expected_safe_std.tolist()}, "
            f"actual={safe_input.tolist()}"
        )
    return raw_std, expected_safe_std


def resolve_directed_message_edge_statistics(
    attr_stat,
    uv_stat,
    *,
    device=None,
    dtype=torch.float32,
):
    
    _require_mapping("attr_stat", attr_stat)
    _require_mapping("uv_stat", uv_stat)
    if not isinstance(dtype, torch.dtype) or not dtype.is_floating_point:
        raise TypeError(f"dtype must be a floating torch.dtype, got {dtype!r}")
    output_device = torch.device("cpu") if device is None else torch.device(device)

    if uv_stat.get("std_ddof") != 0:
        raise ValueError(
            f"uv_stat std_ddof must be 0, got {uv_stat.get('std_ddof')!r}"
        )
    channels = uv_stat.get("edge_standardized_channels")
    try:
        channels = tuple(channels)
    except TypeError as exc:
        raise TypeError(
            "edge_standardized_channels must be [12,14,15]"
        ) from exc
    if channels != EDGE_STANDARDIZED_CHANNELS:
        raise ValueError(
            "edge_standardized_channels must be exactly [12,14,15], "
            f"got {list(channels)}"
        )

    edge_attr_mean64 = _float_vector(
        attr_stat, "mean_edge_attr", EDGE_ATTR_DIM, output_device
    )
    raw_edge_attr_std64, safe_edge_attr_std64 = (
        _resolve_raw_and_safe_std(
            attr_stat,
            "std_edge_attr",
            "raw_std_edge_attr",
            EDGE_ATTR_DIM,
            output_device,
        )
    )
    edge_grid_mean64 = _float_vector(
        uv_stat, "mean_edge_grid", 3, output_device
    )
    raw_edge_grid_std64, safe_edge_grid_std64 = (
        _resolve_raw_and_safe_std(
            uv_stat,
            "std_edge_grid",
            "raw_std_edge_grid",
            3,
            output_device,
        )
    )

    curve_count, src_count, dst_count = _positive_integer_counts(
        uv_stat, "count_edge_grid", 3
    )
    pooled_count = src_count + dst_count
    src_mean = edge_grid_mean64[1]
    dst_mean = edge_grid_mean64[2]
    src_std = raw_edge_grid_std64[1]
    dst_std = raw_edge_grid_std64[2]
    pooled_mean = (
        src_count * src_mean + dst_count * dst_mean
    ) / pooled_count
    pooled_variance = (
        src_count
        * (src_std.square() + (src_mean - pooled_mean).square())
        + dst_count
        * (dst_std.square() + (dst_mean - pooled_mean).square())
    ) / pooled_count
    pooled_raw_std = torch.sqrt(torch.clamp(pooled_variance, min=0.0))

    raw_edge_attr_std = raw_edge_attr_std64.to(dtype=dtype)
    raw_curve_std = raw_edge_grid_std64[0].to(dtype=dtype)
    raw_side_std = pooled_raw_std.to(dtype=dtype)
    return DirectedMessageEdgeStatistics(
        edge_attr_mean=edge_attr_mean64.to(dtype=dtype),
        edge_attr_std=safe_edge_attr_std64.to(dtype=dtype),
        raw_edge_attr_std=raw_edge_attr_std,
        curve_curvature_mean=edge_grid_mean64[0].to(dtype=dtype),
        curve_curvature_std=safe_edge_grid_std64[0].to(dtype=dtype),
        raw_curve_curvature_std=raw_curve_std,
        side_normal_curvature_mean=pooled_mean.to(dtype=dtype),
        side_normal_curvature_std=_safe_std(raw_side_std),
        raw_side_normal_curvature_std=raw_side_std,
        curve_curvature_count=curve_count,
        src_count=src_count,
        dst_count=dst_count,
        pooled_count=pooled_count,
    )


def _validate_message_view(message_view, statistics):
    if not isinstance(message_view, PhysicalEdgeMessageView):
        raise TypeError(
            "message_view must be a PhysicalEdgeMessageView built from raw "
            "physical-edge features"
        )
    if not isinstance(statistics, DirectedMessageEdgeStatistics):
        raise TypeError(
            "statistics must be DirectedMessageEdgeStatistics"
        )

    message_count = message_view.message_graph.num_edges()
    tensors_and_shapes = (
        (
            "message_edge_attr",
            message_view.message_edge_attr,
            (message_count, EDGE_ATTR_DIM),
            torch.float32,
        ),
        (
            "message_edge_grid",
            message_view.message_edge_grid,
            (message_count,) + MESSAGE_EDGE_GRID_SHAPE,
            torch.float32,
        ),
        (
            "message_edge_face_uv",
            message_view.message_edge_face_uv,
            (message_count,) + MESSAGE_EDGE_FACE_UV_SHAPE,
            torch.float32,
        ),
        (
            "message_edge_face_uv_valid",
            message_view.message_edge_face_uv_valid,
            (message_count,) + MESSAGE_EDGE_FACE_UV_VALID_SHAPE,
            torch.bool,
        ),
    )
    for name, value, shape, dtype in tensors_and_shapes:
        if not isinstance(value, torch.Tensor):
            raise TypeError(f"{name} must be a torch.Tensor")
        if value.shape != shape:
            raise ValueError(
                f"{name} must have shape {shape}, got {tuple(value.shape)}"
            )
        if value.dtype != dtype:
            raise TypeError(
                f"{name} must have dtype={dtype}, got {value.dtype}"
            )
        if value.device != message_view.message_graph.device:
            raise ValueError(
                f"{name} device does not match message_graph device"
            )
        if dtype != torch.bool and not torch.all(torch.isfinite(value)):
            raise ValueError(f"{name} contains NaN or Inf")

    statistics_tensors = (
        statistics.edge_attr_mean,
        statistics.edge_attr_std,
        statistics.curve_curvature_mean,
        statistics.curve_curvature_std,
        statistics.side_normal_curvature_mean,
        statistics.side_normal_curvature_std,
    )
    for value in statistics_tensors:
        if value.device != message_view.message_edge_grid.device:
            raise ValueError(
                "Statistics and message tensors must be on the same device"
            )
        if value.dtype != message_view.message_edge_grid.dtype:
            raise TypeError(
                "Statistics dtype must match message tensor dtype"
            )
        if not torch.all(torch.isfinite(value)):
            raise ValueError("Resolved statistics contain NaN or Inf")
    if torch.any(statistics.edge_attr_std <= 0):
        raise ValueError("edge_attr_std must be positive")
    if statistics.curve_curvature_std <= 0:
        raise ValueError("curve_curvature_std must be positive")
    if statistics.side_normal_curvature_std <= 0:
        raise ValueError("side_normal_curvature_std must be positive")


def standardize_message_edge_view(message_view, statistics):
    
    _validate_message_view(message_view, statistics)

    standardized_attr = (
        message_view.message_edge_attr - statistics.edge_attr_mean
    ) / statistics.edge_attr_std
    standardized_grid = message_view.message_edge_grid.clone()

    tangent_valid = (
        torch.linalg.vector_norm(
            message_view.message_edge_grid[:, 3:6, :], dim=1
        )
        > TANGENT_VALID_EPSILON
    )
    channel_12 = standardized_grid[:, 12, :]
    channel_12.zero_()
    channel_12[tangent_valid] = (
        message_view.message_edge_grid[:, 12, :][tangent_valid]
        - statistics.curve_curvature_mean
    ) / statistics.curve_curvature_std

    side_validity = (
        message_view.message_edge_face_uv_valid[:, 0, :],
        message_view.message_edge_face_uv_valid[:, 1, :],
    )
    for channel, valid in zip((14, 15), side_validity):
        output = standardized_grid[:, channel, :]
        output.zero_()
        output[valid] = (
            message_view.message_edge_grid[:, channel, :][valid]
            - statistics.side_normal_curvature_mean
        ) / statistics.side_normal_curvature_std

    if not torch.all(torch.isfinite(standardized_attr)):
        raise ValueError("Standardized message_edge_attr contains NaN or Inf")
    if not torch.all(torch.isfinite(standardized_grid)):
        raise ValueError("Standardized message_edge_grid contains NaN or Inf")

    return replace(
        message_view,
        message_edge_attr=standardized_attr,
        message_edge_grid=standardized_grid,
    )
