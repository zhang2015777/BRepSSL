

from collections.abc import Mapping
from dataclasses import dataclass, replace

import dgl
import torch

from utils.physical_edge_message_adapter import (
    PhysicalEdgeMessageView,
    build_physical_edge_message_view,
)
from utils.message_edge_standardization import (
    DirectedMessageEdgeStatistics,
    resolve_directed_message_edge_statistics,
    standardize_message_edge_view,
)


FACE_ATTR_DIM = 16
FACE_GRID_SHAPE = (11, 5, 5)
EDGE_ATTR_DIM = 16
EDGE_GRID_SHAPE = (16, 5)
EDGE_FACE_UV_SHAPE = (2, 5, 2)
EDGE_FACE_UV_VALID_SHAPE = (2, 5)
FACE_STANDARDIZED_CHANNELS = (6, 7, 9)
SAFE_STD_EPSILON = 1e-8
UV_BOUND_TOLERANCE = 1e-6


@dataclass(frozen=True)
class BRepModelInputStatistics:
    face_attr_mean: torch.Tensor
    face_attr_std: torch.Tensor
    raw_face_attr_std: torch.Tensor
    face_grid_mean: torch.Tensor
    face_grid_std: torch.Tensor
    raw_face_grid_std: torch.Tensor
    face_grid_count: tuple[int, int, int]
    message_edge_statistics: DirectedMessageEdgeStatistics


@dataclass(frozen=True)
class BRepModelInputView:
    node_attr: torch.Tensor
    node_grid: torch.Tensor
    message_view: PhysicalEdgeMessageView
    physical_num_nodes: int
    physical_num_edges: int
    physical_batch_num_nodes: torch.Tensor
    physical_batch_num_edges: torch.Tensor


def iter_brep_model_input_tensors(model_input):
    
    if not isinstance(model_input, BRepModelInputView):
        raise TypeError("model_input must be a BRepModelInputView")
    message_view = model_input.message_view
    yield model_input.node_attr
    yield model_input.node_grid
    yield model_input.physical_batch_num_nodes
    yield model_input.physical_batch_num_edges
    yield message_view.message_edge_attr
    yield message_view.message_edge_grid
    yield message_view.message_edge_face_uv
    yield message_view.message_edge_face_uv_valid
    yield message_view.message_to_physical_edge
    yield message_view.message_is_reverse
    yield message_view.message_is_self_loop
    yield message_view.physical_to_forward_message
    yield message_view.physical_to_reverse_message


def validate_brep_model_input_device(model_input, device):
    
    device = torch.device(device)
    if model_input.message_view.message_graph.device != device:
        raise ValueError("message_graph is not on the requested device")
    for tensor in iter_brep_model_input_tensors(model_input):
        if tensor.device != device:
            raise ValueError(
                "BRepModelInputView contains a tensor on a different device"
            )


def pin_brep_model_input_view(model_input):
    
    if not isinstance(model_input, BRepModelInputView):
        raise TypeError("model_input must be a BRepModelInputView")
    message_view = model_input.message_view
    message_graph = message_view.message_graph
    if message_graph.device.type != "cpu":
        raise ValueError("Only CPU model input views can be pinned")
    if not message_graph.is_pinned():
        message_graph.pin_memory_()

    def pin_tensor(value):
        if value.device.type != "cpu":
            raise ValueError("Only CPU tensors can be pinned")
        return value if value.is_pinned() else value.pin_memory()

    pinned_message_view = replace(
        message_view,
        message_graph=message_graph,
        message_edge_attr=pin_tensor(message_view.message_edge_attr),
        message_edge_grid=pin_tensor(message_view.message_edge_grid),
        message_edge_face_uv=pin_tensor(message_view.message_edge_face_uv),
        message_edge_face_uv_valid=pin_tensor(
            message_view.message_edge_face_uv_valid
        ),
        message_to_physical_edge=pin_tensor(
            message_view.message_to_physical_edge
        ),
        message_is_reverse=pin_tensor(message_view.message_is_reverse),
        message_is_self_loop=pin_tensor(message_view.message_is_self_loop),
        physical_to_forward_message=pin_tensor(
            message_view.physical_to_forward_message
        ),
        physical_to_reverse_message=pin_tensor(
            message_view.physical_to_reverse_message
        ),
    )
    return replace(
        model_input,
        node_attr=pin_tensor(model_input.node_attr),
        node_grid=pin_tensor(model_input.node_grid),
        message_view=pinned_message_view,
        physical_batch_num_nodes=pin_tensor(
            model_input.physical_batch_num_nodes
        ),
        physical_batch_num_edges=pin_tensor(
            model_input.physical_batch_num_edges
        ),
    )


def _require_mapping(name, value):
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping")


def _float_vector(mapping, key, length, device):
    if key not in mapping:
        raise KeyError(f"Missing required statistics key {key!r}")
    try:
        value = torch.as_tensor(mapping[key]).detach().clone()
    except (TypeError, ValueError, RuntimeError) as exc:
        raise TypeError(f"{key} must contain numeric values") from exc
    if value.shape != (length,):
        raise ValueError(
            f"{key} must have shape [{length}], got {tuple(value.shape)}"
        )
    if value.dtype == torch.bool or not (
        value.dtype.is_floating_point
        or value.dtype
        in (
            torch.int8,
            torch.int16,
            torch.int32,
            torch.int64,
            torch.uint8,
        )
    ):
        raise TypeError(f"{key} must contain real numeric values")
    value = value.to(device=device, dtype=torch.float64)
    if not torch.all(torch.isfinite(value)):
        raise ValueError(f"{key} contains NaN or Inf")
    return value


def _safe_std(raw_std):
    return torch.where(
        raw_std < SAFE_STD_EPSILON,
        torch.ones_like(raw_std),
        raw_std,
    )


def _resolve_raw_and_safe_std(
    mapping,
    safe_key,
    raw_key,
    length,
    device,
):
    safe_input = _float_vector(mapping, safe_key, length, device)
    if torch.any(safe_input < 0):
        raise ValueError(f"{safe_key} contains negative values")
    if raw_key not in mapping:
        raw_std = safe_input
        return raw_std, _safe_std(raw_std)

    raw_std = _float_vector(mapping, raw_key, length, device)
    if torch.any(raw_std < 0):
        raise ValueError(f"{raw_key} contains negative values")
    expected_safe = _safe_std(raw_std)
    if not torch.allclose(
        safe_input,
        expected_safe,
        rtol=1e-6,
        atol=1e-8,
    ):
        raise ValueError(
            f"{safe_key} is inconsistent with safe({raw_key}); "
            f"expected={expected_safe.tolist()}, actual={safe_input.tolist()}"
        )
    return raw_std, expected_safe


def _positive_integer_counts(mapping, key, length):
    if key not in mapping:
        raise KeyError(f"Missing required statistics key {key!r}")
    try:
        value = torch.as_tensor(mapping[key]).detach().clone()
    except (TypeError, ValueError, RuntimeError) as exc:
        raise TypeError(f"{key} must contain integer counts") from exc
    if value.shape != (length,):
        raise ValueError(
            f"{key} must have shape [{length}], got {tuple(value.shape)}"
        )
    if value.dtype == torch.bool:
        raise TypeError(f"{key} must contain positive integers")
    value = value.to(dtype=torch.float64)
    if not torch.all(torch.isfinite(value)):
        raise ValueError(f"{key} contains NaN or Inf")
    if torch.any(value <= 0):
        raise ValueError(f"{key} values must be positive")
    if torch.any(value != torch.round(value)):
        raise ValueError(f"{key} values must be integers")
    return tuple(int(item) for item in value.tolist())


def resolve_brep_model_input_statistics(
    attr_stat,
    uv_stat,
    *,
    device=None,
    dtype=torch.float32,
):
    
    _require_mapping("attr_stat", attr_stat)
    _require_mapping("uv_stat", uv_stat)
    if not isinstance(dtype, torch.dtype) or not dtype.is_floating_point:
        raise TypeError(f"dtype must be a floating torch.dtype, got {dtype!r}")
    output_device = torch.device("cpu") if device is None else torch.device(device)

    if uv_stat.get("std_ddof") != 0:
        raise ValueError(
            f"uv_stat std_ddof must be 0, got {uv_stat.get('std_ddof')!r}"
        )
    channels = uv_stat.get("face_standardized_channels")
    try:
        channels = tuple(channels)
    except TypeError as exc:
        raise TypeError(
            "face_standardized_channels must be [6,7,9]"
        ) from exc
    if channels != FACE_STANDARDIZED_CHANNELS:
        raise ValueError(
            "face_standardized_channels must be exactly [6,7,9], "
            f"got {list(channels)}"
        )

    face_attr_mean64 = _float_vector(
        attr_stat, "mean_face_attr", FACE_ATTR_DIM, output_device
    )
    raw_face_attr_std64, safe_face_attr_std64 = (
        _resolve_raw_and_safe_std(
            attr_stat,
            "std_face_attr",
            "raw_std_face_attr",
            FACE_ATTR_DIM,
            output_device,
        )
    )
    face_grid_mean64 = _float_vector(
        uv_stat, "mean_face_grid", 3, output_device
    )
    raw_face_grid_std64, safe_face_grid_std64 = (
        _resolve_raw_and_safe_std(
            uv_stat,
            "std_face_grid",
            "raw_std_face_grid",
            3,
            output_device,
        )
    )
    face_grid_count = _positive_integer_counts(
        uv_stat, "count_face_grid", 3
    )
    message_edge_statistics = resolve_directed_message_edge_statistics(
        attr_stat,
        uv_stat,
        device=output_device,
        dtype=dtype,
    )

    return BRepModelInputStatistics(
        face_attr_mean=face_attr_mean64.to(dtype=dtype),
        face_attr_std=safe_face_attr_std64.to(dtype=dtype),
        raw_face_attr_std=raw_face_attr_std64.to(dtype=dtype),
        face_grid_mean=face_grid_mean64.to(dtype=dtype),
        face_grid_std=safe_face_grid_std64.to(dtype=dtype),
        raw_face_grid_std=raw_face_grid_std64.to(dtype=dtype),
        face_grid_count=face_grid_count,
        message_edge_statistics=message_edge_statistics,
    )


def _require_graph_tensor(
    graph,
    storage,
    key,
    expected_shape,
    expected_dtype,
):
    if key not in storage:
        raise KeyError(f"physical_graph is missing required field {key!r}")
    value = storage[key]
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"physical_graph field {key!r} must be a tensor")
    if value.shape != expected_shape:
        raise ValueError(
            f"physical_graph field {key!r} must have shape "
            f"{expected_shape}, got {tuple(value.shape)}"
        )
    if value.dtype != expected_dtype:
        raise TypeError(
            f"physical_graph field {key!r} must have dtype="
            f"{expected_dtype}, got {value.dtype}"
        )
    if value.device != graph.device:
        raise ValueError(
            f"physical_graph field {key!r} device={value.device} "
            f"does not match graph device={graph.device}"
        )
    if expected_dtype != torch.bool and not torch.all(torch.isfinite(value)):
        raise ValueError(
            f"physical_graph field {key!r} contains NaN or Inf"
        )
    return value


def _validate_statistics_for_graph(statistics, graph):
    if not isinstance(statistics, BRepModelInputStatistics):
        raise TypeError("statistics must be a BRepModelInputStatistics")
    tensors_and_shapes = (
        ("face_attr_mean", statistics.face_attr_mean, (FACE_ATTR_DIM,)),
        ("face_attr_std", statistics.face_attr_std, (FACE_ATTR_DIM,)),
        (
            "raw_face_attr_std",
            statistics.raw_face_attr_std,
            (FACE_ATTR_DIM,),
        ),
        ("face_grid_mean", statistics.face_grid_mean, (3,)),
        ("face_grid_std", statistics.face_grid_std, (3,)),
        ("raw_face_grid_std", statistics.raw_face_grid_std, (3,)),
    )
    for name, value, shape in tensors_and_shapes:
        if not isinstance(value, torch.Tensor) or value.shape != shape:
            raise ValueError(f"statistics.{name} must have shape {shape}")
        if value.dtype != torch.float32:
            raise TypeError(f"statistics.{name} must have dtype=torch.float32")
        if value.device != graph.device:
            raise ValueError(
                f"statistics.{name} device does not match graph device"
            )
        if not torch.all(torch.isfinite(value)):
            raise ValueError(f"statistics.{name} contains NaN or Inf")
    if torch.any(statistics.face_attr_std <= 0):
        raise ValueError("statistics.face_attr_std must be positive")
    if torch.any(statistics.face_grid_std <= 0):
        raise ValueError("statistics.face_grid_std must be positive")


def build_brep_model_input_view(
    physical_graph,
    statistics,
    *,
    physical_graph_is_standardized=False,
):
    






    if not isinstance(physical_graph, dgl.DGLGraph):
        raise TypeError("physical_graph must be a dgl.DGLGraph")
    if physical_graph_is_standardized:
        raise ValueError(
            "build_brep_model_input_view only accepts raw physical graphs "
            "before attribute and UV continuous-channel standardization"
        )
    _validate_statistics_for_graph(statistics, physical_graph)

    node_count = physical_graph.num_nodes()
    edge_count = physical_graph.num_edges()
    node_attr_raw = _require_graph_tensor(
        physical_graph,
        physical_graph.ndata,
        "x",
        (node_count, FACE_ATTR_DIM),
        torch.float32,
    )
    node_grid_raw = _require_graph_tensor(
        physical_graph,
        physical_graph.ndata,
        "grid",
        (node_count,) + FACE_GRID_SHAPE,
        torch.float32,
    )
    edge_attr_raw = _require_graph_tensor(
        physical_graph,
        physical_graph.edata,
        "x",
        (edge_count, EDGE_ATTR_DIM),
        torch.float32,
    )
    edge_grid_raw = _require_graph_tensor(
        physical_graph,
        physical_graph.edata,
        "grid",
        (edge_count,) + EDGE_GRID_SHAPE,
        torch.float32,
    )
    edge_face_uv_raw = _require_graph_tensor(
        physical_graph,
        physical_graph.edata,
        "face_uv",
        (edge_count,) + EDGE_FACE_UV_SHAPE,
        torch.float32,
    )
    edge_face_uv_valid_raw = _require_graph_tensor(
        physical_graph,
        physical_graph.edata,
        "face_uv_valid",
        (edge_count,) + EDGE_FACE_UV_VALID_SHAPE,
        torch.bool,
    )

    invalid_uv = edge_face_uv_raw[~edge_face_uv_valid_raw]
    if invalid_uv.numel() and torch.any(invalid_uv != 0):
        raise ValueError(
            "physical_graph invalid face_uv positions must be exactly [0,0]"
        )
    valid_uv = edge_face_uv_raw[edge_face_uv_valid_raw]
    if valid_uv.numel() and torch.any(
        torch.abs(valid_uv) > 1.0 + UV_BOUND_TOLERANCE
    ):
        raise ValueError(
            "physical_graph valid face_uv coordinates must lie in [-1,1]"
        )

    node_attr = (
        node_attr_raw - statistics.face_attr_mean
    ) / statistics.face_attr_std
    node_grid = node_grid_raw.clone()
    for offset, channel in enumerate(FACE_STANDARDIZED_CHANNELS):
        node_grid[:, channel, :, :] = (
            node_grid_raw[:, channel, :, :]
            - statistics.face_grid_mean[offset]
        ) / statistics.face_grid_std[offset]

    raw_message_view = build_physical_edge_message_view(
        physical_graph,
        edge_attr_raw,
        edge_grid_raw,
        edge_face_uv_raw,
        edge_face_uv_valid_raw,
        edge_grid_is_standardized=False,
    )
    message_view = standardize_message_edge_view(
        raw_message_view,
        statistics.message_edge_statistics,
    )

    if not torch.all(torch.isfinite(node_attr)):
        raise ValueError("Standardized node_attr contains NaN or Inf")
    if not torch.all(torch.isfinite(node_grid)):
        raise ValueError("Standardized node_grid contains NaN or Inf")

    return BRepModelInputView(
        node_attr=node_attr,
        node_grid=node_grid,
        message_view=message_view,
        physical_num_nodes=node_count,
        physical_num_edges=edge_count,
        physical_batch_num_nodes=physical_graph.batch_num_nodes().clone(),
        physical_batch_num_edges=physical_graph.batch_num_edges().clone(),
    )
