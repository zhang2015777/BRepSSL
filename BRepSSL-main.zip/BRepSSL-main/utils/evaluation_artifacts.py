






import csv
from pathlib import Path

import numpy as np
import torch


def make_confusion_matrix(num_classes):
    num_classes = int(num_classes)
    if num_classes <= 0:
        raise ValueError("num_classes must be positive")
    return np.zeros((num_classes, num_classes), dtype=np.int64)


def update_confusion_matrix(
    confusion_matrix,
    predictions,
    targets,
    *,
    ignore_index=None,
):
    
    matrix = np.asarray(confusion_matrix)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError(
            "confusion_matrix must be square, got shape {}".format(matrix.shape)
        )
    if matrix.dtype != np.int64:
        raise TypeError("confusion_matrix must have dtype=np.int64")
    num_classes = int(matrix.shape[0])

    with torch.no_grad():
        target_ids = targets.detach().reshape(-1).to(dtype=torch.int64)
        detached_predictions = predictions.detach()
        if detached_predictions.ndim == targets.ndim + 1:
            if detached_predictions.shape[0] != target_ids.numel():
                raise ValueError("Prediction and target counts do not match")
            prediction_ids = detached_predictions.argmax(dim=1).reshape(-1)
        elif detached_predictions.ndim == targets.ndim:
            prediction_ids = detached_predictions.reshape(-1).to(dtype=torch.int64)
        else:
            raise ValueError(
                "Expected class logits or class IDs, got prediction shape {} "
                "and target shape {}".format(
                    tuple(detached_predictions.shape),
                    tuple(targets.shape),
                )
            )

        if prediction_ids.numel() != target_ids.numel():
            raise ValueError("Prediction and target counts do not match")
        valid = torch.ones_like(target_ids, dtype=torch.bool)
        if ignore_index is not None:
            valid &= target_ids != int(ignore_index)
        prediction_ids = prediction_ids[valid]
        target_ids = target_ids[valid]
        if target_ids.numel() == 0:
            return
        if (
            (target_ids < 0).any().item()
            or (target_ids >= num_classes).any().item()
            or (prediction_ids < 0).any().item()
            or (prediction_ids >= num_classes).any().item()
        ):
            raise ValueError(
                "Non-ignored true and predicted labels must be in [0, {})".format(
                    num_classes
                )
            )

        encoded = target_ids * num_classes + prediction_ids
        batch_counts = torch.bincount(
            encoded,
            minlength=num_classes * num_classes,
        ).reshape(num_classes, num_classes)
        matrix += batch_counts.to(device="cpu", dtype=torch.int64).numpy()


def _safe_ratio(numerator, denominator):
    denominator = int(denominator)
    if denominator == 0:
        return 0.0
    return float(numerator) / float(denominator)


def classification_metrics_from_confusion(confusion_matrix, class_names):
    matrix = np.asarray(confusion_matrix, dtype=np.int64)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError(
            "confusion_matrix must be square, got shape {}".format(matrix.shape)
        )
    names = tuple(str(name) for name in class_names)
    if len(names) != matrix.shape[0]:
        raise ValueError("class_names length must match confusion matrix size")
    if np.any(matrix < 0):
        raise ValueError("confusion_matrix counts must be non-negative")

    true_count = matrix.sum(axis=1, dtype=np.int64)
    predicted_count = matrix.sum(axis=0, dtype=np.int64)
    true_positive = np.diag(matrix)
    per_class = {}
    precisions = []
    recalls = []
    f1_scores = []
    for class_index, class_name in enumerate(names):
        tp = int(true_positive[class_index])
        support = int(true_count[class_index])
        predicted_support = int(predicted_count[class_index])
        precision = _safe_ratio(tp, predicted_support)
        recall = _safe_ratio(tp, support)
        f1 = (
            0.0
            if precision + recall == 0.0
            else 2.0 * precision * recall / (precision + recall)
        )
        union = support + predicted_support - tp
        iou = _safe_ratio(tp, union)
        precisions.append(precision)
        recalls.append(recall)
        f1_scores.append(f1)
        per_class[str(class_index)] = {
            "class_index": class_index,
            "class_name": class_name,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "iou": iou,
            "support": support,
        }

    return {
        "macro_precision": float(np.mean(precisions)) if precisions else 0.0,
        "macro_recall": float(np.mean(recalls)) if recalls else 0.0,
        "macro_f1": float(np.mean(f1_scores)) if f1_scores else 0.0,
        "per_class": per_class,
        "confusion_matrix": matrix.tolist(),
    }


def instance_confusion_matrix_from_counts(*, tp, fp, fn, tn):
    counts = (int(tp), int(fp), int(fn), int(tn))
    if any(value < 0 for value in counts):
        raise ValueError("Instance pair counts must be non-negative")
    return np.asarray(
        [[counts[3], counts[1]], [counts[2], counts[0]]],
        dtype=np.int64,
    )


def write_confusion_matrix_csv(path, confusion_matrix, class_names):
    path = Path(path)
    matrix = np.asarray(confusion_matrix, dtype=np.int64)
    names = tuple(str(name) for name in class_names)
    if matrix.shape != (len(names), len(names)):
        raise ValueError("Confusion matrix shape and class names do not match")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["true_label/predicted_label", *names])
        for class_name, row in zip(names, matrix.tolist()):
            writer.writerow([class_name, *[int(value) for value in row]])


def write_per_class_metrics_csv(path, task_reports):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = (
        "task",
        "class_index",
        "class_name",
        "precision",
        "recall",
        "f1",
        "iou",
        "support",
    )
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for task_name, report in task_reports.items():
            for class_metrics in report["per_class"].values():
                writer.writerow({"task": task_name, **class_metrics})


def write_confusion_matrix_png(
    path,
    confusion_matrix,
    class_names,
    *,
    title,
):
    
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return False

    path = Path(path)
    matrix = np.asarray(confusion_matrix, dtype=np.int64)
    names = tuple(str(name) for name in class_names)
    if matrix.shape != (len(names), len(names)):
        raise ValueError("Confusion matrix shape and class names do not match")
    path.parent.mkdir(parents=True, exist_ok=True)

    figure_size = max(5.0, min(13.0, 0.85 * len(names)))
    figure, axis = plt.subplots(figsize=(figure_size, figure_size))
    image = axis.imshow(matrix, interpolation="nearest", cmap="Blues")
    figure.colorbar(image, ax=axis, fraction=0.046, pad=0.04)
    tick_labels = ["{}:{}".format(index, name) for index, name in enumerate(names)]
    axis.set(
        xticks=np.arange(len(names)),
        yticks=np.arange(len(names)),
        xticklabels=tick_labels,
        yticklabels=tick_labels,
        xlabel="Predicted",
        ylabel="True",
        title=str(title),
    )
    plt.setp(axis.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
    threshold = float(matrix.max()) / 2.0 if matrix.size else 0.0
    font_size = 7 if len(names) > 5 else 10
    for true_index in range(matrix.shape[0]):
        for predicted_index in range(matrix.shape[1]):
            count = int(matrix[true_index, predicted_index])
            axis.text(
                predicted_index,
                true_index,
                str(count),
                ha="center",
                va="center",
                color="white" if count > threshold else "black",
                fontsize=font_size,
            )
    figure.tight_layout()
    figure.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(figure)
    return True
