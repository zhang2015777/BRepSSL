







from dataclasses import dataclass

import dgl
import torch


EDGE_ATTR_DIM = 16
EDGE_GRID_SHAPE = (16, 5)
EDGE_FACE_UV_SHAPE = (2, 5, 2)
EDGE_FACE_UV_VALID_SHAPE = (2, 5)
UV_BOUND_TOLERANCE = 1e-6


@dataclass(frozen=True)
class PhysicalEdgeMessageView:
    message_graph: dgl.DGLGraph
    message_edge_attr: torch.Tensor
    message_edge_grid: torch.Tensor
    message_edge_face_uv: torch.Tensor
    message_edge_face_uv_valid: torch.Tensor
    message_to_physical_edge: torch.Tensor
    message_is_reverse: torch.Tensor
    message_is_self_loop: torch.Tensor
    physical_to_forward_message: torch.Tensor
    physical_to_reverse_message: torch.Tensor


def _require_tensor(name, value, dtype, shape):
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"{name} must be a torch.Tensor")
    if value.dtype != dtype:
        raise TypeError(
            f"{name} must have dtype={dtype}, got dtype={value.dtype}"
        )
    if tuple(value.shape) != tuple(shape):
        raise ValueError(
            f"{name} must have shape={tuple(shape)}, got shape={tuple(value.shape)}"
        )


def _validate_inputs(
    physical_graph,
    edge_attr,
    edge_grid,
    edge_face_uv,
    edge_face_uv_valid,
    edge_grid_is_standardized,
):
    if not isinstance(physical_graph, dgl.DGLGraph):
        raise TypeError("physical_graph must be a dgl.DGLGraph")
    if edge_grid_is_standardized:
        raise ValueError(
            "Physical-edge direction expansion must run before edge-grid "
            "standardization; channels 14 and 15 cannot be safely swapped "
            "after side-specific standardization."
        )

    edge_count = physical_graph.num_edges()
    _require_tensor(
        "edge_attr",
        edge_attr,
        torch.float32,
        (edge_count, EDGE_ATTR_DIM),
    )
    _require_tensor(
        "edge_grid",
        edge_grid,
        torch.float32,
        (edge_count,) + EDGE_GRID_SHAPE,
    )
    _require_tensor(
        "edge_face_uv",
        edge_face_uv,
        torch.float32,
        (edge_count,) + EDGE_FACE_UV_SHAPE,
    )
    _require_tensor(
        "edge_face_uv_valid",
        edge_face_uv_valid,
        torch.bool,
        (edge_count,) + EDGE_FACE_UV_VALID_SHAPE,
    )

    graph_device = physical_graph.device
    for name, value in (
        ("edge_attr", edge_attr),
        ("edge_grid", edge_grid),
        ("edge_face_uv", edge_face_uv),
        ("edge_face_uv_valid", edge_face_uv_valid),
    ):
        if value.device != graph_device:
            raise ValueError(
                f"{name} device={value.device} does not match "
                f"physical_graph device={graph_device}"
            )

    for name, value in (
        ("edge_attr", edge_attr),
        ("edge_grid", edge_grid),
        ("edge_face_uv", edge_face_uv),
    ):
        if not torch.all(torch.isfinite(value)):
            raise ValueError(f"{name} contains NaN or Inf")

    invalid_uv = edge_face_uv[~edge_face_uv_valid]
    if invalid_uv.numel() and torch.any(invalid_uv != 0):
        raise ValueError(
            "edge_face_uv must be exactly [0,0] wherever "
            "edge_face_uv_valid is False"
        )
    valid_uv = edge_face_uv[edge_face_uv_valid]
    if valid_uv.numel() and torch.any(
        torch.abs(valid_uv) > 1.0 + UV_BOUND_TOLERANCE
    ):
        raise ValueError("valid edge_face_uv coordinates must lie in [-1,1]")


def reverse_edge_grid(edge_grid):
    
    if not isinstance(edge_grid, torch.Tensor):
        raise TypeError("edge_grid must be a torch.Tensor")
    if edge_grid.dtype != torch.float32:
        raise TypeError(
            f"edge_grid must have dtype=torch.float32, got {edge_grid.dtype}"
        )
    if edge_grid.ndim != 3 or tuple(edge_grid.shape[1:]) != EDGE_GRID_SHAPE:
        raise ValueError(
            f"edge_grid must have shape [E,16,5], got {tuple(edge_grid.shape)}"
        )

    flipped = torch.flip(edge_grid, dims=(2,))
    reverse = torch.empty_like(edge_grid)
    reverse[:, 0:3, :] = flipped[:, 0:3, :]
    reverse[:, 3:6, :] = -flipped[:, 3:6, :]
    reverse[:, 6:9, :] = flipped[:, 9:12, :]
    reverse[:, 9:12, :] = flipped[:, 6:9, :]
    reverse[:, 12, :] = flipped[:, 12, :]
    reverse[:, 13, :] = flipped[:, 13, :]
    reverse[:, 14, :] = flipped[:, 15, :]
    reverse[:, 15, :] = flipped[:, 14, :]
    return reverse


def reverse_edge_face_uv(edge_face_uv, edge_face_uv_valid):
    
    if not isinstance(edge_face_uv, torch.Tensor):
        raise TypeError("edge_face_uv must be a torch.Tensor")
    if not isinstance(edge_face_uv_valid, torch.Tensor):
        raise TypeError("edge_face_uv_valid must be a torch.Tensor")
    if edge_face_uv.dtype != torch.float32:
        raise TypeError("edge_face_uv must have dtype=torch.float32")
    if edge_face_uv_valid.dtype != torch.bool:
        raise TypeError("edge_face_uv_valid must have dtype=torch.bool")
    if (
        edge_face_uv.ndim != 4
        or tuple(edge_face_uv.shape[1:]) != EDGE_FACE_UV_SHAPE
    ):
        raise ValueError(
            "edge_face_uv must have shape [E,2,5,2], "
            f"got {tuple(edge_face_uv.shape)}"
        )
    if (
        edge_face_uv_valid.ndim != 3
        or tuple(edge_face_uv_valid.shape[1:])
        != EDGE_FACE_UV_VALID_SHAPE
    ):
        raise ValueError(
            "edge_face_uv_valid must have shape [E,2,5], "
            f"got {tuple(edge_face_uv_valid.shape)}"
        )
    if edge_face_uv.shape[0] != edge_face_uv_valid.shape[0]:
        raise ValueError(
            "edge_face_uv and edge_face_uv_valid edge counts do not match"
        )
    return (
        torch.flip(edge_face_uv, dims=(1, 2)),
        torch.flip(edge_face_uv_valid, dims=(1, 2)),
    )


def _interleave(forward, reverse):
    return torch.stack((forward, reverse), dim=1).flatten(0, 1)


def build_physical_edge_message_view(
    physical_graph,
    edge_attr,
    edge_grid,
    edge_face_uv,
    edge_face_uv_valid,
    *,
    edge_grid_is_standardized=False,
):
    





    _validate_inputs(
        physical_graph,
        edge_attr,
        edge_grid,
        edge_face_uv,
        edge_face_uv_valid,
        edge_grid_is_standardized,
    )

    device = physical_graph.device
    edge_count = physical_graph.num_edges()
    src, dst = physical_graph.edges(order="eid")
    message_src = torch.stack((src, dst), dim=1).reshape(-1)
    message_dst = torch.stack((dst, src), dim=1).reshape(-1)
    message_graph = dgl.graph(
        (message_src, message_dst),
        num_nodes=physical_graph.num_nodes(),
        idtype=physical_graph.idtype,
        device=device,
    )

    physical_batch_num_nodes = physical_graph.batch_num_nodes().to(device)
    physical_batch_num_edges = physical_graph.batch_num_edges().to(device)
    message_graph.set_batch_num_nodes(physical_batch_num_nodes)
    message_graph.set_batch_num_edges(physical_batch_num_edges * 2)

    reverse_grid = reverse_edge_grid(edge_grid)
    reverse_uv, reverse_uv_valid = reverse_edge_face_uv(
        edge_face_uv, edge_face_uv_valid
    )
    message_edge_attr = _interleave(edge_attr, edge_attr)
    message_edge_grid = _interleave(edge_grid, reverse_grid)
    message_edge_face_uv = _interleave(edge_face_uv, reverse_uv)
    message_edge_face_uv_valid = _interleave(
        edge_face_uv_valid, reverse_uv_valid
    )

    physical_indices = torch.arange(
        edge_count, dtype=torch.int64, device=device
    )
    message_to_physical_edge = physical_indices.repeat_interleave(2)
    message_is_reverse = torch.tensor(
        [False, True], dtype=torch.bool, device=device
    ).repeat(edge_count)
    physical_to_forward_message = physical_indices * 2
    physical_to_reverse_message = physical_to_forward_message + 1
    message_is_self_loop = (src == dst).repeat_interleave(2)

    if message_graph.num_edges() != 2 * edge_count:
        raise RuntimeError(
            "Message graph edge count does not equal twice the physical edge count"
        )
    if message_graph.num_nodes() != physical_graph.num_nodes():
        raise RuntimeError("Message graph node count changed unexpectedly")

    return PhysicalEdgeMessageView(
        message_graph=message_graph,
        message_edge_attr=message_edge_attr,
        message_edge_grid=message_edge_grid,
        message_edge_face_uv=message_edge_face_uv,
        message_edge_face_uv_valid=message_edge_face_uv_valid,
        message_to_physical_edge=message_to_physical_edge,
        message_is_reverse=message_is_reverse,
        message_is_self_loop=message_is_self_loop,
        physical_to_forward_message=physical_to_forward_message,
        physical_to_reverse_message=physical_to_reverse_message,
    )
