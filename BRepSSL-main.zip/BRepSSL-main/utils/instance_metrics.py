import numpy as np
import torch
from scipy.optimize import linear_sum_assignment


def safe_div(num, den, eps=1e-8):
    denominator = float(den)
    if abs(denominator) < float(eps):
        return 0.0
    return float(num) / denominator


def pairwise_instance_counts(
    inst_logits,
    inst_label,
    inst_mask,
    threshold=0.5,
):
    with torch.no_grad():
        pred = torch.sigmoid(inst_logits.detach()) >= threshold
        target = inst_label.detach() >= 0.5
        valid = inst_mask.detach().bool()

        pred = pred[valid]
        target = target[valid]
        tp = int((pred & target).sum().item())
        fp = int((pred & ~target).sum().item())
        fn = int((~pred & target).sum().item())
        tn = int((~pred & ~target).sum().item())
    return tp, fp, fn, tn


def pairwise_instance_metrics_from_counts(tp, fp, fn, tn):
    return {
        "acc": safe_div(tp + tn, tp + fp + fn + tn),
        "precision": safe_div(tp, tp + fp),
        "recall": safe_div(tp, tp + fn),
        "f1": safe_div(2 * tp, 2 * tp + fp + fn),
        "iou": safe_div(tp, tp + fp + fn),
    }


def connected_components_from_pair_matrix(pair_matrix):
    if isinstance(pair_matrix, torch.Tensor):
        adjacency = pair_matrix.detach().to(device="cpu", dtype=torch.bool).numpy()
    else:
        adjacency = np.asarray(pair_matrix, dtype=np.bool_)

    if adjacency.ndim != 2 or adjacency.shape[0] != adjacency.shape[1]:
        raise ValueError(
            "pair_matrix must be square, got shape {}.".format(adjacency.shape)
        )
    if adjacency.shape[0] == 0:
        return []

    adjacency = np.logical_or(adjacency, adjacency.T)
    adjacency = adjacency.copy()
    np.fill_diagonal(adjacency, True)

    components = []
    visited = np.zeros(adjacency.shape[0], dtype=np.bool_)
    for start in range(adjacency.shape[0]):
        if visited[start]:
            continue
        component = set()
        stack = [start]
        visited[start] = True
        while stack:
            node = stack.pop()
            component.add(int(node))
            neighbors = np.flatnonzero(adjacency[node])
            for neighbor in neighbors:
                if not visited[neighbor]:
                    visited[neighbor] = True
                    stack.append(int(neighbor))
        components.append(component)
    return components


def cluster_iou_for_one_graph(pred_pair_matrix, gt_pair_matrix):
    pred_components = connected_components_from_pair_matrix(pred_pair_matrix)
    gt_components = connected_components_from_pair_matrix(gt_pair_matrix)
    if not pred_components or not gt_components:
        return {
            "inst_cluster_iou": 0.0,
            "inst_cluster_iou_matched": 0.0,
            "num_pred_instances": len(pred_components),
            "num_gt_instances": len(gt_components),
        }

    iou_matrix = np.zeros(
        (len(pred_components), len(gt_components)),
        dtype=np.float64,
    )
    for pred_idx, pred_component in enumerate(pred_components):
        for gt_idx, gt_component in enumerate(gt_components):
            intersection = len(pred_component & gt_component)
            union = len(pred_component | gt_component)
            iou_matrix[pred_idx, gt_idx] = safe_div(intersection, union)

    pred_indices, gt_indices = linear_sum_assignment(-iou_matrix)
    matched_iou_sum = float(iou_matrix[pred_indices, gt_indices].sum())
    matched_count = len(pred_indices)
    return {
        "inst_cluster_iou": safe_div(
            matched_iou_sum,
            max(len(pred_components), len(gt_components)),
        ),
        "inst_cluster_iou_matched": safe_div(
            matched_iou_sum,
            matched_count,
        ),
        "num_pred_instances": len(pred_components),
        "num_gt_instances": len(gt_components),
    }


def batch_instance_cluster_iou(
    inst_logits,
    inst_label,
    inst_mask,
    threshold=0.5,
):
    if inst_logits.ndim == 2:
        inst_logits = inst_logits.unsqueeze(0)
        inst_label = inst_label.unsqueeze(0)
        inst_mask = inst_mask.unsqueeze(0)
    if (
        inst_logits.ndim != 3
        or inst_label.shape != inst_logits.shape
        or inst_mask.shape != inst_logits.shape
    ):
        raise ValueError(
            "Expected matching [B, maxN, maxN] tensors, got logits={}, "
            "label={}, mask={}.".format(
                tuple(inst_logits.shape),
                tuple(inst_label.shape),
                tuple(inst_mask.shape),
            )
        )

    cluster_ious = []
    matched_cluster_ious = []
    with torch.no_grad():
        logits = inst_logits.detach()
        labels = inst_label.detach()
        masks = inst_mask.detach().bool()
        for batch_idx in range(logits.shape[0]):
            num_nodes = int(masks[batch_idx].any(dim=1).sum().item())
            if num_nodes == 0:
                cluster_ious.append(0.0)
                matched_cluster_ious.append(0.0)
                continue

            pred_pair_matrix = (
                torch.sigmoid(logits[batch_idx, :num_nodes, :num_nodes])
                >= threshold
            )
            gt_pair_matrix = (
                labels[batch_idx, :num_nodes, :num_nodes] >= 0.5
            )
            graph_metrics = cluster_iou_for_one_graph(
                pred_pair_matrix,
                gt_pair_matrix,
            )
            cluster_ious.append(graph_metrics["inst_cluster_iou"])
            matched_cluster_ious.append(
                graph_metrics["inst_cluster_iou_matched"]
            )

    graph_count = len(cluster_ious)
    return {
        "inst_cluster_iou": safe_div(sum(cluster_ious), graph_count),
        "inst_cluster_iou_matched": safe_div(
            sum(matched_cluster_ious),
            graph_count,
        ),
        "graph_count": graph_count,
    }
