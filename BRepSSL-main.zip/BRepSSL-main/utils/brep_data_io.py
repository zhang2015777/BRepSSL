

import json
from numbers import Integral
from pathlib import Path

import dgl
import numpy as np
import torch

from configs.main_experiment_config import FORMAL_SPLIT_PROTOCOL


FACE_ATTR_DIM = 16
FACE_GRID_SHAPE = (11, 5, 5)
EDGE_ATTR_DIM = 16
EDGE_GRID_SHAPE = (16, 5)
EDGE_FACE_UV_SHAPE = (2, 5, 2)
EDGE_FACE_UV_VALID_SHAPE = (2, 5)
FACE_STANDARDIZED_CHANNELS = (6, 7, 9)
EDGE_STANDARDIZED_CHANNELS = (12, 14, 15)


def load_json(path):
    path = Path(path)
    if path.suffix.lower() != ".json":
        raise ValueError(f"formal B-Rep IO only accepts JSON: {path}")
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def _float_tensor(value, name, expected_shape):
    try:
        array = np.asarray(value, dtype=np.float32, order="C")
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be numeric") from exc
    if array.shape != expected_shape:
        raise ValueError(
            f"{name} expected shape {expected_shape}, got {array.shape}"
        )
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} contains NaN or Inf")
    return torch.from_numpy(array)


def _int64_vector(value, name):
    if not isinstance(value, (list, tuple, np.ndarray)):
        raise TypeError(f"{name} must be a one-dimensional integer sequence")
    flat_values = value.tolist() if isinstance(value, np.ndarray) else value
    if any(
        isinstance(item, (bool, np.bool_))
        or not isinstance(item, Integral)
        for item in flat_values
    ):
        raise TypeError(f"{name} must contain integer indices")
    try:
        array = np.asarray(value, dtype=np.int64, order="C")
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must contain integer indices") from exc
    if array.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    return array


def _bool_tensor(value, name, expected_shape):
    array = np.asarray(value)
    if array.shape != expected_shape or array.dtype != np.bool_:
        raise TypeError(f"{name} must be bool with shape {expected_shape}")
    return torch.from_numpy(np.asarray(array, dtype=np.bool_, order="C"))


def load_one_graph(part_id, data):
    required = (
        "graph",
        "graph_face_attr",
        "graph_face_grid",
        "graph_edge_attr",
        "graph_edge_grid",
        "graph_edge_face_uv",
        "graph_edge_face_uv_valid",
    )
    missing = [key for key in required if key not in data]
    if missing:
        raise KeyError(f"part={part_id}: missing graph fields {missing}")
    graph_info = data["graph"]
    if not isinstance(graph_info, dict):
        raise TypeError(f"part={part_id}: graph must be an object")
    edges = graph_info.get("edges")
    if not (
        isinstance(edges, (list, tuple))
        and len(edges) == 2
        and len(edges[0]) == len(edges[1])
    ):
        raise ValueError(f"part={part_id}: graph edges must be [src,dst]")
    num_nodes = int(graph_info.get("num_nodes"))
    src = _int64_vector(edges[0], f"part={part_id} graph src")
    dst = _int64_vector(edges[1], f"part={part_id} graph dst")
    if src.shape != dst.shape:
        raise ValueError(f"part={part_id}: graph src/dst lengths differ")
    num_edges = int(src.shape[0])
    if num_nodes < 0:
        raise ValueError(f"part={part_id}: num_nodes must be non-negative")
    if num_edges and (
        np.any(src < 0)
        or np.any(dst < 0)
        or np.any(src >= num_nodes)
        or np.any(dst >= num_nodes)
    ):
        raise ValueError(f"part={part_id}: graph endpoint is out of range")
    graph = dgl.graph(
        (torch.from_numpy(src), torch.from_numpy(dst)),
        num_nodes=num_nodes,
        idtype=torch.int64,
    )
    graph.ndata["x"] = _float_tensor(
        data["graph_face_attr"],
        f"part={part_id} graph_face_attr",
        (num_nodes, FACE_ATTR_DIM),
    )
    graph.ndata["grid"] = _float_tensor(
        data["graph_face_grid"],
        f"part={part_id} graph_face_grid",
        (num_nodes,) + FACE_GRID_SHAPE,
    )
    graph.edata["x"] = _float_tensor(
        data["graph_edge_attr"],
        f"part={part_id} graph_edge_attr",
        (num_edges, EDGE_ATTR_DIM),
    )
    graph.edata["grid"] = _float_tensor(
        data["graph_edge_grid"],
        f"part={part_id} graph_edge_grid",
        (num_edges,) + EDGE_GRID_SHAPE,
    )
    face_uv = _float_tensor(
        data["graph_edge_face_uv"],
        f"part={part_id} graph_edge_face_uv",
        (num_edges,) + EDGE_FACE_UV_SHAPE,
    )
    expected_valid = (num_edges,) + EDGE_FACE_UV_VALID_SHAPE
    valid = _bool_tensor(
        data["graph_edge_face_uv_valid"],
        f"part={part_id} UV valid",
        expected_valid,
    )
    if torch.any(face_uv[~valid] != 0):
        raise ValueError(f"part={part_id}: invalid UV positions must be zero")
    if torch.any(torch.abs(face_uv[valid]) > 1.0 + 1e-6):
        raise ValueError(f"part={part_id}: valid UV must be in [-1,1]")
    graph.edata["face_uv"] = face_uv
    graph.edata["face_uv_valid"] = valid
    return {"graph": graph, "filename": part_id}


def _load_statistics_common(path, schema_version, train_ids_sha256):
    stat = load_json(path)
    expected = {
        "schema_version": schema_version,
        "source_split": "train",
        "split_protocol": FORMAL_SPLIT_PROTOCOL,
        "std_ddof": 0,
    }
    for key, value in expected.items():
        if stat.get(key) != value:
            raise ValueError(f"{path}: {key} must be {value!r}")
    if (
        train_ids_sha256 is not None
        and stat.get("train_ids_sha256") != train_ids_sha256
    ):
        raise ValueError(f"{path}: train_ids_sha256 mismatch")
    return stat


def _vector(stat, key, dimension, path):
    tensor = torch.as_tensor(stat.get(key), dtype=torch.float32)
    if tensor.shape != (dimension,) or not torch.all(torch.isfinite(tensor)):
        raise ValueError(f"{path}: {key} must be finite [{dimension}]")
    return tensor


def load_attr_statistics(path, expected_train_ids_sha256=None):
    stat = _load_statistics_common(
        path,
        "brep_graph_attr_stat_v2",
        expected_train_ids_sha256,
    )
    if stat.get("face_attr_dim") != 16 or stat.get("edge_attr_dim") != 16:
        raise ValueError(f"{path}: formal attr dimensions must be 16/16")
    result = dict(stat)
    for domain in ("face", "edge"):
        mean_key = f"mean_{domain}_attr"
        std_key = f"std_{domain}_attr"
        result[mean_key] = _vector(stat, mean_key, 16, path)
        raw_std = _vector(stat, std_key, 16, path)
        if torch.any(raw_std < 0):
            raise ValueError(f"{path}: {std_key} is negative")
        result[f"raw_{std_key}"] = raw_std
        result[std_key] = torch.where(
            raw_std < 1e-8,
            torch.ones_like(raw_std),
            raw_std,
        )
    return result


def load_uv_statistics(path, expected_train_ids_sha256=None):
    stat = _load_statistics_common(
        path,
        "brep_graph_uv_stat_v1",
        expected_train_ids_sha256,
    )
    if stat.get("face_grid_dim") != 11 or stat.get("edge_grid_dim") != 16:
        raise ValueError(f"{path}: formal grid dimensions must be 11/16")
    if tuple(stat.get("face_standardized_channels", ())) != (
        FACE_STANDARDIZED_CHANNELS
    ):
        raise ValueError(f"{path}: wrong face standardized channels")
    if tuple(stat.get("edge_standardized_channels", ())) != (
        EDGE_STANDARDIZED_CHANNELS
    ):
        raise ValueError(f"{path}: wrong edge standardized channels")
    result = dict(stat)
    for domain in ("face", "edge"):
        mean_key = f"mean_{domain}_grid"
        std_key = f"std_{domain}_grid"
        count_key = f"count_{domain}_grid"
        result[mean_key] = _vector(stat, mean_key, 3, path)
        raw_std = _vector(stat, std_key, 3, path)
        counts = torch.as_tensor(stat.get(count_key), dtype=torch.int64)
        if torch.any(raw_std < 0):
            raise ValueError(f"{path}: {std_key} is negative")
        if counts.shape != (3,) or torch.any(counts <= 0):
            raise ValueError(f"{path}: {count_key} must be positive [3]")
        result[f"raw_{std_key}"] = raw_std
        result[std_key] = torch.where(
            raw_std < 1e-8,
            torch.ones_like(raw_std),
            raw_std,
        )
        result[count_key] = counts
    return result
