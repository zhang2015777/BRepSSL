

import sys
from pathlib import Path

import dgl
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.physical_edge_message_adapter import (
    build_physical_edge_message_view,
)


def make_edge_tensors(edge_count, value_offset=0.0):
    edge_attr = (
        torch.arange(edge_count * 16, dtype=torch.float32).reshape(
            edge_count, 16
        )
        + value_offset
    )
    edge_grid = (
        torch.arange(edge_count * 16 * 5, dtype=torch.float32).reshape(
            edge_count, 16, 5
        )
        + 1000.0
        + value_offset
    )
    edge_face_uv = torch.zeros(edge_count, 2, 5, 2, dtype=torch.float32)
    for edge_index in range(edge_count):
        for side in range(2):
            for sample in range(5):
                edge_face_uv[edge_index, side, sample, 0] = (
                    -0.8 + 0.1 * sample + 0.05 * side + 0.01 * edge_index
                )
                edge_face_uv[edge_index, side, sample, 1] = (
                    0.7 - 0.1 * sample - 0.05 * side - 0.01 * edge_index
                )
    edge_face_uv_valid = torch.ones(
        edge_count, 2, 5, dtype=torch.bool
    )
    if edge_count:
        edge_face_uv_valid[0, 0, 1] = False
        edge_face_uv[0, 0, 1] = 0.0
    return edge_attr, edge_grid, edge_face_uv, edge_face_uv_valid


def expected_reverse_grid(edge_grid):
    flipped = torch.flip(edge_grid, dims=(2,))
    expected = torch.empty_like(edge_grid)
    expected[:, 0:3] = flipped[:, 0:3]
    expected[:, 3:6] = -flipped[:, 3:6]
    expected[:, 6:9] = flipped[:, 9:12]
    expected[:, 9:12] = flipped[:, 6:9]
    expected[:, 12] = flipped[:, 12]
    expected[:, 13] = flipped[:, 13]
    expected[:, 14] = flipped[:, 15]
    expected[:, 15] = flipped[:, 14]
    return expected


def assert_view(
    physical_graph,
    tensors,
    expected_src,
    expected_dst,
    expected_self_loop,
):
    edge_attr, edge_grid, edge_face_uv, edge_face_uv_valid = tensors
    view = build_physical_edge_message_view(
        physical_graph,
        edge_attr,
        edge_grid,
        edge_face_uv,
        edge_face_uv_valid,
    )
    edge_count = physical_graph.num_edges()
    message_src, message_dst = view.message_graph.edges(order="eid")
    assert torch.equal(message_src.cpu(), torch.tensor(expected_src))
    assert torch.equal(message_dst.cpu(), torch.tensor(expected_dst))
    assert view.message_graph.num_nodes() == physical_graph.num_nodes()
    assert view.message_graph.num_edges() == 2 * edge_count

    physical_indices = torch.arange(edge_count)
    assert torch.equal(
        view.message_to_physical_edge.cpu(),
        physical_indices.repeat_interleave(2),
    )
    assert torch.equal(
        view.message_is_reverse.cpu(),
        torch.tensor([False, True]).repeat(edge_count),
    )
    assert torch.equal(
        view.physical_to_forward_message.cpu(), physical_indices * 2
    )
    assert torch.equal(
        view.physical_to_reverse_message.cpu(), physical_indices * 2 + 1
    )
    assert torch.equal(
        view.message_is_self_loop.cpu(), torch.tensor(expected_self_loop)
    )

    assert torch.equal(view.message_edge_attr[0::2], edge_attr)
    assert torch.equal(view.message_edge_attr[1::2], edge_attr)
    expected_grid = expected_reverse_grid(edge_grid)
    assert torch.equal(view.message_edge_grid[0::2], edge_grid)
    assert torch.equal(view.message_edge_grid[1::2], expected_grid)
    assert torch.equal(
        view.message_edge_grid[1::2, 0:3],
        torch.flip(edge_grid[:, 0:3], dims=(2,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 3:6],
        -torch.flip(edge_grid[:, 3:6], dims=(2,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 6:9],
        torch.flip(edge_grid[:, 9:12], dims=(2,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 9:12],
        torch.flip(edge_grid[:, 6:9], dims=(2,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 12],
        torch.flip(edge_grid[:, 12], dims=(1,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 13],
        torch.flip(edge_grid[:, 13], dims=(1,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 14],
        torch.flip(edge_grid[:, 15], dims=(1,)),
    )
    assert torch.equal(
        view.message_edge_grid[1::2, 15],
        torch.flip(edge_grid[:, 14], dims=(1,)),
    )

    expected_uv = torch.flip(edge_face_uv, dims=(1, 2))
    expected_valid = torch.flip(edge_face_uv_valid, dims=(1, 2))
    assert torch.equal(view.message_edge_face_uv[0::2], edge_face_uv)
    assert torch.equal(view.message_edge_face_uv[1::2], expected_uv)
    assert torch.equal(
        view.message_edge_face_uv_valid[0::2], edge_face_uv_valid
    )
    assert torch.equal(
        view.message_edge_face_uv_valid[1::2], expected_valid
    )
    assert torch.all(
        view.message_edge_face_uv[
            ~view.message_edge_face_uv_valid
        ]
        == 0
    )

    graph_device = physical_graph.device
    for tensor in (
        view.message_edge_attr,
        view.message_edge_grid,
        view.message_edge_face_uv,
        view.message_edge_face_uv_valid,
        view.message_to_physical_edge,
        view.message_is_reverse,
        view.message_is_self_loop,
        view.physical_to_forward_message,
        view.physical_to_reverse_message,
    ):
        assert tensor.device == graph_device
    assert view.message_graph.device == graph_device
    assert len(view.message_graph.ndata) == 0
    assert len(view.message_graph.edata) == 0
    return view


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def check_invalid_inputs(graph, tensors):
    edge_attr, edge_grid, edge_face_uv, edge_face_uv_valid = tensors
    expect_error(
        ValueError,
        lambda: build_physical_edge_message_view(
            graph,
            edge_attr,
            edge_grid[:, :15],
            edge_face_uv,
            edge_face_uv_valid,
        ),
    )
    expect_error(
        TypeError,
        lambda: build_physical_edge_message_view(
            graph,
            edge_attr.to(torch.float64),
            edge_grid,
            edge_face_uv,
            edge_face_uv_valid,
        ),
    )
    expect_error(
        ValueError,
        lambda: build_physical_edge_message_view(
            graph,
            edge_attr[:-1],
            edge_grid,
            edge_face_uv,
            edge_face_uv_valid,
        ),
    )
    bad_uv = edge_face_uv.clone()
    invalid_location = torch.nonzero(
        ~edge_face_uv_valid, as_tuple=False
    )[0]
    bad_uv[
        invalid_location[0],
        invalid_location[1],
        invalid_location[2],
    ] = torch.tensor([0.25, -0.25])
    expect_error(
        ValueError,
        lambda: build_physical_edge_message_view(
            graph,
            edge_attr,
            edge_grid,
            bad_uv,
            edge_face_uv_valid,
        ),
    )
    expect_error(
        TypeError,
        lambda: build_physical_edge_message_view(
            graph,
            edge_attr,
            edge_grid,
            edge_face_uv,
            edge_face_uv_valid.to(torch.int64),
        ),
    )
    expect_error(
        ValueError,
        lambda: build_physical_edge_message_view(
            graph,
            edge_attr,
            edge_grid,
            edge_face_uv,
            edge_face_uv_valid,
            edge_grid_is_standardized=True,
        ),
    )


def main():
    graph_a = dgl.graph(([0, 1], [1, 2]), num_nodes=3)
    tensors_a = make_edge_tensors(2)
    view_a = assert_view(
        graph_a,
        tensors_a,
        expected_src=[0, 1, 1, 2],
        expected_dst=[1, 0, 2, 1],
        expected_self_loop=[False, False, False, False],
    )
    check_invalid_inputs(graph_a, tensors_a)

    graph_b = dgl.graph(([0], [0]), num_nodes=2)
    tensors_b = make_edge_tensors(1, value_offset=5000.0)
    view_b = assert_view(
        graph_b,
        tensors_b,
        expected_src=[0, 0],
        expected_dst=[0, 0],
        expected_self_loop=[True, True],
    )
    assert not torch.equal(
        view_b.message_edge_grid[0], view_b.message_edge_grid[1]
    )
    assert not torch.equal(
        view_b.message_edge_face_uv[0], view_b.message_edge_face_uv[1]
    )

    batch_graph = dgl.batch([graph_a, graph_b])
    batch_tensors = tuple(
        torch.cat((left, right), dim=0)
        for left, right in zip(tensors_a, tensors_b)
    )
    batch_view = assert_view(
        batch_graph,
        batch_tensors,
        expected_src=[0, 1, 1, 2, 3, 3],
        expected_dst=[1, 0, 2, 1, 3, 3],
        expected_self_loop=[False, False, False, False, True, True],
    )
    assert torch.equal(
        batch_view.message_graph.batch_num_nodes().cpu(),
        batch_graph.batch_num_nodes().cpu(),
    )
    assert torch.equal(
        batch_view.message_graph.batch_num_edges().cpu(),
        batch_graph.batch_num_edges().cpu() * 2,
    )
    assert torch.equal(
        batch_view.message_to_physical_edge.cpu(),
        torch.tensor([0, 0, 1, 1, 2, 2]),
    )

    print("PHYSICAL_EDGE_MESSAGE_ADAPTER_CHECK_PASS")
    print("single_graph_a_physical_edges=2 message_edges=4")
    print("single_graph_b_seam_physical_edges=1 message_edges=2")
    print("batch_physical_edges=3 message_edges=6")


if __name__ == "__main__":
    main()
