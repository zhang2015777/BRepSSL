

import sys
from dataclasses import replace
from pathlib import Path

import torch
from torch import nn
import torch.nn.functional as F


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
)
from dataset.quality_export.check_brep_graph_geometry_encoder import (
    assert_model_input_unchanged,
    make_batch,
    make_graph_b,
    make_statistics,
    snapshot_model_input,
)
from models.brep_physical_message_backbone import (
    BRepPhysicalMessageBackbone,
)
from models.brep_physical_message_pretrainer import (
    BRepPhysicalMessageMaskedPretrainer,
)
from models.brep_pretrain_input_masking import (
    sample_brep_pretrain_mask_plan,
)


OLD_DECODER_NAMES = (
    "node_attr_decoder",
    "node_grid_decoder",
    "node_inside_decoder",
    "edge_attr_decoder",
    "edge_grid_decoder",
    "edge_uv_decoder",
    "edge_uv_valid_decoder",
)
OLD_OUTPUT_NAMES = (
    "pred_node_attr",
    "target_node_attr",
    "pred_node_grid_continuous",
    "target_node_grid_continuous",
    "node_inside_logits",
    "target_node_inside",
    "pred_edge_attr",
    "target_edge_attr",
    "pred_edge_grid",
    "target_edge_grid",
    "pred_edge_uv",
    "target_edge_uv",
    "edge_uv_valid_logits",
)


def changed_batch(batch, *, node_ids=None, physical_ids=None):
    model_input = batch.model_input
    node_attr = model_input.node_attr.clone()
    node_grid = model_input.node_grid.clone()
    messages = model_input.message_view
    edge_attr = messages.message_edge_attr.clone()
    if node_ids is not None and node_ids.numel():
        node_attr[node_ids] += 7.0
        node_grid[node_ids, 0:10] -= 5.0
        node_grid[node_ids, 10] = 1.0 - node_grid[node_ids, 10]
    if physical_ids is not None and physical_ids.numel():
        for physical_id in physical_ids.tolist():
            edge_attr[2 * physical_id : 2 * physical_id + 2] += 4.0
    return replace(
        batch,
        model_input=replace(
            model_input,
            node_attr=node_attr,
            node_grid=node_grid,
            message_view=replace(
                messages,
                message_edge_attr=edge_attr,
            ),
        ),
    )


def finite_gradients(module):
    values = [
        parameter.grad
        for parameter in module.parameters()
        if parameter.requires_grad and parameter.grad is not None
    ]
    assert values
    assert all(torch.all(torch.isfinite(value)) for value in values)


def main():
    torch.manual_seed(911)
    statistics = make_statistics()
    batch = make_batch(statistics, include_b=True)
    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.5,
        edge_mask_ratio=0.5,
        negative_edge_ratio=1.0,
        generator=torch.Generator().manual_seed(912),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    assert plan.masked_node_indices.numel() > 0
    assert plan.masked_physical_edge_indices.numel() > 0
    model = BRepPhysicalMessageMaskedPretrainer(
        node_mask_ratio=0.5,
        edge_mask_ratio=0.5,
        negative_edge_ratio=1.0,
        decoder_drop=0.0,
    )
    assert sum(
        isinstance(module, BRepPhysicalMessageBackbone)
        for module in model.modules()
    ) == 1
    assert not hasattr(model, "teacher_backbone")
    assert not hasattr(model, "ema_teacher")
    for name in OLD_DECODER_NAMES:
        assert not hasattr(model, name)

    model.eval()
    with torch.no_grad():
        expected_full_geometry = model.backbone.encode_full_geometry(
            batch.model_input
        )

    calls = {
        "encode_full_geometry": 0,
        "forward_student": 0,
        "forward_full": 0,
        "iba": 0,
        "diffusion": 0,
        "attention": 0,
        "target_grad_enabled": None,
    }
    original_encode = model.backbone.encode_full_geometry
    original_student = model.backbone.forward_student
    original_full = model.backbone.forward_full

    def counted_encode(model_input):
        calls["encode_full_geometry"] += 1
        calls["target_grad_enabled"] = torch.is_grad_enabled()
        return original_encode(model_input)

    def counted_student(student_input, node_mask):
        calls["forward_student"] += 1
        return original_student(student_input, node_mask)

    def counted_full(model_input):
        calls["forward_full"] += 1
        return original_full(model_input)

    model.backbone.encode_full_geometry = counted_encode
    model.backbone.forward_student = counted_student
    model.backbone.forward_full = counted_full
    hooks = (
        model.backbone.iba_dmp.register_forward_hook(
            lambda *_: calls.__setitem__("iba", calls["iba"] + 1)
        ),
        model.backbone.damped_diffusion.register_forward_hook(
            lambda *_: calls.__setitem__(
                "diffusion", calls["diffusion"] + 1
            )
        ),
        model.backbone.attention_refiner.register_forward_hook(
            lambda *_: calls.__setitem__(
                "attention", calls["attention"] + 1
            )
        ),
    )
    before = snapshot_model_input(batch.model_input)
    out = model(batch, mask_plan=plan, return_predictions=True)
    for hook in hooks:
        hook.remove()
    model.backbone.encode_full_geometry = original_encode
    model.backbone.forward_student = original_student
    model.backbone.forward_full = original_full
    assert_model_input_unchanged(batch.model_input, before)
    assert calls == {
        "encode_full_geometry": 1,
        "forward_student": 1,
        "forward_full": 0,
        "iba": 1,
        "diffusion": 1,
        "attention": 1,
        "target_grad_enabled": False,
    }

    k_node = plan.masked_node_indices.numel()
    k_edge = plan.masked_physical_edge_indices.numel()
    assert out["pred_node_embedding"].shape == (k_node, 128)
    assert out["target_node_embedding"].shape == (k_node, 128)
    assert out["pred_edge_embedding"].shape == (k_edge, 128)
    assert out["target_edge_embedding"].shape == (k_edge, 128)
    assert out["target_node_embedding"].requires_grad is False
    assert out["target_node_embedding"].grad_fn is None
    assert out["target_edge_embedding"].requires_grad is False
    assert out["target_edge_embedding"].grad_fn is None
    for name in OLD_OUTPUT_NAMES:
        assert name not in out

    expected_forward = 2 * plan.masked_physical_edge_indices
    assert torch.equal(out["forward_message_ids"], expected_forward)
    torch.testing.assert_close(
        out["target_node_embedding"],
        expected_full_geometry.node_feat[plan.masked_node_indices],
    )
    torch.testing.assert_close(
        out["target_edge_embedding"],
        expected_full_geometry.message_edge_feat[expected_forward],
    )

    manual_node = F.smooth_l1_loss(
        out["pred_node_embedding"],
        out["target_node_embedding"],
        beta=model.embedding_smooth_l1_beta,
    )
    manual_edge = F.smooth_l1_loss(
        out["pred_edge_embedding"],
        out["target_edge_embedding"],
        beta=model.embedding_smooth_l1_beta,
    )
    manual_topology = F.binary_cross_entropy_with_logits(
        out["topology_logits"],
        out["topology_labels"],
    )
    torch.testing.assert_close(out["loss_node_embedding"], manual_node)
    torch.testing.assert_close(out["loss_edge_embedding"], manual_edge)
    torch.testing.assert_close(out["loss_topology"], manual_topology)
    torch.testing.assert_close(out["loss_node"], manual_node)
    torch.testing.assert_close(out["loss_edge"], manual_edge)
    torch.testing.assert_close(
        out["loss_total"],
        manual_node + manual_edge + 0.5 * manual_topology,
    )

    node_changed = changed_batch(
        batch,
        node_ids=plan.masked_node_indices,
    )
    node_out = model(
        node_changed,
        mask_plan=plan,
        return_predictions=True,
    )
    torch.testing.assert_close(
        out["pred_node_embedding"],
        node_out["pred_node_embedding"],
        rtol=0.0,
        atol=1e-6,
    )
    assert not torch.allclose(
        out["target_node_embedding"],
        node_out["target_node_embedding"],
    )
    assert not torch.allclose(
        out["loss_node_embedding"],
        node_out["loss_node_embedding"],
    )

    edge_changed = changed_batch(
        batch,
        physical_ids=plan.masked_physical_edge_indices,
    )
    edge_out = model(
        edge_changed,
        mask_plan=plan,
        return_predictions=True,
    )
    torch.testing.assert_close(
        out["pred_edge_embedding"],
        edge_out["pred_edge_embedding"],
        rtol=0.0,
        atol=1e-6,
    )
    assert not torch.allclose(
        out["target_edge_embedding"],
        edge_out["target_edge_embedding"],
    )
    assert not torch.allclose(
        out["loss_edge_embedding"],
        edge_out["loss_edge_embedding"],
    )

    unmasked = torch.nonzero(~plan.node_mask, as_tuple=False).flatten()
    context_out = model(
        changed_batch(batch, node_ids=unmasked),
        mask_plan=plan,
        return_predictions=True,
    )
    assert (
        not torch.allclose(
            out["pred_node_embedding"],
            context_out["pred_node_embedding"],
        )
        or not torch.allclose(
            out["pred_edge_embedding"],
            context_out["pred_edge_embedding"],
        )
        or not torch.allclose(
            out["topology_logits"],
            context_out["topology_logits"],
        )
    )

    model.train()
    train_out = model(batch, mask_plan=plan)
    train_out["loss"].backward()
    finite_gradients(model.backbone.geometry_encoder)
    first_iba = model.backbone.iba_dmp.layers[0]
    finite_gradients(first_iba.route_network)
    finite_gradients(first_iba.continuity_message_network)
    finite_gradients(first_iba.boundary_message_network)
    finite_gradients(model.node_embedding_decoder)
    finite_gradients(model.edge_relation_trunk)
    finite_gradients(model.edge_embedding_decoder)
    finite_gradients(model.topology_decoder)

    seam_batch = collate_brep_pretrain_model_input(
        [BRepPretrainModelInputSample("seam_only", make_graph_b())],
        statistics=statistics,
    )
    empty_plan = sample_brep_pretrain_mask_plan(
        seam_batch,
        node_mask_ratio=0.0,
        edge_mask_ratio=1.0,
        negative_edge_ratio=1.0,
        generator=torch.Generator().manual_seed(913),
        min_mask_nodes=0,
        min_mask_edges=1,
    )
    assert empty_plan.num_candidate_physical_edges == 0
    empty_out = model(
        seam_batch,
        mask_plan=empty_plan,
        return_predictions=True,
    )
    assert empty_out["num_mask_nodes"].item() == 0
    assert empty_out["num_mask_physical_edges"].item() == 0
    assert empty_out["num_topology_pos"].item() == 0
    assert empty_out["num_topology_neg"].item() == 0
    assert empty_out["loss_node_embedding"].item() == 0.0
    assert empty_out["loss_edge_embedding"].item() == 0.0
    assert empty_out["loss_topology"].item() == 0.0
    assert empty_out["loss_total"].requires_grad
    expected_batch_norms = {
        id(layer.edge_mpnn.norm_drop[0])
        for layer in model.backbone.iba_dmp.layers
    }
    actual_batch_norms = {
        id(module)
        for module in model.modules()
        if isinstance(module, nn.modules.batchnorm._BatchNorm)
    }
    assert actual_batch_norms == expected_batch_norms

    print("BREP_GRAPH_PHYSICAL_MESSAGE_PRETRAINER_CHECK_PASS")


if __name__ == "__main__":
    main()
