

import sys
from dataclasses import replace
from pathlib import Path

import dgl
import torch
from torch import nn


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
)
from models.brep_geometry_encoder import (
    BRepGeometryEncoder,
    BRepGeometryEncoding,
)
from models.brep_pretrain_input_masking import (
    BRepMaskedStudentInput,
    build_masked_brep_student_input,
    sample_brep_pretrain_mask_plan,
)
from models.graph_masking import (
    SINGLE_TOPOLOGY_CACHE_ATTR,
    build_single_graph_topology_cache,
)
from utils.brep_model_input_view import resolve_brep_model_input_statistics


def make_statistics():
    attr_stat = {
        "mean_face_attr": torch.zeros(16),
        "std_face_attr": torch.ones(16),
        "mean_edge_attr": torch.zeros(16),
        "std_edge_attr": torch.ones(16),
    }
    uv_stat = {
        "std_ddof": 0,
        "face_standardized_channels": [6, 7, 9],
        "mean_face_grid": torch.zeros(3),
        "std_face_grid": torch.ones(3),
        "count_face_grid": torch.tensor([20, 20, 20]),
        "edge_standardized_channels": [12, 14, 15],
        "mean_edge_grid": torch.zeros(3),
        "std_edge_grid": torch.ones(3),
        "count_edge_grid": torch.tensor([20, 20, 20]),
    }
    return resolve_brep_model_input_statistics(attr_stat, uv_stat)


def attach_features(graph, offset):
    node_count = graph.num_nodes()
    edge_count = graph.num_edges()
    graph.ndata["x"] = (
        torch.arange(node_count * 16, dtype=torch.float32).reshape(
            node_count, 16
        )
        / 10.0
        + offset
    )
    node_grid = torch.zeros(
        node_count,
        11,
        5,
        5,
        dtype=torch.float32,
    )
    row = torch.linspace(-1.0, 1.0, 5).reshape(1, 5)
    col = torch.linspace(-1.0, 1.0, 5).reshape(5, 1)
    for node_index in range(node_count):
        for channel in range(10):
            node_grid[node_index, channel] = (
                offset
                + node_index * 0.3
                + channel * 0.05
                + row * (channel + 1) * 0.02
                + col * (node_index + 1) * 0.03
            )
    node_grid[:, 10] = 1.0
    graph.ndata["grid"] = node_grid

    edge_attr = torch.zeros(edge_count, 16, dtype=torch.float32)
    edge_grid = torch.zeros(edge_count, 16, 5, dtype=torch.float32)
    samples = torch.linspace(0.0, 1.0, 5)
    for edge_index in range(edge_count):
        edge_attr[edge_index] = (
            torch.arange(16, dtype=torch.float32) * 0.03
            + edge_index * 0.2
            + offset
        )
        edge_attr[edge_index, edge_index % 3] = 1.0
        edge_grid[edge_index, 0, :] = samples + edge_index
        edge_grid[edge_index, 1, :] = 0.2 * samples + offset
        edge_grid[edge_index, 2, :] = 0.1 * edge_index
        edge_grid[edge_index, 3, :] = 1.0
        edge_grid[edge_index, 4, :] = 0.1 * edge_index
        edge_grid[edge_index, 5, :] = 0.0
        edge_grid[edge_index, 6:9, :] = torch.tensor(
            [0.0, 0.0, 1.0]
        ).reshape(3, 1)
        edge_grid[edge_index, 9:12, :] = torch.tensor(
            [0.0, 1.0, 0.0]
        ).reshape(3, 1)
        edge_grid[edge_index, 12, :] = 0.2 + samples * 0.1
        edge_grid[edge_index, 13, :] = -0.4 + samples * 0.2
        edge_grid[edge_index, 14, :] = 0.3 + samples * 0.2
        edge_grid[edge_index, 15, :] = -0.7 + samples * 0.3
    graph.edata["x"] = edge_attr
    graph.edata["grid"] = edge_grid

    face_uv = torch.zeros(edge_count, 2, 5, 2, dtype=torch.float32)
    face_uv_valid = torch.ones(edge_count, 2, 5, dtype=torch.bool)
    for edge_index in range(edge_count):
        face_uv[edge_index, 0, :, 0] = torch.linspace(-0.9, 0.7, 5)
        face_uv[edge_index, 0, :, 1] = -0.6 + edge_index * 0.1
        face_uv[edge_index, 1, :, 0] = 0.5 - edge_index * 0.1
        face_uv[edge_index, 1, :, 1] = torch.linspace(0.8, -0.8, 5)
    if edge_count:
        face_uv_valid[0, 0, 2] = False
        face_uv[0, 0, 2] = 0.0
    graph.edata["face_uv"] = face_uv
    graph.edata["face_uv_valid"] = face_uv_valid
    setattr(
        graph,
        SINGLE_TOPOLOGY_CACHE_ATTR,
        build_single_graph_topology_cache(graph),
    )
    return graph


def make_graph_a():
    return attach_features(
        dgl.graph(([0, 1, 2], [1, 2, 3]), num_nodes=4),
        0.0,
    )


def make_graph_b():
    graph = attach_features(
        dgl.graph(([0], [0]), num_nodes=2),
        2.0,
    )
    graph.edata["face_uv"][0, 0, :, 0] = -0.9
    graph.edata["face_uv"][0, 1, :, 0] = 0.9
    graph.edata["face_uv"][0, 0, :, 1] = torch.linspace(-0.8, 0.8, 5)
    graph.edata["face_uv"][0, 1, :, 1] = torch.linspace(0.8, -0.8, 5)
    graph.edata["face_uv_valid"][0] = True
    return graph


def make_batch(statistics, include_b=True):
    samples = [BRepPretrainModelInputSample("part_a", make_graph_a())]
    if include_b:
        samples.append(BRepPretrainModelInputSample("part_b", make_graph_b()))
    return collate_brep_pretrain_model_input(
        samples,
        statistics=statistics,
    )


def snapshot_model_input(model_input):
    message = model_input.message_view
    src, dst = message.message_graph.edges(order="eid")
    return {
        "node_attr": model_input.node_attr.clone(),
        "node_grid": model_input.node_grid.clone(),
        "edge_attr": message.message_edge_attr.clone(),
        "edge_grid": message.message_edge_grid.clone(),
        "uv": message.message_edge_face_uv.clone(),
        "valid": message.message_edge_face_uv_valid.clone(),
        "src": src.clone(),
        "dst": dst.clone(),
    }


def assert_model_input_unchanged(model_input, before):
    message = model_input.message_view
    torch.testing.assert_close(model_input.node_attr, before["node_attr"])
    torch.testing.assert_close(model_input.node_grid, before["node_grid"])
    torch.testing.assert_close(
        message.message_edge_attr,
        before["edge_attr"],
    )
    torch.testing.assert_close(
        message.message_edge_grid,
        before["edge_grid"],
    )
    torch.testing.assert_close(message.message_edge_face_uv, before["uv"])
    assert torch.equal(message.message_edge_face_uv_valid, before["valid"])
    src, dst = message.message_graph.edges(order="eid")
    assert torch.equal(src, before["src"])
    assert torch.equal(dst, before["dst"])


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def replace_full_message_view(model_input, **changes):
    return replace(
        model_input,
        message_view=replace(model_input.message_view, **changes),
    )


def check_full_direction_and_uv(encoder, batch):
    model_input = batch.model_input
    before = snapshot_model_input(model_input)
    full = encoder.encode_full(model_input)
    assert isinstance(full, BRepGeometryEncoding)
    assert full.node_feat.shape == (6, 128)
    assert full.message_edge_feat.shape == (8, 128)
    assert torch.all(torch.isfinite(full.node_feat))
    assert torch.all(torch.isfinite(full.message_edge_feat))
    for edge_index in range(4):
        assert not torch.allclose(
            full.message_edge_feat[2 * edge_index],
            full.message_edge_feat[2 * edge_index + 1],
        )

    modified_uv = model_input.message_view.message_edge_face_uv.clone()
    valid = model_input.message_view.message_edge_face_uv_valid
    modified_uv[0, 0, valid[0, 0], 0] = (
        -modified_uv[0, 0, valid[0, 0], 0] + 0.05
    ).clamp(-1.0, 1.0)
    uv_changed = encoder.encode_full(
        replace_full_message_view(
            model_input,
            message_edge_face_uv=modified_uv,
        )
    )
    assert not torch.allclose(
        full.message_edge_feat[0],
        uv_changed.message_edge_feat[0],
    )

    unrelated_grid = model_input.node_grid.clone()
    unrelated_grid[3, 0:10] += 17.0
    unrelated_changed = encoder.encode_full(
        replace(model_input, node_grid=unrelated_grid)
    )
    torch.testing.assert_close(
        full.message_edge_feat[0],
        unrelated_changed.message_edge_feat[0],
    )

    no_src_uv = model_input.message_view.message_edge_face_uv.clone()
    no_src_valid = (
        model_input.message_view.message_edge_face_uv_valid.clone()
    )
    no_src_uv[0, 0] = 0
    no_src_valid[0, 0] = False
    no_src_model = replace_full_message_view(
        model_input,
        message_edge_face_uv=no_src_uv,
        message_edge_face_uv_valid=no_src_valid,
    )
    no_src_encoding = encoder.encode_full(no_src_model)
    source_changed_grid = no_src_model.node_grid.clone()
    source_changed_grid[0, 0:10] += 31.0
    source_changed = encoder.encode_full(
        replace(no_src_model, node_grid=source_changed_grid)
    )
    torch.testing.assert_close(
        no_src_encoding.message_edge_feat[0],
        source_changed.message_edge_feat[0],
    )

    fake_maps = torch.arange(
        1,
        model_input.node_attr.shape[0] + 1,
        dtype=torch.float32,
    ).reshape(-1, 1, 1, 1).expand(-1, 64, 5, 5)
    message_src, message_dst = (
        model_input.message_view.message_graph.edges(order="eid")
    )
    all_valid = torch.ones(8, 5, dtype=torch.bool)
    src_samples = encoder._sample_face_feature_map(
        fake_maps,
        message_src,
        model_input.message_view.message_edge_face_uv[:, 0],
        all_valid,
    )
    dst_samples = encoder._sample_face_feature_map(
        fake_maps,
        message_dst,
        model_input.message_view.message_edge_face_uv[:, 1],
        all_valid,
    )
    for message_index in range(8):
        assert torch.allclose(
            src_samples[message_index],
            torch.full(
                (64, 5),
                float(message_src[message_index] + 1),
            ),
        )
        assert torch.allclose(
            dst_samples[message_index],
            torch.full(
                (64, 5),
                float(message_dst[message_index] + 1),
            ),
        )
    assert message_src[0] == message_dst[1]
    assert message_dst[0] == message_src[1]
    assert_model_input_unchanged(model_input, before)
    return full


def make_empty_message_student(student):
    empty_graph = dgl.graph(
        (
            torch.empty(0, dtype=torch.int64),
            torch.empty(0, dtype=torch.int64),
        ),
        num_nodes=student.message_graph.num_nodes(),
    )
    empty_graph.set_batch_num_nodes(student.message_graph.batch_num_nodes())
    empty_graph.set_batch_num_edges(
        torch.zeros_like(student.message_graph.batch_num_edges())
    )
    return replace(
        student,
        message_graph=empty_graph,
        message_edge_attr=student.message_edge_attr[:0],
        message_edge_grid=student.message_edge_grid[:0],
        message_edge_face_uv=student.message_edge_face_uv[:0],
        message_edge_face_uv_valid=student.message_edge_face_uv_valid[:0],
        message_to_physical_edge=student.message_to_physical_edge[:0],
        message_is_reverse=student.message_is_reverse[:0],
        message_is_self_loop=student.message_is_self_loop[:0],
        kept_original_message_indices=student.kept_original_message_indices[:0],
    )


def check_student_mask_token_and_deletion(encoder, statistics):
    batch = make_batch(statistics, include_b=False)
    node_plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.0,
        negative_edge_ratio=0.0,
        generator=torch.Generator().manual_seed(101),
        min_mask_nodes=1,
        min_mask_edges=0,
    )
    node_student = build_masked_brep_student_input(batch, node_plan)
    assert torch.all(node_student.node_attr[node_plan.node_mask] == 0)
    assert torch.all(node_student.node_grid[node_plan.node_mask] == 0)
    student_before = {
        "node_attr": node_student.node_attr.clone(),
        "node_grid": node_student.node_grid.clone(),
        "edge_attr": node_student.message_edge_attr.clone(),
        "edge_grid": node_student.message_edge_grid.clone(),
        "uv": node_student.message_edge_face_uv.clone(),
        "valid": node_student.message_edge_face_uv_valid.clone(),
        "src": node_student.message_graph.edges(order="eid")[0].clone(),
        "dst": node_student.message_graph.edges(order="eid")[1].clone(),
    }
    encoded = encoder.encode_student(node_student, node_plan.node_mask)
    assert encoded.node_feat.shape == (4, 128)
    assert encoded.message_edge_feat.shape == (6, 128)

    with torch.no_grad():
        saved_token = encoder.node_mask_token.clone()
        encoder.node_mask_token.add_(0.25)
    changed_token = encoder.encode_student(
        node_student,
        node_plan.node_mask,
    )
    with torch.no_grad():
        encoder.node_mask_token.copy_(saved_token)
    assert not torch.allclose(
        encoded.node_feat[node_plan.node_mask],
        changed_token.node_feat[node_plan.node_mask],
    )
    torch.testing.assert_close(
        encoded.node_feat[~node_plan.node_mask],
        changed_token.node_feat[~node_plan.node_mask],
    )

    empty_student = make_empty_message_student(node_student)
    no_context = encoder.encode_student(
        empty_student,
        node_plan.node_mask,
    )
    assert torch.all(torch.isfinite(no_context.node_feat))
    assert not torch.allclose(
        encoded.node_feat[node_plan.node_mask],
        no_context.node_feat[node_plan.node_mask],
    )
    torch.testing.assert_close(
        node_student.node_attr,
        student_before["node_attr"],
    )
    torch.testing.assert_close(
        node_student.node_grid,
        student_before["node_grid"],
    )
    torch.testing.assert_close(
        node_student.message_edge_attr,
        student_before["edge_attr"],
    )
    torch.testing.assert_close(
        node_student.message_edge_grid,
        student_before["edge_grid"],
    )
    torch.testing.assert_close(
        node_student.message_edge_face_uv,
        student_before["uv"],
    )
    assert torch.equal(
        node_student.message_edge_face_uv_valid,
        student_before["valid"],
    )
    student_src, student_dst = node_student.message_graph.edges(order="eid")
    assert torch.equal(student_src, student_before["src"])
    assert torch.equal(student_dst, student_before["dst"])

    edge_plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.0,
        edge_mask_ratio=0.34,
        negative_edge_ratio=0.0,
        generator=torch.Generator().manual_seed(102),
        min_mask_nodes=0,
        min_mask_edges=1,
    )
    edge_student = build_masked_brep_student_input(batch, edge_plan)
    edge_encoded = encoder.encode_student(
        edge_student,
        edge_plan.node_mask,
    )
    assert edge_encoded.message_edge_feat.shape[0] == 4
    masked_physical = edge_plan.masked_physical_edge_indices[0]
    assert not torch.any(
        edge_student.message_to_physical_edge == masked_physical
    )


def check_single_item_group_norm(encoder, statistics):
    seam_batch = collate_brep_pretrain_model_input(
        [BRepPretrainModelInputSample("part_b", make_graph_b())],
        statistics=statistics,
    )
    full = seam_batch.model_input
    message = full.message_view
    one_graph = dgl.graph(([0], [0]), num_nodes=1)
    one_graph.set_batch_num_nodes(torch.tensor([1]))
    one_graph.set_batch_num_edges(torch.tensor([1]))
    one_student = BRepMaskedStudentInput(
        node_attr=full.node_attr[:1].clone(),
        node_grid=full.node_grid[:1].clone(),
        message_graph=one_graph,
        message_edge_attr=message.message_edge_attr[:1].clone(),
        message_edge_grid=message.message_edge_grid[:1].clone(),
        message_edge_face_uv=message.message_edge_face_uv[:1].clone(),
        message_edge_face_uv_valid=(
            message.message_edge_face_uv_valid[:1].clone()
        ),
        message_to_physical_edge=torch.tensor([0]),
        message_is_reverse=torch.tensor([False]),
        message_is_self_loop=torch.tensor([True]),
        kept_original_message_indices=torch.tensor([0]),
        physical_num_nodes=1,
        physical_num_edges=1,
        physical_batch_num_nodes=torch.tensor([1]),
        physical_batch_num_edges=torch.tensor([1]),
    )
    result = encoder.encode_student(
        one_student,
        torch.tensor([False]),
    )
    assert result.node_feat.shape == (1, 128)
    assert result.message_edge_feat.shape == (1, 128)


def check_errors(encoder, statistics):
    batch = make_batch(statistics, include_b=False)
    model_input = batch.model_input
    expect_error(TypeError, lambda: encoder.encode_full(object()))

    wrong_shape = replace(
        model_input,
        node_attr=model_input.node_attr[:, :15],
    )
    expect_error(ValueError, lambda: encoder.encode_full(wrong_shape))
    wrong_dtype = replace_full_message_view(
        model_input,
        message_edge_grid=(
            model_input.message_view.message_edge_grid.to(torch.float64)
        ),
    )
    expect_error(TypeError, lambda: encoder.encode_full(wrong_dtype))

    invalid_uv = model_input.message_view.message_edge_face_uv.clone()
    invalid = ~model_input.message_view.message_edge_face_uv_valid
    invalid_index = torch.nonzero(invalid, as_tuple=False)[0]
    invalid_uv[
        invalid_index[0],
        invalid_index[1],
        invalid_index[2],
    ] = torch.tensor([0.2, -0.2])
    expect_error(
        ValueError,
        lambda: encoder.encode_full(
            replace_full_message_view(
                model_input,
                message_edge_face_uv=invalid_uv,
            )
        ),
    )

    nan_attr = model_input.node_attr.clone()
    nan_attr[0, 0] = float("nan")
    expect_error(
        ValueError,
        lambda: encoder.encode_full(
            replace(model_input, node_attr=nan_attr)
        ),
    )

    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.0,
        negative_edge_ratio=0.0,
        generator=torch.Generator().manual_seed(103),
        min_mask_nodes=1,
        min_mask_edges=0,
    )
    student = build_masked_brep_student_input(batch, plan)
    expect_error(
        TypeError,
        lambda: encoder.encode_student(student, plan.node_mask.float()),
    )
    expect_error(
        ValueError,
        lambda: encoder.encode_student(student, plan.node_mask[:-1]),
    )
    leaked_attr = student.node_attr.clone()
    leaked_attr[plan.node_mask, 0] = 1.0
    expect_error(
        ValueError,
        lambda: encoder.encode_student(
            replace(student, node_attr=leaked_attr),
            plan.node_mask,
        ),
    )

    meta_encoder = BRepGeometryEncoder().to("meta")
    meta_encoder.eval()
    expect_error(
        ValueError,
        lambda: meta_encoder.encode_full(model_input),
    )


def main():
    torch.manual_seed(20260725)
    statistics = make_statistics()
    batch = make_batch(statistics, include_b=True)
    encoder = BRepGeometryEncoder()
    encoder.eval()
    assert not any(
        isinstance(module, nn.modules.batchnorm._BatchNorm)
        for module in encoder.modules()
    )

    full = check_full_direction_and_uv(encoder, batch)
    seam_forward = full.message_edge_feat[-2]
    seam_reverse = full.message_edge_feat[-1]
    assert not torch.allclose(seam_forward, seam_reverse)
    check_student_mask_token_and_deletion(encoder, statistics)
    check_single_item_group_norm(encoder, statistics)
    check_errors(encoder, statistics)

    first = encoder.encode_full(batch.model_input)
    second = encoder.encode_full(batch.model_input)
    torch.testing.assert_close(
        first.node_feat,
        second.node_feat,
        rtol=0.0,
        atol=1e-7,
    )
    torch.testing.assert_close(
        first.message_edge_feat,
        second.message_edge_feat,
        rtol=0.0,
        atol=1e-7,
    )
    print("BREP_GRAPH_GEOMETRY_ENCODER_CHECK_PASS")
    print("full_shapes=node[6,128] message_edge[8,128]")
    print("direction_and_pcurve_sampling=PASS seam=PASS")
    print("student_mask_token_and_edge_deletion=PASS")
    print("groupnorm_determinism_and_strict_inputs=PASS")


if __name__ == "__main__":
    main()
