

import copy
from dataclasses import fields
from pathlib import Path
import sys

import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
    validate_brep_pretrain_filelist_override,
)
from dataloader.mfinstseg_physical_message import (
    BRepSupervisedModelInputBatch,
    BRepSupervisedModelInputSample,
    MFInstSegPhysicalMessageDataset,
    collate_mfinstseg_physical_message,
    move_brep_supervised_model_input_batch,
    parse_mfinstseg_supervised_labels,
)
from dataset.quality_export.check_brep_graph_pretrain_model_input_loader import (
    make_graph_a,
    make_graph_b,
    make_statistics,
    snapshot_graph,
    assert_graph_unchanged,
)
from models.graph_masking import BATCH_TOPOLOGY_CACHE_ATTR
from utils.brep_model_input_view import resolve_brep_model_input_statistics


def expect_error(error_type, callback):
    try:
        callback()
    except error_type:
        return
    raise AssertionError(f"Expected {error_type.__name__}")


def make_supervised_samples():
    graph_a = make_graph_a()
    graph_b = make_graph_b()
    sample_a = BRepSupervisedModelInputSample(
        part_id="part_a",
        geometry_sample=BRepPretrainModelInputSample("part_a", graph_a),
        seg_y=torch.tensor([0, 1, 12], dtype=torch.int64),
        inst_y=torch.tensor(
            [[1, 1, 0], [1, 1, 0], [0, 0, 1]],
            dtype=torch.float32,
        ),
        quality=torch.tensor(
            [[-1.0, 0.0], [0.5, 1.0], [2.0, -0.5]],
            dtype=torch.float32,
        ),
        process_y=torch.tensor([-1, 0, 1], dtype=torch.int64),
    )
    sample_b = BRepSupervisedModelInputSample(
        part_id="part_b",
        geometry_sample=BRepPretrainModelInputSample("part_b", graph_b),
        seg_y=torch.tensor([2, 3], dtype=torch.int64),
        inst_y=torch.eye(2, dtype=torch.float32),
        quality=torch.tensor(
            [[1.5, -1.0], [0.25, 0.75]],
            dtype=torch.float32,
        ),
        process_y=torch.tensor([1, 0], dtype=torch.int64),
    )
    return sample_a, sample_b


def assert_model_inputs_equal(left, right):
    torch.testing.assert_close(left.node_attr, right.node_attr)
    torch.testing.assert_close(left.node_grid, right.node_grid)
    assert left.physical_num_nodes == right.physical_num_nodes
    assert left.physical_num_edges == right.physical_num_edges
    torch.testing.assert_close(
        left.physical_batch_num_nodes,
        right.physical_batch_num_nodes,
    )
    torch.testing.assert_close(
        left.physical_batch_num_edges,
        right.physical_batch_num_edges,
    )
    left_view = left.message_view
    right_view = right.message_view
    left_src, left_dst = left_view.message_graph.edges(order="eid")
    right_src, right_dst = right_view.message_graph.edges(order="eid")
    assert torch.equal(left_src, right_src)
    assert torch.equal(left_dst, right_dst)
    for name in (
        "message_edge_attr",
        "message_edge_grid",
        "message_edge_face_uv",
        "message_edge_face_uv_valid",
        "message_to_physical_edge",
        "message_is_reverse",
        "message_is_self_loop",
        "physical_to_forward_message",
        "physical_to_reverse_message",
    ):
        torch.testing.assert_close(
            getattr(left_view, name),
            getattr(right_view, name),
        )


def check_label_parser():
    labels = [
        [
            "part_a",
            {
                "seg": {"0": 0, "1": 1, "2": 24},
                "inst": [[1, 1, 0], [1, 1, 0], [0, 0, 1]],
                "process_type": {"0": -1, "1": 0, "2": 1},
                "roughness": {"0": 1.0, "1": 3.0, "2": 5.0},
                "tolerance": {"0": 2.0, "1": 4.0, "2": 6.0},
            },
        ]
    ]
    seg, inst, quality, process = parse_mfinstseg_supervised_labels(
        "part_a",
        labels,
        3,
        dataset_type="tiny",
        quality_mean=[1.0, 2.0],
        quality_std=[2.0, 2.0],
    )
    assert torch.equal(seg, torch.tensor([0, 1, 12]))
    assert inst.shape == (3, 3)
    torch.testing.assert_close(
        quality,
        torch.tensor([[0.0, 0.0], [1.0, 1.0], [2.0, 2.0]]),
    )
    assert torch.equal(process, torch.tensor([-1, 0, 1]))

    bad_process = copy.deepcopy(labels)
    bad_process[0][1]["process_type"]["1"] = 2
    expect_error(
        ValueError,
        lambda: parse_mfinstseg_supervised_labels(
            "part_a",
            bad_process,
            3,
            dataset_type="tiny",
            quality_mean=[0.0, 0.0],
            quality_std=[1.0, 1.0],
        ),
    )
    ragged = copy.deepcopy(labels)
    ragged[0][1]["inst"] = [[1, 0], [0]]
    expect_error(
        ValueError,
        lambda: parse_mfinstseg_supervised_labels(
            "part_a",
            ragged,
            3,
            dataset_type="tiny",
            quality_mean=[0.0, 0.0],
            quality_std=[1.0, 1.0],
        ),
    )
    nonfinite = copy.deepcopy(labels)
    nonfinite[0][1]["roughness"]["0"] = float("nan")
    expect_error(
        ValueError,
        lambda: parse_mfinstseg_supervised_labels(
            "part_a",
            nonfinite,
            3,
            dataset_type="tiny",
            quality_mean=[0.0, 0.0],
            quality_std=[1.0, 1.0],
        ),
    )


def check_override_protocol():
    formal_train = ["part_c", "part_a", "part_b"]
    result = validate_brep_pretrain_filelist_override(
        "train",
        ["part_b", "part_a"],
        formal_train,
    )
    assert result == ["part_b", "part_a"]
    expect_error(
        ValueError,
        lambda: validate_brep_pretrain_filelist_override(
            "eval", ["part_a"], formal_train
        ),
    )
    expect_error(
        ValueError,
        lambda: validate_brep_pretrain_filelist_override(
            "train", ["part_a", "part_a"], formal_train
        ),
    )
    expect_error(
        ValueError,
        lambda: validate_brep_pretrain_filelist_override(
            "train", ["eval_only"], formal_train
        ),
    )
    expect_error(
        ValueError,
        lambda: MFInstSegPhysicalMessageDataset(
            "unused",
            random_rotate=True,
            quality_stat_path="unused",
        ),
    )


def main():
    attr_stat, uv_stat = make_statistics()
    statistics = resolve_brep_model_input_statistics(attr_stat, uv_stat)
    sample_a, sample_b = make_supervised_samples()
    graph_a = sample_a.geometry_sample.physical_graph
    graph_b = sample_b.geometry_sample.physical_graph
    before_a = snapshot_graph(graph_a)
    before_b = snapshot_graph(graph_b)
    labels_before = {
        name: getattr(sample_a, name).clone()
        for name in ("seg_y", "inst_y", "quality", "process_y")
    }

    batch = collate_mfinstseg_physical_message(
        [sample_a, sample_b],
        statistics=statistics,
    )
    assert isinstance(batch, BRepSupervisedModelInputBatch)
    assert batch.part_ids == ("part_a", "part_b")
    direct_geometry = collate_brep_pretrain_model_input(
        [sample_a.geometry_sample, sample_b.geometry_sample],
        statistics=statistics,
    )
    assert_model_inputs_equal(batch.model_input, direct_geometry.model_input)
    assert batch.physical_topology_graph.num_edges() == 3
    assert batch.model_input.message_view.message_graph.num_edges() == 6
    assert torch.equal(batch.seg_y, torch.tensor([0, 1, 12, 2, 3]))
    torch.testing.assert_close(
        batch.quality,
        torch.cat((sample_a.quality, sample_b.quality)),
    )
    assert torch.equal(
        batch.process_y,
        torch.tensor([-1, 0, 1, 1, 0]),
    )
    assert batch.inst_labels.shape == (2, 3, 3)
    torch.testing.assert_close(batch.inst_labels[0], sample_a.inst_y)
    torch.testing.assert_close(
        batch.inst_labels[1, :2, :2],
        sample_b.inst_y,
    )
    assert torch.equal(
        batch.inst_masks[0],
        torch.ones(3, 3),
    )
    assert torch.equal(
        batch.inst_masks[1],
        torch.tensor(
            [[1.0, 1.0, 0.0], [1.0, 1.0, 0.0], [0.0, 0.0, 0.0]]
        ),
    )
    assert len(batch.physical_topology_graph.ndata) == 0
    assert len(batch.physical_topology_graph.edata) == 0
    message_graph = batch.model_input.message_view.message_graph
    assert len(message_graph.ndata) == 0
    assert len(message_graph.edata) == 0
    output_fields = {field.name for field in fields(type(batch))}
    assert "raw_physical_graph" not in output_fields
    assert "raw_graph" not in output_fields

    moved = move_brep_supervised_model_input_batch(batch, "cpu")
    assert moved is not batch
    assert moved.model_input.node_attr.data_ptr() != (
        batch.model_input.node_attr.data_ptr()
    )
    assert hasattr(
        moved.physical_topology_graph,
        BATCH_TOPOLOGY_CACHE_ATTR,
    )
    assert moved.seg_y.device.type == "cpu"
    assert_graph_unchanged(graph_a, before_a)
    assert_graph_unchanged(graph_b, before_b)
    for name, value in labels_before.items():
        assert torch.equal(getattr(sample_a, name), value)

    expect_error(
        ValueError,
        lambda: collate_mfinstseg_physical_message(
            [
                sample_a,
                BRepSupervisedModelInputSample(
                    "part_a",
                    BRepPretrainModelInputSample("part_a", make_graph_b()),
                    torch.tensor([1, 2], dtype=torch.int64),
                    torch.eye(2),
                    torch.zeros(2, 2),
                    torch.tensor([0, 1], dtype=torch.int64),
                ),
            ],
            statistics=statistics,
        ),
    )
    expect_error(
        ValueError,
        lambda: BRepSupervisedModelInputSample(
            "bad_count",
            BRepPretrainModelInputSample("bad_count", make_graph_a()),
            torch.tensor([0, 1], dtype=torch.int64),
            torch.eye(3),
            torch.zeros(3, 2),
            torch.tensor([0, 1, -1], dtype=torch.int64),
        ),
    )
    check_label_parser()
    check_override_protocol()
    print("MFINSTSEG_PHYSICAL_MESSAGE_LOADER_CHECK_PASS")


if __name__ == "__main__":
    main()
