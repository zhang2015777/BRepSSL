

import copy
import sys
from dataclasses import fields
from pathlib import Path

import dgl
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepPretrainModelInputBatch,
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
)
from models.graph_masking import (
    BATCH_TOPOLOGY_CACHE_ATTR,
    SINGLE_TOPOLOGY_CACHE_ATTR,
    build_single_graph_topology_cache,
)
from utils.brep_model_input_view import resolve_brep_model_input_statistics


def make_statistics():
    attr_stat = {
        "mean_face_attr": torch.linspace(-1.0, 1.0, 16),
        "std_face_attr": torch.linspace(0.5, 2.0, 16),
        "mean_edge_attr": torch.linspace(-2.0, 2.0, 16),
        "std_edge_attr": torch.linspace(0.75, 2.25, 16),
    }
    uv_stat = {
        "std_ddof": 0,
        "face_standardized_channels": [6, 7, 9],
        "mean_face_grid": torch.tensor([1.0, -2.0, 3.0]),
        "std_face_grid": torch.tensor([2.0, 4.0, 5.0]),
        "count_face_grid": torch.tensor([11, 12, 13]),
        "edge_standardized_channels": [12, 14, 15],
        "mean_edge_grid": torch.tensor([2.0, 1.0, 5.0]),
        "std_edge_grid": torch.tensor([3.0, 2.0, 4.0]),
        "count_edge_grid": torch.tensor([7, 3, 5]),
    }
    return attr_stat, uv_stat


def attach_raw_features(graph, value_offset):
    node_count = graph.num_nodes()
    edge_count = graph.num_edges()
    graph.ndata["x"] = (
        torch.arange(node_count * 16, dtype=torch.float32).reshape(
            node_count, 16
        )
        + value_offset
    )
    graph.ndata["grid"] = (
        torch.arange(
            node_count * 11 * 5 * 5,
            dtype=torch.float32,
        ).reshape(node_count, 11, 5, 5)
        + 100.0
        + value_offset
    )
    graph.ndata["grid"][:, 10] = (
        torch.arange(25, dtype=torch.float32).reshape(1, 5, 5) % 2
    )

    graph.edata["x"] = (
        torch.arange(edge_count * 16, dtype=torch.float32).reshape(
            edge_count, 16
        )
        + 200.0
        + value_offset
    )
    graph.edata["grid"] = (
        torch.arange(
            edge_count * 16 * 5,
            dtype=torch.float32,
        ).reshape(edge_count, 16, 5)
        + 300.0
        + value_offset
    )
    if edge_count:
        graph.edata["grid"][0, 3:6, 1] = 0.0

    face_uv = torch.zeros(edge_count, 2, 5, 2, dtype=torch.float32)
    face_uv_valid = torch.ones(edge_count, 2, 5, dtype=torch.bool)
    for edge_index in range(edge_count):
        for side in range(2):
            for sample_index in range(5):
                face_uv[edge_index, side, sample_index] = torch.tensor(
                    [
                        -0.8 + 0.1 * sample_index + 0.03 * side,
                        0.8 - 0.1 * sample_index - 0.02 * edge_index,
                    ],
                    dtype=torch.float32,
                )
    if edge_count:
        face_uv_valid[0, 0, 2] = False
        face_uv[0, 0, 2] = 0.0
    graph.edata["face_uv"] = face_uv
    graph.edata["face_uv_valid"] = face_uv_valid

    setattr(
        graph,
        SINGLE_TOPOLOGY_CACHE_ATTR,
        build_single_graph_topology_cache(graph),
    )
    return graph


def make_graph_a():
    return attach_raw_features(
        dgl.graph(([0, 1], [1, 2]), num_nodes=3),
        0.0,
    )


def make_graph_b():
    return attach_raw_features(
        dgl.graph(([0], [0]), num_nodes=2),
        1000.0,
    )


def snapshot_graph(graph):
    src, dst = graph.edges(order="eid")
    return {
        "src": src.clone(),
        "dst": dst.clone(),
        "ndata": {
            key: value.clone() for key, value in graph.ndata.items()
        },
        "edata": {
            key: value.clone() for key, value in graph.edata.items()
        },
    }


def assert_graph_unchanged(graph, before):
    src, dst = graph.edges(order="eid")
    assert torch.equal(src, before["src"])
    assert torch.equal(dst, before["dst"])
    assert set(graph.ndata.keys()) == set(before["ndata"])
    assert set(graph.edata.keys()) == set(before["edata"])
    for key, value in before["ndata"].items():
        assert torch.equal(graph.ndata[key], value)
    for key, value in before["edata"].items():
        assert torch.equal(graph.edata[key], value)


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def standardize_masked(values, valid, mean, std):
    result = torch.zeros_like(values)
    result[valid] = (values[valid] - mean) / std
    return result


def assert_model_input(batch, graph_a, graph_b, statistics):
    model_input = batch.model_input
    raw_batched = dgl.batch([graph_a, graph_b])
    expected_node_attr = (
        raw_batched.ndata["x"] - statistics.face_attr_mean
    ) / statistics.face_attr_std
    torch.testing.assert_close(model_input.node_attr, expected_node_attr)

    expected_node_grid = raw_batched.ndata["grid"].clone()
    for offset, channel in enumerate((6, 7, 9)):
        expected_node_grid[:, channel] = (
            expected_node_grid[:, channel]
            - statistics.face_grid_mean[offset]
        ) / statistics.face_grid_std[offset]
    torch.testing.assert_close(model_input.node_grid, expected_node_grid)
    for channel in (0, 1, 2, 3, 4, 5, 8, 10):
        torch.testing.assert_close(
            model_input.node_grid[:, channel],
            raw_batched.ndata["grid"][:, channel],
        )
    assert torch.equal(
        model_input.node_grid[:, 10],
        raw_batched.ndata["grid"][:, 10],
    )

    message_view = model_input.message_view
    edge_statistics = statistics.message_edge_statistics
    expected_edge_attr = (
        raw_batched.edata["x"] - edge_statistics.edge_attr_mean
    ) / edge_statistics.edge_attr_std
    torch.testing.assert_close(
        message_view.message_edge_attr[0::2],
        expected_edge_attr,
    )
    torch.testing.assert_close(
        message_view.message_edge_attr[1::2],
        expected_edge_attr,
    )

    raw_grid = raw_batched.edata["grid"]
    tangent_valid = (
        torch.linalg.vector_norm(raw_grid[:, 3:6], dim=1) > 1e-12
    )
    expected_12 = standardize_masked(
        raw_grid[:, 12],
        tangent_valid,
        edge_statistics.curve_curvature_mean,
        edge_statistics.curve_curvature_std,
    )
    torch.testing.assert_close(
        message_view.message_edge_grid[0::2, 12],
        expected_12,
    )
    torch.testing.assert_close(
        message_view.message_edge_grid[1::2, 12],
        torch.flip(expected_12, dims=(1,)),
    )

    expected_14 = standardize_masked(
        raw_grid[:, 14],
        raw_batched.edata["face_uv_valid"][:, 0],
        edge_statistics.side_normal_curvature_mean,
        edge_statistics.side_normal_curvature_std,
    )
    expected_15 = standardize_masked(
        raw_grid[:, 15],
        raw_batched.edata["face_uv_valid"][:, 1],
        edge_statistics.side_normal_curvature_mean,
        edge_statistics.side_normal_curvature_std,
    )
    torch.testing.assert_close(
        message_view.message_edge_grid[0::2, 14],
        expected_14,
    )
    torch.testing.assert_close(
        message_view.message_edge_grid[0::2, 15],
        expected_15,
    )
    torch.testing.assert_close(
        message_view.message_edge_grid[1::2, 14],
        torch.flip(expected_15, dims=(1,)),
    )
    torch.testing.assert_close(
        message_view.message_edge_grid[1::2, 15],
        torch.flip(expected_14, dims=(1,)),
    )


def assert_batch_protocol(batch, graph_a, graph_b, statistics):
    assert isinstance(batch, BRepPretrainModelInputBatch)
    assert batch.part_ids == ("part_a", "part_b")
    topology = batch.physical_topology_graph
    assert topology.num_nodes() == 5
    assert topology.num_edges() == 3
    assert torch.equal(topology.batch_num_nodes(), torch.tensor([3, 2]))
    assert torch.equal(topology.batch_num_edges(), torch.tensor([2, 1]))
    assert len(topology.ndata) == 0
    assert len(topology.edata) == 0

    topology_cache = getattr(topology, BATCH_TOPOLOGY_CACHE_ATTR)
    assert [record["node_count"] for record in topology_cache] == [3, 2]
    assert [record["edge_count"] for record in topology_cache] == [2, 1]
    assert sum(record["edge_count"] for record in topology_cache) == 3

    model_input = batch.model_input
    assert model_input.physical_num_nodes == 5
    assert model_input.physical_num_edges == 3
    assert torch.equal(
        model_input.physical_batch_num_nodes,
        torch.tensor([3, 2]),
    )
    assert torch.equal(
        model_input.physical_batch_num_edges,
        torch.tensor([2, 1]),
    )
    message_graph = model_input.message_view.message_graph
    assert message_graph.num_edges() == 6
    assert torch.equal(
        message_graph.batch_num_edges(),
        torch.tensor([4, 2]),
    )
    assert len(message_graph.ndata) == 0
    assert len(message_graph.edata) == 0

    message_src, message_dst = message_graph.edges(order="eid")
    assert torch.equal(
        message_src,
        torch.tensor([0, 1, 1, 2, 3, 3]),
    )
    assert torch.equal(
        message_dst,
        torch.tensor([1, 0, 2, 1, 3, 3]),
    )
    assert torch.equal(
        model_input.message_view.message_is_self_loop,
        torch.tensor([False, False, False, False, True, True]),
    )
    assert model_input.node_attr.device == graph_a.device
    assert message_graph.device == graph_a.device

    output_fields = {field.name for field in fields(type(batch))}
    for forbidden in (
        "raw_batched_graph",
        "raw_physical_graph",
        "raw_node_attr",
        "raw_edge_attr",
        "raw_node_grid",
        "raw_edge_grid",
        "seg_y",
        "process_y",
        "quality",
        "bottom_y",
    ):
        assert forbidden not in output_fields
    assert_model_input(batch, graph_a, graph_b, statistics)


def check_failure_paths(statistics):
    graph_a = make_graph_a()
    graph_b = make_graph_b()
    sample_a = BRepPretrainModelInputSample("part_a", graph_a)
    sample_b = BRepPretrainModelInputSample("part_b", graph_b)

    expect_error(
        ValueError,
        lambda: collate_brep_pretrain_model_input(
            [],
            statistics=statistics,
        ),
    )
    expect_error(
        TypeError,
        lambda: collate_brep_pretrain_model_input(
            [object()],
            statistics=statistics,
        ),
    )
    expect_error(
        TypeError,
        lambda: collate_brep_pretrain_model_input(
            [sample_a],
            statistics=None,
        ),
    )
    expect_error(
        TypeError,
        lambda: collate_brep_pretrain_model_input(
            [sample_a],
            statistics=object(),
        ),
    )
    expect_error(
        ValueError,
        lambda: collate_brep_pretrain_model_input(
            [
                sample_a,
                BRepPretrainModelInputSample("part_a", graph_b),
            ],
            statistics=statistics,
        ),
    )

    labeled_seg = make_graph_a()
    labeled_seg.ndata["seg_y"] = torch.zeros(
        labeled_seg.num_nodes(),
        dtype=torch.int64,
    )
    expect_error(
        ValueError,
        lambda: collate_brep_pretrain_model_input(
            [BRepPretrainModelInputSample("seg", labeled_seg)],
            statistics=statistics,
        ),
    )
    labeled_quality = make_graph_a()
    labeled_quality.ndata["quality"] = torch.zeros(
        labeled_quality.num_nodes(),
        2,
    )
    expect_error(
        ValueError,
        lambda: collate_brep_pretrain_model_input(
            [
                BRepPretrainModelInputSample(
                    "quality",
                    labeled_quality,
                )
            ],
            statistics=statistics,
        ),
    )

    bad_node_cache = make_graph_a()
    bad_node_cache_value = copy.deepcopy(
        getattr(bad_node_cache, SINGLE_TOPOLOGY_CACHE_ATTR)
    )
    bad_node_cache_value["num_nodes"] += 1
    setattr(
        bad_node_cache,
        SINGLE_TOPOLOGY_CACHE_ATTR,
        bad_node_cache_value,
    )
    expect_error(
        ValueError,
        lambda: collate_brep_pretrain_model_input(
            [BRepPretrainModelInputSample("bad_nodes", bad_node_cache)],
            statistics=statistics,
        ),
    )

    bad_edge_cache = make_graph_a()
    bad_edge_cache_value = copy.deepcopy(
        getattr(bad_edge_cache, SINGLE_TOPOLOGY_CACHE_ATTR)
    )
    bad_edge_cache_value["num_edges"] += 1
    setattr(
        bad_edge_cache,
        SINGLE_TOPOLOGY_CACHE_ATTR,
        bad_edge_cache_value,
    )
    expect_error(
        ValueError,
        lambda: collate_brep_pretrain_model_input(
            [BRepPretrainModelInputSample("bad_edges", bad_edge_cache)],
            statistics=statistics,
        ),
    )

def check_single_graph_batches(statistics):
    graph_a = make_graph_a()
    graph_a_batch = collate_brep_pretrain_model_input(
        [BRepPretrainModelInputSample("part_a", graph_a)],
        statistics=statistics,
    )
    assert graph_a_batch.part_ids == ("part_a",)
    assert torch.equal(
        graph_a_batch.physical_topology_graph.batch_num_nodes(),
        torch.tensor([3]),
    )
    assert torch.equal(
        graph_a_batch.physical_topology_graph.batch_num_edges(),
        torch.tensor([2]),
    )
    assert torch.equal(
        graph_a_batch.model_input.message_view.message_graph.batch_num_edges(),
        torch.tensor([4]),
    )

    graph_b = make_graph_b()
    graph_b_batch = collate_brep_pretrain_model_input(
        [BRepPretrainModelInputSample("part_b", graph_b)],
        statistics=statistics,
    )
    assert graph_b_batch.part_ids == ("part_b",)
    assert torch.equal(
        graph_b_batch.physical_topology_graph.batch_num_nodes(),
        torch.tensor([2]),
    )
    assert torch.equal(
        graph_b_batch.physical_topology_graph.batch_num_edges(),
        torch.tensor([1]),
    )
    seam_message = graph_b_batch.model_input.message_view
    assert torch.equal(
        seam_message.message_graph.batch_num_edges(),
        torch.tensor([2]),
    )
    seam_src, seam_dst = seam_message.message_graph.edges(order="eid")
    assert torch.equal(seam_src, torch.tensor([0, 0]))
    assert torch.equal(seam_dst, torch.tensor([0, 0]))
    assert torch.equal(
        seam_message.message_is_self_loop,
        torch.tensor([True, True]),
    )


def main():
    attr_stat, uv_stat = make_statistics()
    attr_before = copy.deepcopy(attr_stat)
    uv_before = copy.deepcopy(uv_stat)
    statistics = resolve_brep_model_input_statistics(attr_stat, uv_stat)

    graph_a = make_graph_a()
    graph_b = make_graph_b()
    graph_a_before = snapshot_graph(graph_a)
    graph_b_before = snapshot_graph(graph_b)
    batch = collate_brep_pretrain_model_input(
        [
            BRepPretrainModelInputSample("part_a", graph_a),
            BRepPretrainModelInputSample("part_b", graph_b),
        ],
        statistics=statistics,
    )
    assert_batch_protocol(batch, graph_a, graph_b, statistics)
    assert_graph_unchanged(graph_a, graph_a_before)
    assert_graph_unchanged(graph_b, graph_b_before)

    for current, before in (
        (attr_stat, attr_before),
        (uv_stat, uv_before),
    ):
        assert current.keys() == before.keys()
        for key, value in current.items():
            if isinstance(value, torch.Tensor):
                assert torch.equal(value, before[key])
            else:
                assert value == before[key]

    check_single_graph_batches(statistics)
    check_failure_paths(statistics)

    print("BREP_GRAPH_PRETRAIN_MODEL_INPUT_LOADER_CHECK_PASS")
    print("part_ids=('part_a','part_b')")
    print("batch_nodes=[3,2] physical_edges=[2,1] message_edges=[4,2]")
    print("physical_message_v1=PASS")


if __name__ == "__main__":
    main()
