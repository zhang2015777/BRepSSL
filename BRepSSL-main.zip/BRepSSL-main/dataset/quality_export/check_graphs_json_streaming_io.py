

from __future__ import annotations

import hashlib
import math
import sys
import tempfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.graph_json_stream import (
    iter_graph_records,
    validate_graphs_json_streaming,
    write_graph_records_atomic,
    write_top_level_json_array_streaming,
)


def expect_error(error_type, callback):
    try:
        callback()
    except error_type:
        return
    raise AssertionError(f"Expected {error_type.__name__}")


class SinglePassRecords:
    def __init__(self, count):
        self.count = count
        self.iterations = 0
        self.yield_count = 0

    def __iter__(self):
        self.iterations += 1
        if self.iterations != 1:
            raise AssertionError("records iterator was consumed more than once")
        for index in range(self.count):
            self.yield_count += 1
            yield [f"part_{index:05d}", {"value": index}]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)

        empty = root / "empty.json"
        assert write_top_level_json_array_streaming(empty, iter(())) == 0
        assert empty.read_text(encoding="utf-8") == "[]"

        path = root / "graphs.json"
        records = (
            ["part_b", {"value": 2, "text": "加工"}],
            ["part_a", {"value": 1}],
        )
        assert write_graph_records_atomic(path, iter(records)) == (
            "part_b",
            "part_a",
        )
        assert [part_id for part_id, _ in iter_graph_records(path)] == [
            "part_b",
            "part_a",
        ]
        text = path.read_text(encoding="utf-8")
        assert '"part_b",{"value":2,"text":"加工"}' in text
        assert ": " not in text and ", " not in text
        assert "\n    " not in text
        validate_graphs_json_streaming(
            path,
            expected_count=2,
            expected_part_ids=("part_b", "part_a"),
        )
        first_hash = sha256(path)
        write_graph_records_atomic(path, iter(records))
        assert sha256(path) == first_hash

        previous = path.read_bytes()
        expect_error(
            ValueError,
            lambda: write_graph_records_atomic(
                path,
                iter(
                    (
                        ["valid", {"value": 1.0}],
                        ["invalid", {"value": math.nan}],
                    )
                ),
            ),
        )
        assert path.read_bytes() == previous
        assert not Path(str(path) + ".tmp").exists()

        def interrupted():
            yield ["first", {"value": 1}]
            raise RuntimeError("interrupted")

        expect_error(
            RuntimeError,
            lambda: write_graph_records_atomic(path, interrupted()),
        )
        assert path.read_bytes() == previous
        assert not Path(str(path) + ".tmp").exists()

        duplicate = root / "duplicate.json"
        expect_error(
            ValueError,
            lambda: write_graph_records_atomic(
                duplicate,
                iter(
                    (
                        ["same", {"value": 1}],
                        ["same", {"value": 2}],
                    )
                ),
            ),
        )
        assert not duplicate.exists()

        truncated = root / "truncated.json"
        truncated.write_text('[["part",{"value":1}]', encoding="utf-8")
        expect_error(ValueError, lambda: tuple(iter_graph_records(truncated)))

        trailing = root / "trailing.json"
        trailing.write_text("[] trailing", encoding="utf-8")
        expect_error(ValueError, lambda: tuple(iter_graph_records(trailing)))
        trailing_comma = root / "trailing_comma.json"
        trailing_comma.write_text(
            '[["part",{"value":1}],]',
            encoding="utf-8",
        )
        expect_error(
            ValueError,
            lambda: tuple(iter_graph_records(trailing_comma)),
        )

        many = root / "many.json"
        single_pass = SinglePassRecords(10_000)
        write_graph_records_atomic(many, single_pass)
        assert single_pass.iterations == 1
        assert single_pass.yield_count == 10_000
        count = sum(1 for _ in iter_graph_records(many, chunk_size=257))
        assert count == 10_000

    print("GRAPHS_JSON_STREAMING_IO_CHECK_PASS")


if __name__ == "__main__":
    main()
