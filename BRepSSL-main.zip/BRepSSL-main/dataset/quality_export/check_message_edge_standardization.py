

import copy
import math
import sys
from pathlib import Path

import dgl
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.message_edge_standardization import (
    resolve_directed_message_edge_statistics,
    standardize_message_edge_view,
)
from utils.physical_edge_message_adapter import (
    build_physical_edge_message_view,
)


def make_raw_inputs():
    graph = dgl.graph(([0, 1], [1, 2]), num_nodes=3)
    edge_attr = torch.arange(32, dtype=torch.float32).reshape(2, 16)
    edge_grid = (
        torch.arange(2 * 16 * 5, dtype=torch.float32).reshape(2, 16, 5)
        + 100.0
    )

    edge_grid[0, 3:6, 1] = 0.0
    edge_grid[1, 3:6, 3] = 0.0

    edge_face_uv = torch.zeros(2, 2, 5, 2, dtype=torch.float32)
    edge_face_uv_valid = torch.ones(2, 2, 5, dtype=torch.bool)
    for edge_index in range(2):
        for side in range(2):
            for sample in range(5):
                edge_face_uv[edge_index, side, sample] = torch.tensor(
                    [
                        -0.8 + 0.1 * sample + 0.03 * side,
                        0.8 - 0.1 * sample - 0.03 * edge_index,
                    ]
                )
    edge_face_uv_valid[0, 0, 2] = False
    edge_face_uv_valid[0, 1, 4] = False
    edge_face_uv_valid[1, 0, 1] = False
    edge_face_uv_valid[1, 1, 3] = False
    edge_face_uv[~edge_face_uv_valid] = 0.0
    return (
        graph,
        edge_attr,
        edge_grid,
        edge_face_uv,
        edge_face_uv_valid,
    )


def make_statistics():
    attr_stat = {
        "mean_edge_attr": torch.linspace(-1.0, 2.0, 16),
        "std_edge_attr": torch.linspace(0.5, 2.0, 16),
    }
    uv_stat = {
        "mean_edge_grid": torch.tensor([2.0, 1.0, 5.0]),
        "std_edge_grid": torch.tensor([3.0, 2.0, 4.0]),
        "count_edge_grid": torch.tensor([7, 3, 5]),
        "std_ddof": 0,
        "edge_standardized_channels": [12, 14, 15],
    }
    return attr_stat, uv_stat


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def check_pooled_statistics(statistics):
    src_count = 3
    dst_count = 5
    src_mean = 1.0
    dst_mean = 5.0
    src_std = 2.0
    dst_std = 4.0
    pooled_count = src_count + dst_count
    pooled_mean = (
        src_count * src_mean + dst_count * dst_mean
    ) / pooled_count
    pooled_variance = (
        src_count * (src_std**2 + (src_mean - pooled_mean) ** 2)
        + dst_count * (dst_std**2 + (dst_mean - pooled_mean) ** 2)
    ) / pooled_count
    pooled_std = math.sqrt(max(pooled_variance, 0.0))

    assert statistics.src_count == src_count
    assert statistics.dst_count == dst_count
    assert statistics.pooled_count == pooled_count
    torch.testing.assert_close(
        statistics.side_normal_curvature_mean,
        torch.tensor(pooled_mean, dtype=torch.float32),
    )
    torch.testing.assert_close(
        statistics.raw_side_normal_curvature_std,
        torch.tensor(pooled_std, dtype=torch.float32),
    )
    assert not math.isclose(pooled_mean, (src_mean + dst_mean) / 2.0)
    assert not math.isclose(pooled_std, (src_std + dst_std) / 2.0)


def check_standardization(message_view, output, statistics):
    original_attr = message_view.message_edge_attr
    expected_attr = (
        original_attr - statistics.edge_attr_mean
    ) / statistics.edge_attr_std
    torch.testing.assert_close(output.message_edge_attr, expected_attr)
    torch.testing.assert_close(
        output.message_edge_attr[0::2],
        output.message_edge_attr[1::2],
    )

    original_grid = message_view.message_edge_grid
    output_grid = output.message_edge_grid
    tangent_valid = (
        torch.linalg.vector_norm(original_grid[:, 3:6, :], dim=1) > 1e-12
    )
    expected_12 = torch.zeros_like(original_grid[:, 12, :])
    expected_12[tangent_valid] = (
        original_grid[:, 12, :][tangent_valid]
        - statistics.curve_curvature_mean
    ) / statistics.curve_curvature_std
    torch.testing.assert_close(output_grid[:, 12, :], expected_12)
    assert torch.all(output_grid[:, 12, :][~tangent_valid] == 0)

    valid_14 = message_view.message_edge_face_uv_valid[:, 0, :]
    valid_15 = message_view.message_edge_face_uv_valid[:, 1, :]
    for channel, valid in ((14, valid_14), (15, valid_15)):
        expected = torch.zeros_like(original_grid[:, channel, :])
        expected[valid] = (
            original_grid[:, channel, :][valid]
            - statistics.side_normal_curvature_mean
        ) / statistics.side_normal_curvature_std
        torch.testing.assert_close(output_grid[:, channel, :], expected)
        assert torch.all(output_grid[:, channel, :][~valid] == 0)

    torch.testing.assert_close(output_grid[:, 0:12], original_grid[:, 0:12])
    torch.testing.assert_close(output_grid[:, 13], original_grid[:, 13])
    torch.testing.assert_close(
        output.message_edge_face_uv,
        message_view.message_edge_face_uv,
    )
    assert torch.equal(
        output.message_edge_face_uv_valid,
        message_view.message_edge_face_uv_valid,
    )

    forward_14 = output_grid[0::2, 14]
    forward_15 = output_grid[0::2, 15]
    reverse_14 = output_grid[1::2, 14]
    reverse_15 = output_grid[1::2, 15]
    torch.testing.assert_close(
        reverse_14, torch.flip(forward_15, dims=(1,))
    )
    torch.testing.assert_close(
        reverse_15, torch.flip(forward_14, dims=(1,))
    )
    torch.testing.assert_close(
        output_grid[1::2, 12],
        torch.flip(output_grid[0::2, 12], dims=(1,)),
    )


def check_errors(attr_stat, uv_stat, message_view):
    bad_attr_shape = copy.deepcopy(attr_stat)
    bad_attr_shape["mean_edge_attr"] = torch.zeros(15)
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            bad_attr_shape, uv_stat
        ),
    )

    bad_ddof = copy.deepcopy(uv_stat)
    bad_ddof["std_ddof"] = 1
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            attr_stat, bad_ddof
        ),
    )

    bad_channels = copy.deepcopy(uv_stat)
    bad_channels["edge_standardized_channels"] = [12, 15, 14]
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            attr_stat, bad_channels
        ),
    )

    for bad_count in (0, -1):
        invalid_count = copy.deepcopy(uv_stat)
        invalid_count["count_edge_grid"][1] = bad_count
        expect_error(
            ValueError,
            lambda invalid_count=invalid_count:
            resolve_directed_message_edge_statistics(
                attr_stat, invalid_count
            ),
        )

    negative_std = copy.deepcopy(uv_stat)
    negative_std["std_edge_grid"][2] = -0.1
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            attr_stat, negative_std
        ),
    )

    nan_stat = copy.deepcopy(attr_stat)
    nan_stat["mean_edge_attr"][0] = float("nan")
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            nan_stat, uv_stat
        ),
    )
    inf_stat = copy.deepcopy(uv_stat)
    inf_stat["std_edge_grid"][0] = float("inf")
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            attr_stat, inf_stat
        ),
    )
    expect_error(
        TypeError,
        lambda: standardize_message_edge_view(
            object(),
            resolve_directed_message_edge_statistics(attr_stat, uv_stat),
        ),
    )


def check_loader_style_statistics(attr_stat, uv_stat):
    raw_json_attr = copy.deepcopy(attr_stat)
    raw_json_attr["std_edge_attr"][0] = 0.0
    raw_json_uv = copy.deepcopy(uv_stat)
    raw_json_uv["std_edge_grid"] = torch.tensor([0.0, 0.0, 4.0])

    loader_attr = copy.deepcopy(raw_json_attr)
    loader_attr["raw_std_edge_attr"] = raw_json_attr[
        "std_edge_attr"
    ].clone()
    loader_attr["std_edge_attr"] = torch.where(
        loader_attr["raw_std_edge_attr"] < 1e-8,
        torch.ones_like(loader_attr["raw_std_edge_attr"]),
        loader_attr["raw_std_edge_attr"],
    )
    loader_uv = copy.deepcopy(raw_json_uv)
    loader_uv["raw_std_edge_grid"] = raw_json_uv[
        "std_edge_grid"
    ].clone()
    loader_uv["std_edge_grid"] = torch.tensor([1.0, 1.0, 4.0])

    raw_result = resolve_directed_message_edge_statistics(
        raw_json_attr, raw_json_uv
    )
    loader_result = resolve_directed_message_edge_statistics(
        loader_attr, loader_uv
    )

    torch.testing.assert_close(
        loader_result.raw_curve_curvature_std, torch.tensor(0.0)
    )
    torch.testing.assert_close(
        loader_result.curve_curvature_std, torch.tensor(1.0)
    )
    torch.testing.assert_close(
        loader_result.raw_edge_attr_std[0], torch.tensor(0.0)
    )
    torch.testing.assert_close(
        loader_result.edge_attr_std[0], torch.tensor(1.0)
    )

    pooled_mean = (
        loader_result.src_count * loader_uv["mean_edge_grid"][1]
        + loader_result.dst_count * loader_uv["mean_edge_grid"][2]
    ) / loader_result.pooled_count
    expected_variance = (
        loader_result.src_count
        * (
            0.0**2
            + (loader_uv["mean_edge_grid"][1] - pooled_mean) ** 2
        )
        + loader_result.dst_count
        * (
            4.0**2
            + (loader_uv["mean_edge_grid"][2] - pooled_mean) ** 2
        )
    ) / loader_result.pooled_count
    expected_raw_pooled_std = torch.sqrt(expected_variance)
    torch.testing.assert_close(
        loader_result.raw_side_normal_curvature_std,
        expected_raw_pooled_std,
    )
    expected_safe_pooled_std = torch.where(
        expected_raw_pooled_std < 1e-8,
        torch.ones_like(expected_raw_pooled_std),
        expected_raw_pooled_std,
    )
    torch.testing.assert_close(
        loader_result.side_normal_curvature_std,
        expected_safe_pooled_std,
    )

    for field in (
        "edge_attr_mean",
        "edge_attr_std",
        "raw_edge_attr_std",
        "curve_curvature_mean",
        "curve_curvature_std",
        "raw_curve_curvature_std",
        "side_normal_curvature_mean",
        "side_normal_curvature_std",
        "raw_side_normal_curvature_std",
    ):
        torch.testing.assert_close(
            getattr(loader_result, field),
            getattr(raw_result, field),
        )
    assert loader_result.curve_curvature_count == raw_result.curve_curvature_count
    assert loader_result.src_count == raw_result.src_count
    assert loader_result.dst_count == raw_result.dst_count
    assert loader_result.pooled_count == raw_result.pooled_count

    inconsistent_uv = copy.deepcopy(loader_uv)
    inconsistent_uv["std_edge_grid"][0] = 2.0
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            loader_attr, inconsistent_uv
        ),
    )
    inconsistent_attr = copy.deepcopy(loader_attr)
    inconsistent_attr["std_edge_attr"][0] = 2.0
    expect_error(
        ValueError,
        lambda: resolve_directed_message_edge_statistics(
            inconsistent_attr, loader_uv
        ),
    )


def main():
    graph, edge_attr, edge_grid, edge_face_uv, edge_face_uv_valid = (
        make_raw_inputs()
    )
    attr_stat, uv_stat = make_statistics()
    attr_stat_before = copy.deepcopy(attr_stat)
    uv_stat_before = copy.deepcopy(uv_stat)
    message_view = build_physical_edge_message_view(
        graph,
        edge_attr,
        edge_grid,
        edge_face_uv,
        edge_face_uv_valid,
    )
    message_attr_before = message_view.message_edge_attr.clone()
    message_grid_before = message_view.message_edge_grid.clone()
    message_uv_before = message_view.message_edge_face_uv.clone()
    message_valid_before = message_view.message_edge_face_uv_valid.clone()

    statistics = resolve_directed_message_edge_statistics(
        attr_stat,
        uv_stat,
        device=message_view.message_edge_grid.device,
        dtype=message_view.message_edge_grid.dtype,
    )
    output = standardize_message_edge_view(message_view, statistics)

    check_pooled_statistics(statistics)
    check_standardization(message_view, output, statistics)
    check_errors(attr_stat, uv_stat, message_view)
    check_loader_style_statistics(attr_stat, uv_stat)

    assert torch.equal(message_view.message_edge_attr, message_attr_before)
    assert torch.equal(message_view.message_edge_grid, message_grid_before)
    assert torch.equal(message_view.message_edge_face_uv, message_uv_before)
    assert torch.equal(
        message_view.message_edge_face_uv_valid, message_valid_before
    )
    assert torch.equal(
        attr_stat["mean_edge_attr"], attr_stat_before["mean_edge_attr"]
    )
    assert torch.equal(
        attr_stat["std_edge_attr"], attr_stat_before["std_edge_attr"]
    )
    for key in ("mean_edge_grid", "std_edge_grid", "count_edge_grid"):
        assert torch.equal(uv_stat[key], uv_stat_before[key])
    assert output.message_edge_grid.device == message_view.message_edge_grid.device
    assert output.message_edge_attr.device == message_view.message_edge_attr.device

    print("MESSAGE_EDGE_STANDARDIZATION_CHECK_PASS")
    print(
        "pooled_counts="
        f"{statistics.src_count}+{statistics.dst_count}="
        f"{statistics.pooled_count}"
    )
    print(
        "pooled_mean="
        f"{statistics.side_normal_curvature_mean.item():.8f}"
    )
    print(
        "pooled_raw_std="
        f"{statistics.raw_side_normal_curvature_std.item():.8f}"
    )


if __name__ == "__main__":
    main()
