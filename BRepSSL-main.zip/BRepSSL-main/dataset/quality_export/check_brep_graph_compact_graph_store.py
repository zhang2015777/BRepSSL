

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from unittest import mock

import numpy as np
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepCompactGraphStore,
    BRepPretrainDataset,
    collate_brep_pretrain_model_input,
)
from models.graph_masking import SINGLE_TOPOLOGY_CACHE_ATTR
from utils.graph_json_stream import sha256_part_ids, write_graph_records_atomic


def expect_error(error_type, callback):
    try:
        callback()
    except error_type:
        return
    raise AssertionError(f"Expected {error_type.__name__}")


def make_graph_record(part_id, index):
    node_count = 2 + index % 2
    if index == 5:
        src, dst = [0], [0]
    else:
        src, dst = [0], [1]
    edge_count = len(src)
    face_attr = (
        np.arange(node_count * 16, dtype=np.float32).reshape(node_count, 16)
        + index
    )
    face_grid = (
        np.arange(node_count * 11 * 25, dtype=np.float32)
        .reshape(node_count, 11, 5, 5)
        / 100.0
        + index
    )
    face_grid[:, 10] = 1.0
    edge_attr = (
        np.arange(edge_count * 16, dtype=np.float32).reshape(edge_count, 16)
        + index
    )
    edge_grid = (
        np.arange(edge_count * 16 * 5, dtype=np.float32)
        .reshape(edge_count, 16, 5)
        / 100.0
        + index
    )
    edge_grid[:, 3:6] += 1.0
    uv = np.zeros((edge_count, 2, 5, 2), dtype=np.float32)
    uv[:, :, :, 0] = np.linspace(-0.8, 0.8, 5, dtype=np.float32)
    valid = np.ones((edge_count, 2, 5), dtype=bool)
    return [
        part_id,
        {
            "graph": {"num_nodes": node_count, "edges": [src, dst]},
            "graph_face_attr": face_attr.tolist(),
            "graph_face_grid": face_grid.tolist(),
            "graph_edge_attr": edge_attr.tolist(),
            "graph_edge_grid": edge_grid.tolist(),
            "graph_edge_face_uv": uv.tolist(),
            "graph_edge_face_uv_valid": valid.tolist(),
        },
    ]


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, separators=(",", ":"), allow_nan=False),
        encoding="utf-8",
    )


def build_dataset_root(root):
    brep_graph = root / "brep_graph"
    partition = root / "MFInstseg_partition"
    brep_graph.mkdir(parents=True)
    partition.mkdir(parents=True)
    part_ids = tuple(f"part_{index}" for index in range(6))
    write_graph_records_atomic(
        brep_graph / "graphs.json",
        (make_graph_record(part_id, index) for index, part_id in enumerate(part_ids)),
    )
    train_ids = part_ids[:3]
    eval_ids = part_ids[3:5]
    test_ids = part_ids[5:]
    for name, values in (
        ("train", train_ids),
        ("eval", eval_ids),
        ("test", test_ids),
    ):
        (partition / f"{name}.txt").write_text(
            "\n".join(values) + "\n",
            encoding="utf-8",
        )
    train_digest = sha256_part_ids(train_ids)
    write_json(
        partition / "partition_info.json",
        {
            "split_protocol": "train_eval_test_80_10_10_seed42",
            "test_split_enabled": True,
            "train_count": len(train_ids),
            "eval_count": len(eval_ids),
            "test_count": len(test_ids),
            "total_count": len(part_ids),
            "train_ids_sha256": train_digest,
        },
    )
    write_json(
        brep_graph / "attr_stat.json",
        {
            "schema_version": "brep_graph_attr_stat_v2",
            "source_split": "train",
            "split_protocol": "train_eval_test_80_10_10_seed42",
            "std_ddof": 0,
            "train_ids_sha256": train_digest,
            "face_attr_dim": 16,
            "edge_attr_dim": 16,
            "mean_face_attr": [0.0] * 16,
            "std_face_attr": [1.0] * 16,
            "mean_edge_attr": [0.0] * 16,
            "std_edge_attr": [1.0] * 16,
        },
    )
    write_json(
        brep_graph / "uv_stat.json",
        {
            "schema_version": "brep_graph_uv_stat_v1",
            "source_split": "train",
            "split_protocol": "train_eval_test_80_10_10_seed42",
            "std_ddof": 0,
            "train_ids_sha256": train_digest,
            "face_grid_dim": 11,
            "edge_grid_dim": 16,
            "face_standardized_channels": [6, 7, 9],
            "edge_standardized_channels": [12, 14, 15],
            "mean_face_grid": [0.0, 0.0, 0.0],
            "std_face_grid": [1.0, 1.0, 1.0],
            "count_face_grid": [1, 1, 1],
            "mean_edge_grid": [0.0, 0.0, 0.0],
            "std_edge_grid": [1.0, 1.0, 1.0],
            "count_edge_grid": [1, 1, 1],
        },
    )
    return part_ids, train_ids, eval_ids, test_ids


def snapshot_graph(graph):
    src, dst = graph.edges(order="eid")
    return (
        src.clone(),
        dst.clone(),
        {key: value.clone() for key, value in graph.ndata.items()},
        {key: value.clone() for key, value in graph.edata.items()},
    )


def assert_graph_unchanged(graph, snapshot):
    src, dst = graph.edges(order="eid")
    assert torch.equal(src, snapshot[0])
    assert torch.equal(dst, snapshot[1])
    for key, value in snapshot[2].items():
        assert torch.equal(graph.ndata[key], value)
    for key, value in snapshot[3].items():
        assert torch.equal(graph.edata[key], value)


def main():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary) / "data3"
        part_ids, train_ids, eval_ids, test_ids = build_dataset_root(root)
        store = BRepCompactGraphStore(root, normalize=True)
        assert store.loaded_graph_count == 0
        assert store.loaded_part_ids == ()
        assert store.stream_scan_count == 0
        assert store.graph_construction_count == 0

        with mock.patch(
            "json.load",
            side_effect=AssertionError("json.load must not read graphs.json"),
        ):
            store.ensure_loaded(train_ids + eval_ids)
        assert store.stream_scan_count == 1
        assert store.loaded_graph_count == 5
        assert store.graph_construction_count == 5
        assert store.loaded_part_ids == train_ids + eval_ids
        assert test_ids[0] not in store.loaded_part_ids
        assert store.estimated_tensor_bytes > 0

        first = store.get_sample(train_ids[0])
        second = store.get_sample(train_ids[0])
        assert first is second
        assert first.physical_graph is second.physical_graph
        assert first.physical_graph.device.type == "cpu"
        assert set(first.__dataclass_fields__) == {"part_id", "physical_graph"}
        assert not hasattr(first, "message_view")
        assert not hasattr(first, "model_input")
        assert store.stream_scan_count == 1
        assert hasattr(first.physical_graph, SINGLE_TOPOLOGY_CACHE_ATTR)

        train_dataset = BRepPretrainDataset(
            root,
            split="train",
            graph_store=store,
        )
        eval_dataset = BRepPretrainDataset(
            root,
            split="eval",
            graph_store=store,
        )
        assert train_dataset.graph_store is eval_dataset.graph_store is store
        assert train_dataset.model_input_statistics is (
            eval_dataset.model_input_statistics
        )
        assert train_dataset.data[0] is store.get_sample(train_ids[0])
        assert eval_dataset.data[0] is store.get_sample(eval_ids[0])
        assert store.stream_scan_count == 1

        graph = first.physical_graph
        before = snapshot_graph(graph)
        collate_brep_pretrain_model_input(
            [first],
            statistics=store.model_input_statistics,
        )
        assert_graph_unchanged(graph, before)

        store.ensure_loaded(test_ids)
        assert store.stream_scan_count == 2
        assert store.loaded_part_ids == part_ids
        assert store.get_sample(train_ids[0]) is first
        assert store.graph_construction_count == len(part_ids)

        expect_error(
            ValueError,
            lambda: store.resolve_part_ids(
                split="train",
                filelist_override=(train_ids[0], train_ids[0]),
            ),
        )
        expect_error(
            KeyError,
            lambda: store.ensure_loaded(("missing_part",)),
        )
        assert store.stream_scan_count == 3

        forbidden_suffixes = {".pkl", ".pt", ".bin"}
        assert not any(
            path.suffix in forbidden_suffixes for path in root.rglob("*")
        )

    print("BREP_GRAPH_COMPACT_GRAPH_STORE_CHECK_PASS")


if __name__ == "__main__":
    main()
