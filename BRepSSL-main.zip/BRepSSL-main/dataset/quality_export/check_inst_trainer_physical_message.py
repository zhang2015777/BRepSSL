

from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile

import torch
from torch import nn
from torch_ema import ExponentialMovingAverage


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from configs.main_experiment_config import FINETUNE_MAIN_CONFIG
from dataset.quality_export.check_brep_graph_physical_message_quality_segmentor import (
    assert_input_unchanged,
    clone_input_state,
    make_batch,
)
from engine.inst_trainer import (
    BEST_METRIC_NAME,
    FINETUNE_CHECKPOINT_FORMAT,
    build_best_finetune_checkpoint,
    build_model,
    compute_masked_instance_loss,
    compute_process_loss,
    is_better_finetune_candidate,
    make_best_candidate,
    make_metric_bundle,
    run_eval,
    sample_train_subset,
    set_backbone_freeze_for_epoch,
    validate_finetune_checkpoint,
    validate_formal_partition_metadata,
)
from models.brep_physical_message_backbone import BRepPhysicalMessageBackbone
from models.brep_physical_message_quality_segmentor import (
    BRepPhysicalMessageQualitySegmentor,
)


def expect_error(error_type, callback):
    try:
        callback()
    except error_type:
        return
    raise AssertionError(f"Expected {error_type.__name__}")


def make_args():
    values = dict(FINETUNE_MAIN_CONFIG)
    values.update(
        {
            "train_percent": 0.5,
            "initialization_mode": "scratch",
            "pretrained_backbone": None,
            "sample_seed": 42,
        }
    )
    return SimpleNamespace(**values)


def make_losses(outputs, batch):
    seg_pred, inst_pred, process_pred = outputs
    semantic_fn = nn.CrossEntropyLoss()
    instance_fn = nn.BCEWithLogitsLoss(reduction="none")
    process_fn = nn.CrossEntropyLoss(ignore_index=-1)
    semantic = semantic_fn(seg_pred, batch.seg_y)
    instance = compute_masked_instance_loss(
        instance_fn,
        inst_pred,
        batch.inst_labels,
        batch.inst_masks,
    )
    process = compute_process_loss(
        process_fn,
        process_pred,
        batch.process_y,
    )
    return semantic, instance, process


def assert_backbone_has_finite_gradient(model):
    gradients = [
        parameter.grad
        for parameter in model.backbone.parameters()
        if parameter.grad is not None
    ]
    assert gradients
    assert all(torch.all(torch.isfinite(value)) for value in gradients)


def check_best_protocol():
    base = {
        "eval_seg_iou": 0.6,
        "eval_inst_pair_iou": 0.4,
        "eval_process_iou": 0.7,
        "loss_total": 1.0,
    }
    best = make_best_candidate(base, 2)
    assert best["segmentation_score"] == 0.5

    semantic_better = make_best_candidate(
        {**base, "eval_seg_iou": 0.7},
        3,
    )
    assert is_better_finetune_candidate(semantic_better, best)
    instance_better = make_best_candidate(
        {**base, "eval_inst_pair_iou": 0.5},
        3,
    )
    assert is_better_finetune_candidate(instance_better, best)
    process_tie_break = make_best_candidate(
        {**base, "eval_process_iou": 0.8},
        3,
    )
    assert is_better_finetune_candidate(process_tie_break, best)
    lower_process = make_best_candidate(
        {**base, "eval_process_iou": 0.6, "loss_total": 0.5},
        3,
    )
    assert not is_better_finetune_candidate(lower_process, best)
    loss_tie_break = make_best_candidate(
        {**base, "loss_total": 0.5},
        3,
    )
    assert is_better_finetune_candidate(loss_tie_break, best)
    identical_later = make_best_candidate(base, 3)
    assert not is_better_finetune_candidate(identical_later, best)
    expect_error(
        KeyError,
        lambda: make_best_candidate(
            {
                "test_seg_iou": 1.0,
                "test_inst_pair_iou": 1.0,
                "test_process_iou": 1.0,
                "loss_total": 0.0,
            },
            1,
        ),
    )


def check_partition_protocol():
    partition_info = {
        "split_protocol": "train_eval_test_80_10_10_seed42",
        "train_ratio": 0.8,
        "eval_ratio": 0.1,
        "requested_test_ratio": 0.1,
        "split_seed": 42,
        "test_split_enabled": True,
        "val_split_enabled": False,
    }
    validate_formal_partition_metadata(partition_info)
    expect_error(
        ValueError,
        lambda: validate_formal_partition_metadata(
            {**partition_info, "eval_ratio": 0.2}
        ),
    )
    expect_error(
        ValueError,
        lambda: validate_formal_partition_metadata(
            {**partition_info, "test_split_enabled": False}
        ),
    )


def main():
    torch.manual_seed(2026)
    args = make_args()
    batch, _ = make_batch()
    before = clone_input_state(batch)
    model = build_model(args, 13)
    assert isinstance(model, BRepPhysicalMessageQualitySegmentor)
    assert isinstance(model.backbone, BRepPhysicalMessageBackbone)
    assert len(batch.physical_topology_graph.ndata) == 0
    assert len(batch.physical_topology_graph.edata) == 0

    model.eval()
    outputs = model(batch)
    losses = make_losses(outputs, batch)
    assert all(loss.ndim == 0 for loss in losses)
    assert all(torch.isfinite(loss) for loss in losses)

    model.train()
    model.zero_grad(set_to_none=True)
    semantic = make_losses(model(batch), batch)[0]
    semantic.backward()
    assert_backbone_has_finite_gradient(model)

    model.zero_grad(set_to_none=True)
    instance = make_losses(model(batch), batch)[1]
    instance.backward()
    assert_backbone_has_finite_gradient(model)

    model.zero_grad(set_to_none=True)
    process = make_losses(model(batch), batch)[2]
    process.backward()
    assert all(
        parameter.grad is None
        for parameter in model.backbone.parameters()
    )

    model.train()
    assert set_backbone_freeze_for_epoch(model, 1, 10)
    assert not model.backbone.training
    assert all(
        not parameter.requires_grad for parameter in model.backbone.parameters()
    )
    model.train()
    assert set_backbone_freeze_for_epoch(model, 10, 10)
    assert not model.backbone.training
    model.train()
    assert not set_backbone_freeze_for_epoch(model, 11, 10)
    assert model.backbone.training
    assert all(
        parameter.requires_grad for parameter in model.backbone.parameters()
    )

    metrics = make_metric_bundle(13, torch.device("cpu"))
    eval_metrics = run_eval(
        model,
        [batch],
        metrics,
        nn.CrossEntropyLoss(),
        nn.BCEWithLogitsLoss(reduction="none"),
        nn.CrossEntropyLoss(ignore_index=-1),
        torch.device("cpu"),
        {"semantic": 1.0, "instance": 1.0, "process": 1.0},
        use_autocast=False,
        metric_prefix="eval",
    )
    assert "eval_seg_iou" in eval_metrics
    assert "eval_inst_pair_iou" in eval_metrics
    assert "eval_process_iou" in eval_metrics
    assert all(
        torch.isfinite(torch.tensor(float(value)))
        for value in eval_metrics.values()
    )
    check_best_protocol()
    check_partition_protocol()

    train_ids = [f"part_{index:03d}" for index in range(200)]
    subset_half, _ = sample_train_subset(train_ids, 0.5, 42)
    subset_one, _ = sample_train_subset(train_ids, 1.0, 42)
    subset_five, _ = sample_train_subset(train_ids, 5.0, 42)
    assert subset_half == sample_train_subset(train_ids, 0.5, 42)[0]
    assert set(subset_half).issubset(subset_one)
    assert set(subset_one).issubset(subset_five)
    assert sample_train_subset(train_ids, 100, 42)[0] == train_ids

    split_info = {"train_subset_ids": subset_half}
    candidate = make_best_candidate(eval_metrics, epoch=1)
    ema = ExponentialMovingAverage(model.parameters(), decay=0.5)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(0.125)
    ema.update()
    first_key = next(iter(model.state_dict()))
    non_ema_value = model.state_dict()[first_key].clone()
    with tempfile.TemporaryDirectory() as directory:
        checkpoint_path = Path(directory) / "best.pth"
        with ema.average_parameters():
            ema_value = model.state_dict()[first_key].clone()
            payload = build_best_finetune_checkpoint(
                model,
                args,
                split_info,
                1,
                candidate,
            )
            torch.save(payload, checkpoint_path)
        loaded = torch.load(checkpoint_path, map_location="cpu")
        validate_finetune_checkpoint(loaded, expected_role="best")
        assert loaded["checkpoint_format"] == FINETUNE_CHECKPOINT_FORMAT
        assert loaded["best_metric_name"] == BEST_METRIC_NAME
        torch.testing.assert_close(
            loaded["model_state_dict"][first_key],
            ema_value,
        )
        assert not torch.equal(ema_value, non_ema_value)
        restored = build_model(args, 13)
        restored.load_state_dict(loaded["model_state_dict"], strict=True)

        bare_path = Path(directory) / "bare.pth"
        torch.save(model.state_dict(), bare_path)
        bare = torch.load(bare_path, map_location="cpu")
        expect_error(
            ValueError,
            lambda: validate_finetune_checkpoint(bare),
        )

    assert_input_unchanged(batch, before)
    print("INST_TRAINER_PHYSICAL_MESSAGE_CHECK_PASS")


if __name__ == "__main__":
    main()
