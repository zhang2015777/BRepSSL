

import ast
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


FORMAL_MODEL_CLASSES = {
    "attention_refinement.py": frozenset({"AttentionRefinementLayer"}),
    "brep_geometry_encoder.py": frozenset({"BRepGeometryEncoding", "BRepGeometryEncoder"}),
    "brep_physical_message_backbone.py": frozenset({"BRepPhysicalMessageBackboneOutput", "BRepPhysicalMessageBackbone"}),
    "brep_physical_message_pretrainer.py": frozenset({"BRepPhysicalMessageMaskedPretrainer"}),
    "brep_physical_message_quality_segmentor.py": frozenset({"BRepPhysicalMessageQualitySegmentor"}),
    "brep_pretrain_input_masking.py": frozenset({"BRepPretrainMaskPlan", "BRepMaskedStudentInput"}),
    "damped_diffusion.py": frozenset({"DampedHeatDiffusionGraphPropagation"}),
    "decoders.py": frozenset({"InnerProductDecoder", "InstanceDecoder"}),
    "graph_masking.py": frozenset(),
    "iba_dmp.py": frozenset({"IBADMPEncoding", "IBADMPBlock", "IBADMPStack"}),
    "layers.py": frozenset({"DropPath", "Scale", "MLP", "EdgeMPNN"}),
    "task_heads.py": frozenset({"_ResidualBlock", "QualityProcessHead", "TaskResidualAdapter"}),
}
FORMAL_MODEL_FILES = frozenset(FORMAL_MODEL_CLASSES)


REMOVED_FILES = (
    "models/inst_segmentors.py",
    "models/encoders.py",
    "models/pnaconv.py",
    "dataloader/base.py",
    "dataloader/mfinstseg.py",
    "utils/data_utils.py",
    "engine/run_pretrain_then_finetune.py",
    "engine/run_no_pretrain_ablation.py",
    "engine/inst_test.py",
    "engine/inst_test_per_feature_metric.py",
    "engine/export_graph_mask_reconstruction.py",
    "docs/dhdgp_pipeline_run_guide.txt",
)
FORBIDDEN_RUNTIME_TOKENS = (
    "legacy_" + "graph_v0",
    "conv_" + "on_edge",
    "use_" + "damped_diffusion",
    "use_" + "attention_refinement",
    "run_" + "pretrain_then_finetune",
    "run_" + "no_pretrain_ablation",
)
FORMAL_SOURCE_ROOTS = (
    "configs",
    "dataloader",
    "dataset",
    "engine",
    "models",
    "utils",
)


def check_formal_model_sources():
    model_root = PROJECT_ROOT / "models"
    actual_files = {
        path.relative_to(model_root).as_posix()
        for path in model_root.rglob("*.py")
        if path.is_file()
    }
    unexpected_files = sorted(actual_files - FORMAL_MODEL_FILES)
    missing_files = sorted(FORMAL_MODEL_FILES - actual_files)
    if unexpected_files or missing_files:
        raise AssertionError(
            "Formal model file whitelist mismatch: "
            f"unexpected={unexpected_files}, missing={missing_files}"
        )

    for filename in sorted(FORMAL_MODEL_FILES):
        path = model_root / filename
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        class_names = [
            node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)
        ]
        actual_classes = set(class_names)
        expected_classes = FORMAL_MODEL_CLASSES[filename]
        unexpected_classes = sorted(actual_classes - expected_classes)
        missing_classes = sorted(expected_classes - actual_classes)
        duplicate_classes = sorted(
            name for name in actual_classes if class_names.count(name) > 1
        )
        if unexpected_classes or missing_classes or duplicate_classes:
            raise AssertionError(
                f"Formal model class whitelist mismatch in {filename}: "
                f"unexpected={unexpected_classes}, missing={missing_classes}, "
                f"duplicates={duplicate_classes}"
            )


def main():
    check_formal_model_sources()

    existing = [path for path in REMOVED_FILES if (PROJECT_ROOT / path).exists()]
    if existing:
        raise AssertionError(f"Removed runtime files still exist: {existing}")
    if (PROJECT_ROOT / "laji").exists():
        raise AssertionError("laji/ must not exist")

    readme = (PROJECT_ROOT / "README.md").read_text(encoding="utf-8")
    forbidden_readme_tokens = (
        "run_" + "pretrain_then_finetune.py",
        "run_" + "no_pretrain_ablation.py",
        "skip_" + "pretrain",
        "finetune_" + "from_scratch",
    )
    present = [token for token in forbidden_readme_tokens if token in readme]
    if present:
        raise AssertionError(f"README contains legacy runtime references: {present}")

    this_file = Path(__file__).resolve()
    findings = []
    for root_name in FORMAL_SOURCE_ROOTS:
        for path in (PROJECT_ROOT / root_name).rglob("*.py"):
            if path.resolve() == this_file:
                continue
            text = path.read_text(encoding="utf-8")
            for token in FORBIDDEN_RUNTIME_TOKENS:
                if token in text:
                    findings.append(
                        f"{path.relative_to(PROJECT_ROOT).as_posix()}: {token}"
                    )
    if findings:
        raise AssertionError("Legacy runtime references remain:\n" + "\n".join(findings))
    print("NO_LEGACY_RUNTIME_CHECK_PASS")


if __name__ == "__main__":
    main()
