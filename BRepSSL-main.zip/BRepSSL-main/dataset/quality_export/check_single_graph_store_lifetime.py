

from __future__ import annotations

import gc
import sys
import tempfile
import weakref
from pathlib import Path

import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepCompactGraphStore,
    BRepPretrainDataset,
    collate_brep_pretrain_model_input,
    move_brep_pretrain_model_input_batch,
)
from dataset.quality_export.check_brep_graph_compact_graph_store import (
    assert_graph_unchanged,
    build_dataset_root,
    snapshot_graph,
)


FORBIDDEN_STORE_FIELDS = {
    "graph_data",
    "raw_graphs",
    "message_view",
    "model_inputs",
    "masked",
    "target_embedding",
    "predictions",
}


def main():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary) / "data3"
        part_ids, train_ids, eval_ids, test_ids = build_dataset_root(root)

        store = BRepCompactGraphStore(root, normalize=True)
        assert store.loaded_graph_count == 0
        assert tuple(store.__dict__).count("_sample_by_id") == 1
        assert not (set(store.__dict__) & FORBIDDEN_STORE_FIELDS)

        store.ensure_loaded(train_ids + eval_ids)
        assert store.stream_scan_count == 1
        assert store.graph_construction_count == len(train_ids + eval_ids)
        assert all(
            sample.physical_graph.device.type == "cpu"
            for sample in store._sample_by_id.values()
        )

        train_dataset = BRepPretrainDataset(
            root,
            split="train",
            graph_store=store,
        )
        eval_dataset = BRepPretrainDataset(
            root,
            split="eval",
            graph_store=store,
        )
        assert train_dataset.graph_store is store
        assert eval_dataset.graph_store is store
        assert all(
            sample is store.get_sample(sample.part_id)
            for sample in train_dataset.data + eval_dataset.data
        )

        repeated_a = store.get_sample(train_ids[0])
        repeated_b = store.get_sample(train_ids[0])
        assert repeated_a is repeated_b
        assert repeated_a.physical_graph is repeated_b.physical_graph
        assert store.graph_construction_count == len(train_ids + eval_ids)

        source_graph = repeated_a.physical_graph
        source_snapshot = snapshot_graph(source_graph)
        batch = collate_brep_pretrain_model_input(
            [repeated_a],
            statistics=store.model_input_statistics,
        )
        assert batch.model_input.message_view.message_graph is not source_graph
        assert_graph_unchanged(source_graph, source_snapshot)
        moved = move_brep_pretrain_model_input_batch(
            batch,
            "cpu",
            non_blocking=True,
        )
        assert moved is not batch
        assert_graph_unchanged(source_graph, source_snapshot)

        store.ensure_loaded(test_ids)
        test_dataset = BRepPretrainDataset(
            root,
            split="test",
            graph_store=store,
        )
        assert test_dataset.graph_store is train_dataset.graph_store is store
        assert store.graph_construction_count == len(part_ids)
        assert store.loaded_graph_count == len(part_ids)
        assert store.stream_scan_count == 2
        assert all(
            sample is store.get_sample(sample.part_id)
            for sample in test_dataset.data
        )

        sample_fields = set(repeated_a.__dataclass_fields__)
        assert sample_fields == {"part_id", "physical_graph"}
        assert not hasattr(repeated_a, "message_view")
        assert not hasattr(repeated_a, "model_input")
        assert not hasattr(repeated_a, "mask_plan")
        assert not hasattr(repeated_a, "target_embedding")

        store_reference = weakref.ref(store)
        graph_reference = weakref.ref(source_graph)
        del moved, batch, source_graph, repeated_a, repeated_b
        del train_dataset, eval_dataset, test_dataset, store
        gc.collect()
        assert store_reference() is None
        assert graph_reference() is None

    trainer_source = (
        PROJECT_ROOT / "engine" / "inst_trainer.py"
    ).read_text(encoding="utf-8")
    assert trainer_source.count("BRepCompactGraphStore(") == 1
    assert trainer_source.count("graph_store=graph_store") >= 3
    assert "graph_store.ensure_loaded(test_ids)" in trainer_source
    assert not any(
        token in trainer_source
        for token in ("train_store", "eval_store", "test_store")
    )

    print("SINGLE_GRAPH_STORE_LIFETIME_CHECK_PASS")


if __name__ == "__main__":
    main()
