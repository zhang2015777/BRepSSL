

import copy
import sys
from dataclasses import fields
from pathlib import Path

import dgl
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.brep_model_input_view import (
    BRepModelInputStatistics,
    BRepModelInputView,
    build_brep_model_input_view,
    resolve_brep_model_input_statistics,
)


def make_statistics(loader_style=False):
    attr_stat = {
        "mean_face_attr": torch.linspace(-1.0, 1.0, 16),
        "std_face_attr": torch.linspace(0.5, 2.0, 16),
        "mean_edge_attr": torch.linspace(-2.0, 2.0, 16),
        "std_edge_attr": torch.linspace(0.75, 2.25, 16),
    }
    uv_stat = {
        "std_ddof": 0,
        "face_standardized_channels": [6, 7, 9],
        "mean_face_grid": torch.tensor([1.0, -2.0, 3.0]),
        "std_face_grid": torch.tensor([2.0, 4.0, 5.0]),
        "count_face_grid": torch.tensor([11, 12, 13]),
        "edge_standardized_channels": [12, 14, 15],
        "mean_edge_grid": torch.tensor([2.0, 1.0, 5.0]),
        "std_edge_grid": torch.tensor([3.0, 0.0, 4.0]),
        "count_edge_grid": torch.tensor([7, 3, 5]),
    }
    if loader_style:
        attr_stat["raw_std_face_attr"] = attr_stat[
            "std_face_attr"
        ].clone()
        attr_stat["raw_std_edge_attr"] = attr_stat[
            "std_edge_attr"
        ].clone()
        attr_stat["raw_std_face_attr"][0] = 0.0
        attr_stat["raw_std_edge_attr"][0] = 0.0
        attr_stat["std_face_attr"] = torch.where(
            attr_stat["raw_std_face_attr"] < 1e-8,
            torch.ones_like(attr_stat["raw_std_face_attr"]),
            attr_stat["raw_std_face_attr"],
        )
        attr_stat["std_edge_attr"] = torch.where(
            attr_stat["raw_std_edge_attr"] < 1e-8,
            torch.ones_like(attr_stat["raw_std_edge_attr"]),
            attr_stat["raw_std_edge_attr"],
        )

        uv_stat["raw_std_face_grid"] = uv_stat[
            "std_face_grid"
        ].clone()
        uv_stat["raw_std_edge_grid"] = uv_stat[
            "std_edge_grid"
        ].clone()
        uv_stat["raw_std_face_grid"][0] = 0.0
        uv_stat["std_face_grid"] = torch.where(
            uv_stat["raw_std_face_grid"] < 1e-8,
            torch.ones_like(uv_stat["raw_std_face_grid"]),
            uv_stat["raw_std_face_grid"],
        )
        uv_stat["std_edge_grid"] = torch.where(
            uv_stat["raw_std_edge_grid"] < 1e-8,
            torch.ones_like(uv_stat["raw_std_edge_grid"]),
            uv_stat["raw_std_edge_grid"],
        )
    return attr_stat, uv_stat


def attach_features(graph, value_offset):
    node_count = graph.num_nodes()
    edge_count = graph.num_edges()
    graph.ndata["x"] = (
        torch.arange(node_count * 16, dtype=torch.float32).reshape(
            node_count, 16
        )
        + value_offset
    )
    graph.ndata["grid"] = (
        torch.arange(
            node_count * 11 * 5 * 5, dtype=torch.float32
        ).reshape(node_count, 11, 5, 5)
        + 100.0
        + value_offset
    )
    graph.ndata["grid"][:, 10] = (
        torch.arange(25).reshape(1, 5, 5) % 2
    ).to(torch.float32)

    graph.edata["x"] = (
        torch.arange(edge_count * 16, dtype=torch.float32).reshape(
            edge_count, 16
        )
        + 200.0
        + value_offset
    )
    graph.edata["grid"] = (
        torch.arange(
            edge_count * 16 * 5, dtype=torch.float32
        ).reshape(edge_count, 16, 5)
        + 300.0
        + value_offset
    )
    if edge_count:
        graph.edata["grid"][0, 3:6, 1] = 0.0

    face_uv = torch.zeros(edge_count, 2, 5, 2, dtype=torch.float32)
    face_uv_valid = torch.ones(edge_count, 2, 5, dtype=torch.bool)
    for edge_index in range(edge_count):
        for side in range(2):
            for sample in range(5):
                face_uv[edge_index, side, sample] = torch.tensor(
                    [
                        -0.8 + 0.1 * sample + 0.03 * side,
                        0.8 - 0.1 * sample - 0.02 * edge_index,
                    ]
                )
    if edge_count:
        face_uv_valid[0, 0, 2] = False
        face_uv[0, 0, 2] = 0.0
    graph.edata["face_uv"] = face_uv
    graph.edata["face_uv_valid"] = face_uv_valid

    graph.ndata["seg_y"] = torch.arange(node_count)
    graph.ndata["process_y"] = torch.zeros(node_count, dtype=torch.int64)
    graph.ndata["quality"] = torch.full((node_count, 2), 99.0)
    graph.ndata["bottom_y"] = torch.ones(node_count)
    return graph


def make_graph_a():
    return attach_features(
        dgl.graph(([0, 1], [1, 2]), num_nodes=3), 0.0
    )


def make_graph_b():
    return attach_features(
        dgl.graph(([0], [0]), num_nodes=2), 1000.0
    )


def clone_graph_inputs(graph):
    return {
        "src_dst": tuple(item.clone() for item in graph.edges(order="eid")),
        "ndata": {key: value.clone() for key, value in graph.ndata.items()},
        "edata": {key: value.clone() for key, value in graph.edata.items()},
    }


def assert_graph_unchanged(graph, before):
    src, dst = graph.edges(order="eid")
    assert torch.equal(src, before["src_dst"][0])
    assert torch.equal(dst, before["src_dst"][1])
    assert set(graph.ndata.keys()) == set(before["ndata"])
    assert set(graph.edata.keys()) == set(before["edata"])
    for key, value in before["ndata"].items():
        assert torch.equal(graph.ndata[key], value)
    for key, value in before["edata"].items():
        assert torch.equal(graph.edata[key], value)


def assert_statistics_shapes(statistics):
    assert isinstance(statistics, BRepModelInputStatistics)
    assert statistics.face_attr_mean.shape == (16,)
    assert statistics.face_attr_std.shape == (16,)
    assert statistics.raw_face_attr_std.shape == (16,)
    assert statistics.face_grid_mean.shape == (3,)
    assert statistics.face_grid_std.shape == (3,)
    assert statistics.raw_face_grid_std.shape == (3,)
    assert statistics.face_grid_count == (11, 12, 13)


def assert_view(graph, view, statistics):
    assert isinstance(view, BRepModelInputView)
    node_count = graph.num_nodes()
    edge_count = graph.num_edges()
    expected_node_attr = (
        graph.ndata["x"] - statistics.face_attr_mean
    ) / statistics.face_attr_std
    torch.testing.assert_close(view.node_attr, expected_node_attr)

    expected_grid = graph.ndata["grid"].clone()
    for offset, channel in enumerate((6, 7, 9)):
        expected_grid[:, channel] = (
            expected_grid[:, channel] - statistics.face_grid_mean[offset]
        ) / statistics.face_grid_std[offset]
    torch.testing.assert_close(view.node_grid, expected_grid)
    unchanged_channels = (0, 1, 2, 3, 4, 5, 8, 10)
    for channel in unchanged_channels:
        torch.testing.assert_close(
            view.node_grid[:, channel], graph.ndata["grid"][:, channel]
        )
    assert torch.equal(view.node_grid[:, 10], graph.ndata["grid"][:, 10])

    message_view = view.message_view
    assert message_view.message_graph.num_edges() == 2 * edge_count
    physical_src, physical_dst = graph.edges(order="eid")
    expected_src = torch.stack(
        (physical_src, physical_dst), dim=1
    ).reshape(-1)
    expected_dst = torch.stack(
        (physical_dst, physical_src), dim=1
    ).reshape(-1)
    message_src, message_dst = message_view.message_graph.edges(order="eid")
    assert torch.equal(message_src, expected_src)
    assert torch.equal(message_dst, expected_dst)

    edge_statistics = statistics.message_edge_statistics
    expected_edge_attr = (
        graph.edata["x"] - edge_statistics.edge_attr_mean
    ) / edge_statistics.edge_attr_std
    torch.testing.assert_close(
        message_view.message_edge_attr[0::2], expected_edge_attr
    )
    torch.testing.assert_close(
        message_view.message_edge_attr[1::2], expected_edge_attr
    )

    raw_message_grid = message_view.message_edge_grid
    tangent_valid = (
        torch.linalg.vector_norm(raw_message_grid[:, 3:6], dim=1) > 1e-12
    )
    raw_physical_12 = graph.edata["grid"][:, 12]
    expected_forward_12 = torch.zeros_like(raw_physical_12)
    physical_tangent_valid = (
        torch.linalg.vector_norm(graph.edata["grid"][:, 3:6], dim=1)
        > 1e-12
    )
    expected_forward_12[physical_tangent_valid] = (
        raw_physical_12[physical_tangent_valid]
        - edge_statistics.curve_curvature_mean
    ) / edge_statistics.curve_curvature_std
    torch.testing.assert_close(
        raw_message_grid[0::2, 12], expected_forward_12
    )
    assert torch.all(raw_message_grid[:, 12][~tangent_valid] == 0)

    valid_14 = message_view.message_edge_face_uv_valid[:, 0]
    valid_15 = message_view.message_edge_face_uv_valid[:, 1]
    for channel, valid in ((14, valid_14), (15, valid_15)):
        assert torch.all(raw_message_grid[:, channel][~valid] == 0)
        expected = (
            (
                message_view.message_edge_grid[:, channel][valid]
                * edge_statistics.side_normal_curvature_std
            )
            + edge_statistics.side_normal_curvature_mean
        )
        assert torch.all(torch.isfinite(expected))
    expected_forward_14 = torch.zeros_like(graph.edata["grid"][:, 14])
    expected_forward_15 = torch.zeros_like(graph.edata["grid"][:, 15])
    physical_valid_14 = graph.edata["face_uv_valid"][:, 0]
    physical_valid_15 = graph.edata["face_uv_valid"][:, 1]
    expected_forward_14[physical_valid_14] = (
        graph.edata["grid"][:, 14][physical_valid_14]
        - edge_statistics.side_normal_curvature_mean
    ) / edge_statistics.side_normal_curvature_std
    expected_forward_15[physical_valid_15] = (
        graph.edata["grid"][:, 15][physical_valid_15]
        - edge_statistics.side_normal_curvature_mean
    ) / edge_statistics.side_normal_curvature_std
    torch.testing.assert_close(
        raw_message_grid[0::2, 14], expected_forward_14
    )
    torch.testing.assert_close(
        raw_message_grid[0::2, 15], expected_forward_15
    )
    torch.testing.assert_close(
        raw_message_grid[1::2, 14],
        torch.flip(expected_forward_15, dims=(1,)),
    )
    torch.testing.assert_close(
        raw_message_grid[1::2, 15],
        torch.flip(expected_forward_14, dims=(1,)),
    )

    assert view.physical_num_nodes == node_count
    assert view.physical_num_edges == edge_count
    assert torch.equal(
        view.physical_batch_num_nodes, graph.batch_num_nodes()
    )
    assert torch.equal(
        view.physical_batch_num_edges, graph.batch_num_edges()
    )
    assert torch.equal(
        message_view.message_graph.batch_num_nodes(),
        graph.batch_num_nodes(),
    )
    assert torch.equal(
        message_view.message_graph.batch_num_edges(),
        graph.batch_num_edges() * 2,
    )
    assert view.node_attr.device == graph.device
    assert view.node_grid.device == graph.device
    assert message_view.message_graph.device == graph.device

    output_fields = {field.name for field in fields(BRepModelInputView)}
    for forbidden in ("seg_y", "process_y", "quality", "bottom_y"):
        assert forbidden not in output_fields
        assert forbidden not in message_view.message_graph.ndata
        assert forbidden not in message_view.message_graph.edata
    assert len(message_view.message_graph.ndata) == 0
    assert len(message_view.message_graph.edata) == 0


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def check_statistics_compatibility():
    raw_attr, raw_uv = make_statistics(loader_style=False)
    loader_attr, loader_uv = make_statistics(loader_style=True)
    raw_before = (copy.deepcopy(raw_attr), copy.deepcopy(raw_uv))
    loader_before = (copy.deepcopy(loader_attr), copy.deepcopy(loader_uv))
    raw_result = resolve_brep_model_input_statistics(raw_attr, raw_uv)
    loader_result = resolve_brep_model_input_statistics(
        loader_attr, loader_uv
    )
    assert_statistics_shapes(raw_result)
    assert_statistics_shapes(loader_result)
    assert loader_result.raw_face_attr_std[0] == 0
    assert loader_result.face_attr_std[0] == 1
    assert loader_result.raw_face_grid_std[0] == 0
    assert loader_result.face_grid_std[0] == 1

    inconsistent_attr = copy.deepcopy(loader_attr)
    inconsistent_attr["std_face_attr"][0] = 2.0
    expect_error(
        ValueError,
        lambda: resolve_brep_model_input_statistics(
            inconsistent_attr, loader_uv
        ),
    )
    inconsistent_uv = copy.deepcopy(loader_uv)
    inconsistent_uv["std_face_grid"][0] = 2.0
    expect_error(
        ValueError,
        lambda: resolve_brep_model_input_statistics(
            loader_attr, inconsistent_uv
        ),
    )
    inconsistent_edge_attr = copy.deepcopy(loader_attr)
    inconsistent_edge_attr["std_edge_attr"][0] = 2.0
    expect_error(
        ValueError,
        lambda: resolve_brep_model_input_statistics(
            inconsistent_edge_attr, loader_uv
        ),
    )
    inconsistent_edge_uv = copy.deepcopy(loader_uv)
    inconsistent_edge_uv["std_edge_grid"][0] = 2.0
    expect_error(
        ValueError,
        lambda: resolve_brep_model_input_statistics(
            loader_attr, inconsistent_edge_uv
        ),
    )
    for current, before in (
        (raw_attr, raw_before[0]),
        (raw_uv, raw_before[1]),
        (loader_attr, loader_before[0]),
        (loader_uv, loader_before[1]),
    ):
        for key, value in current.items():
            if isinstance(value, torch.Tensor):
                assert torch.equal(value, before[key])
            else:
                assert value == before[key]
    return raw_result, raw_attr, raw_uv


def check_bad_graph_inputs(statistics):
    graph = make_graph_a()
    expect_error(
        ValueError,
        lambda: build_brep_model_input_view(
            graph, statistics, physical_graph_is_standardized=True
        ),
    )

    missing = make_graph_a()
    missing.ndata.pop("x")
    expect_error(
        KeyError,
        lambda: build_brep_model_input_view(missing, statistics),
    )

    wrong_shape = make_graph_a()
    wrong_shape.ndata["x"] = wrong_shape.ndata["x"][:, :15]
    expect_error(
        ValueError,
        lambda: build_brep_model_input_view(wrong_shape, statistics),
    )

    wrong_dtype = make_graph_a()
    wrong_dtype.edata["grid"] = wrong_dtype.edata["grid"].to(torch.float64)
    expect_error(
        TypeError,
        lambda: build_brep_model_input_view(wrong_dtype, statistics),
    )

    invalid_uv = make_graph_a()
    invalid_uv.edata["face_uv"][0, 0, 2] = torch.tensor([0.2, -0.2])
    expect_error(
        ValueError,
        lambda: build_brep_model_input_view(invalid_uv, statistics),
    )

    nonfinite = make_graph_a()
    nonfinite.ndata["grid"][0, 6, 0, 0] = float("nan")
    expect_error(
        ValueError,
        lambda: build_brep_model_input_view(nonfinite, statistics),
    )
    nonfinite_edge = make_graph_a()
    nonfinite_edge.edata["x"][0, 0] = float("inf")
    expect_error(
        ValueError,
        lambda: build_brep_model_input_view(nonfinite_edge, statistics),
    )


def main():
    statistics, attr_stat, uv_stat = check_statistics_compatibility()
    attr_before = copy.deepcopy(attr_stat)
    uv_before = copy.deepcopy(uv_stat)

    graph_a = make_graph_a()
    graph_b = make_graph_b()
    for graph in (graph_a, graph_b):
        before = clone_graph_inputs(graph)
        view = build_brep_model_input_view(graph, statistics)
        assert_view(graph, view, statistics)
        assert_graph_unchanged(graph, before)

    seam_view = build_brep_model_input_view(graph_b, statistics)
    seam_src, seam_dst = seam_view.message_view.message_graph.edges(
        order="eid"
    )
    assert torch.equal(seam_src, torch.tensor([0, 0]))
    assert torch.equal(seam_dst, torch.tensor([0, 0]))
    assert torch.equal(
        seam_view.message_view.message_is_self_loop,
        torch.tensor([True, True]),
    )

    batch_graph = dgl.batch([graph_a, graph_b])
    batch_before = clone_graph_inputs(batch_graph)
    batch_view = build_brep_model_input_view(batch_graph, statistics)
    assert_view(batch_graph, batch_view, statistics)
    assert_graph_unchanged(batch_graph, batch_before)
    assert torch.equal(
        batch_view.physical_batch_num_nodes, torch.tensor([3, 2])
    )
    assert torch.equal(
        batch_view.physical_batch_num_edges, torch.tensor([2, 1])
    )
    assert torch.equal(
        batch_view.message_view.message_graph.batch_num_edges(),
        torch.tensor([4, 2]),
    )

    check_bad_graph_inputs(statistics)
    for current, before in ((attr_stat, attr_before), (uv_stat, uv_before)):
        for key, value in current.items():
            if isinstance(value, torch.Tensor):
                assert torch.equal(value, before[key])
            else:
                assert value == before[key]

    print("BREP_GRAPH_MODEL_INPUT_VIEW_CHECK_PASS")
    print("graph_a_nodes=3 physical_edges=2 message_edges=4")
    print("graph_b_nodes=2 seam_edges=1 message_edges=2")
    print("batch_nodes=[3,2] physical_edges=[2,1] message_edges=[4,2]")


if __name__ == "__main__":
    main()
