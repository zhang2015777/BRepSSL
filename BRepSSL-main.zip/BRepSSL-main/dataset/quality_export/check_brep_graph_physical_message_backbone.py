

import sys
from dataclasses import fields
from pathlib import Path

import dgl
import torch
from torch import nn


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataset.quality_export.check_brep_graph_geometry_encoder import (
    assert_model_input_unchanged,
    make_batch,
    make_empty_message_student,
    make_statistics,
    snapshot_model_input,
)
from models.brep_geometry_encoder import BRepGeometryEncoding
from models.brep_physical_message_backbone import (
    BRepPhysicalMessageBackbone,
    BRepPhysicalMessageBackboneOutput,
)
from models.brep_pretrain_input_masking import (
    build_masked_brep_student_input,
    sample_brep_pretrain_mask_plan,
)
from models.layers import EdgeMPNN


def snapshot_student(student):
    src, dst = student.message_graph.edges(order="eid")
    return {
        "node_attr": student.node_attr.clone(),
        "node_grid": student.node_grid.clone(),
        "edge_attr": student.message_edge_attr.clone(),
        "edge_grid": student.message_edge_grid.clone(),
        "uv": student.message_edge_face_uv.clone(),
        "valid": student.message_edge_face_uv_valid.clone(),
        "mapping": student.message_to_physical_edge.clone(),
        "src": src.clone(),
        "dst": dst.clone(),
    }


def assert_student_unchanged(student, before):
    torch.testing.assert_close(student.node_attr, before["node_attr"])
    torch.testing.assert_close(student.node_grid, before["node_grid"])
    torch.testing.assert_close(
        student.message_edge_attr,
        before["edge_attr"],
    )
    torch.testing.assert_close(
        student.message_edge_grid,
        before["edge_grid"],
    )
    torch.testing.assert_close(student.message_edge_face_uv, before["uv"])
    assert torch.equal(
        student.message_edge_face_uv_valid,
        before["valid"],
    )
    assert torch.equal(student.message_to_physical_edge, before["mapping"])
    src, dst = student.message_graph.edges(order="eid")
    assert torch.equal(src, before["src"])
    assert torch.equal(dst, before["dst"])
    assert len(student.message_graph.ndata) == 0
    assert len(student.message_graph.edata) == 0


def assert_output_shapes(output, node_count, graph_count, message_count):
    assert isinstance(output, BRepPhysicalMessageBackboneOutput)
    assert output.node_emb.shape == (node_count, 128)
    assert output.graph_emb.shape == (graph_count, 128)
    assert output.local_global_feat.shape == (node_count, 256)
    assert output.message_edge_emb.shape == (message_count, 128)
    assert output.route_gate.shape == (message_count, 1)
    for field in fields(BRepPhysicalMessageBackboneOutput):
        value = getattr(output, field.name)
        assert torch.all(torch.isfinite(value))
    assert torch.all(output.route_gate >= 0)
    assert torch.all(output.route_gate <= 1)


def main():
    torch.manual_seed(601)
    statistics = make_statistics()
    batch = make_batch(statistics, include_b=True)
    backbone = BRepPhysicalMessageBackbone()
    backbone.eval()
    assert backbone.damped_diffusion.edge_direction_mode == "directed_messages"
    assert backbone.iba_dmp.num_layers == 3
    edge_mpnns = [layer.edge_mpnn for layer in backbone.iba_dmp.layers]
    assert len(edge_mpnns) == 3
    assert all(isinstance(module, EdgeMPNN) for module in edge_mpnns)
    expected_batch_norms = {id(module.norm_drop[0]) for module in edge_mpnns}
    actual_batch_norms = {
        id(module)
        for module in backbone.modules()
        if isinstance(module, nn.modules.batchnorm._BatchNorm)
    }
    assert actual_batch_norms == expected_batch_norms
    forbidden_class_names = {
        "NodeMPNN",
        "NodeMPNNV2",
        "PNAConvTower",
        "MaskAwareFaceUVEncoder",
        "DirectionConsistentEdgeUVEncoder",
    }
    assert not (
        forbidden_class_names
        & {module.__class__.__name__ for module in backbone.modules()}
    )

    full_before = snapshot_model_input(batch.model_input)
    geometry_only = backbone.encode_full_geometry(batch.model_input)
    assert geometry_only.node_feat.shape == (6, 128)
    assert geometry_only.message_edge_feat.shape == (8, 128)
    execution_order = []
    diffusion_hook = backbone.damped_diffusion.register_forward_hook(
        lambda module, inputs, output: execution_order.append("diffusion")
    )
    attention_hook = backbone.attention_refiner.register_forward_hook(
        lambda module, inputs, output: execution_order.append("attention")
    )
    full_output = backbone.forward_full(batch.model_input)
    diffusion_hook.remove()
    attention_hook.remove()
    assert execution_order == ["diffusion", "attention"]
    assert_output_shapes(full_output, 6, 2, 8)
    assert batch.model_input.physical_num_edges == 4
    assert full_output.message_edge_emb.shape[0] == 8
    for edge_index in range(4):
        assert not torch.allclose(
            full_output.message_edge_emb[2 * edge_index],
            full_output.message_edge_emb[2 * edge_index + 1],
        )
    assert not torch.allclose(
        full_output.message_edge_emb[-2],
        full_output.message_edge_emb[-1],
    )
    assert_model_input_unchanged(batch.model_input, full_before)
    assert len(batch.model_input.message_view.message_graph.ndata) == 0
    assert len(batch.model_input.message_view.message_graph.edata) == 0

    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.34,
        negative_edge_ratio=0.0,
        generator=torch.Generator().manual_seed(602),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    student = build_masked_brep_student_input(batch, plan)
    student_before = snapshot_student(student)
    student_output = backbone.forward_student(student, plan.node_mask)
    assert_output_shapes(
        student_output,
        6,
        2,
        student.message_graph.num_edges(),
    )
    assert student_output.message_edge_emb.shape[0] == 6
    for masked_physical in plan.masked_physical_edge_indices:
        assert not torch.any(
            student.message_to_physical_edge == masked_physical
        )
    assert_student_unchanged(student, student_before)

    empty_context_student = make_empty_message_student(student)
    empty_context_output = backbone.forward_student(
        empty_context_student,
        plan.node_mask,
    )
    assert_output_shapes(empty_context_output, 6, 2, 0)
    assert not torch.allclose(
        student_output.node_emb[plan.node_mask],
        empty_context_output.node_emb[plan.node_mask],
    )

    graph_a_batch = make_batch(statistics, include_b=False)
    all_edge_plan = sample_brep_pretrain_mask_plan(
        graph_a_batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=1.0,
        negative_edge_ratio=0.0,
        generator=torch.Generator().manual_seed(603),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    no_message_student = build_masked_brep_student_input(
        graph_a_batch,
        all_edge_plan,
    )
    assert no_message_student.message_graph.num_edges() == 0
    no_message_output = backbone.forward_student(
        no_message_student,
        all_edge_plan.node_mask,
    )
    assert_output_shapes(no_message_output, 4, 1, 0)

    one_graph = dgl.graph(([0], [0]), num_nodes=1)
    one_graph.set_batch_num_nodes(torch.tensor([1]))
    one_graph.set_batch_num_edges(torch.tensor([1]))
    one_geometry = BRepGeometryEncoding(
        node_feat=torch.linspace(-1.0, 1.0, 128).reshape(1, 128),
        message_edge_feat=torch.linspace(1.0, -1.0, 128).reshape(1, 128),
    )
    one_output = backbone.forward_encoded(one_graph, one_geometry)
    assert_output_shapes(one_output, 1, 1, 1)
    assert len(one_graph.ndata) == 0
    assert len(one_graph.edata) == 0

    first = backbone.forward_full(batch.model_input)
    second = backbone.forward_full(batch.model_input)
    for field in fields(BRepPhysicalMessageBackboneOutput):
        torch.testing.assert_close(
            getattr(first, field.name),
            getattr(second, field.name),
            rtol=0.0,
            atol=1e-6,
        )
    print("BREP_GRAPH_PHYSICAL_MESSAGE_BACKBONE_CHECK_PASS")
    print("full_batch_shapes=node[6,128] graph[2,128] edge[8,128]")
    print("student_deleted_edges_and_zero_message_graph=PASS")
    print("directed_diffusion_then_gatv2_order=PASS")
    print("legacy_mpnn_and_direction_average_absent=PASS")


if __name__ == "__main__":
    main()
