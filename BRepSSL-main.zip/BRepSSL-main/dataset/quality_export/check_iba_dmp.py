

import sys
from pathlib import Path

import dgl
import torch
from torch import nn


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.iba_dmp import IBADMPBlock, IBADMPEncoding, IBADMPStack
from models.layers import DropPath, EdgeMPNN


def make_graphs():
    graph_a = dgl.graph(
        ([0, 1, 1, 2], [1, 0, 2, 1]),
        num_nodes=4,
    )
    graph_b = dgl.graph(([0, 0], [0, 0]), num_nodes=2)
    return graph_a, graph_b, dgl.batch([graph_a, graph_b])


def deterministic_features(graph):
    node_feat = (
        torch.arange(graph.num_nodes() * 128, dtype=torch.float32)
        .reshape(graph.num_nodes(), 128)
        / 100.0
    )
    edge_feat = (
        torch.arange(graph.num_edges() * 128, dtype=torch.float32)
        .reshape(graph.num_edges(), 128)
        / 80.0
    )
    if graph.num_edges() >= 2:
        edge_feat[1] = -edge_feat[1] - 0.7
    return node_feat, edge_feat


def assert_gradients(module, prefixes):
    named = dict(module.named_parameters())
    for prefix in prefixes:
        gradients = [
            parameter.grad
            for name, parameter in named.items()
            if prefix in name
        ]
        assert gradients, f"No parameters found for {prefix}"
        assert any(gradient is not None for gradient in gradients)
        for gradient in gradients:
            if gradient is not None:
                assert torch.all(torch.isfinite(gradient))


def main():
    torch.manual_seed(501)
    graph_a, graph_b, batch_graph = make_graphs()
    node_feat, edge_feat = deterministic_features(batch_graph)
    node_before = node_feat.clone()
    edge_before = edge_feat.clone()

    stack = IBADMPStack(num_layers=3, drop=0.0)
    stack.eval()
    output = stack(batch_graph, node_feat, edge_feat)
    assert isinstance(output, IBADMPEncoding)
    assert output.node_feat.shape == (6, 128)
    assert output.message_edge_feat.shape == (6, 128)
    assert output.route_gate.shape == (6, 1)
    assert torch.all(output.route_gate >= 0)
    assert torch.all(output.route_gate <= 1)
    assert not torch.allclose(output.route_gate[0], output.route_gate[1])
    assert not torch.allclose(output.message_edge_feat, edge_feat)
    assert torch.equal(node_feat, node_before)
    assert torch.equal(edge_feat, edge_before)

    changed_edge = edge_feat.clone()
    changed_edge[0] += 3.0
    changed_gate = stack(batch_graph, node_feat, changed_edge).route_gate
    assert not torch.allclose(output.route_gate[0], changed_gate[0])

    changed_node = node_feat.clone()
    changed_node[0] += torch.linspace(-2.0, 2.0, 128)
    changed_node_output = stack(
        batch_graph,
        changed_node,
        edge_feat,
    )
    assert not torch.allclose(
        output.node_feat[1],
        changed_node_output.node_feat[1],
    )

    first_block = stack.layers[0]
    assert (
        first_block.continuity_message_network
        is not first_block.boundary_message_network
    )
    assert (
        first_block.continuity_message_network[0].in_features == 256
    )
    assert first_block.boundary_message_network[0].in_features == 384
    assert len({id(layer) for layer in stack.layers}) == 3
    assert len({id(layer.edge_mpnn) for layer in stack.layers}) == 3
    assert isinstance(first_block.edge_mpnn, EdgeMPNN)
    assert first_block.edge_mpnn.node_dim == 128
    assert first_block.edge_mpnn.edge_dim == 128
    assert first_block.edge_mpnn.mlp.linears[0].out_features == 256
    assert first_block.edge_mpnn.norm_drop[1].p == 0.3
    assert isinstance(first_block.edge_mpnn.drop_path1, DropPath)
    assert first_block.edge_mpnn.drop_path1.drop_prob == 0.3
    assert isinstance(first_block.edge_mpnn.drop_path2, DropPath)
    assert first_block.edge_mpnn.drop_path2.drop_prob == 0.3
    assert not hasattr(first_block, "edge_update_network")
    assert not hasattr(first_block, "edge_output_norm")
    assert not hasattr(first_block, "edge_residual_scale")

    node_a = node_feat[:4]
    edge_a = edge_feat[:4]
    node_b = node_feat[4:]
    edge_b = edge_feat[4:]
    separate_a = stack(graph_a, node_a, edge_a)
    separate_b = stack(graph_b, node_b, edge_b)
    torch.testing.assert_close(
        output.node_feat,
        torch.cat((separate_a.node_feat, separate_b.node_feat), dim=0),
        rtol=1e-5,
        atol=3e-6,
    )
    torch.testing.assert_close(
        output.message_edge_feat,
        torch.cat(
            (
                separate_a.message_edge_feat,
                separate_b.message_edge_feat,
            ),
            dim=0,
        ),
        rtol=1e-5,
        atol=3e-6,
    )
    torch.testing.assert_close(
        output.route_gate,
        torch.cat((separate_a.route_gate, separate_b.route_gate), dim=0),
        rtol=1e-5,
        atol=3e-6,
    )
    assert torch.all(torch.isfinite(output.node_feat[3]))
    assert torch.all(torch.isfinite(separate_b.node_feat))

    no_edge_graph = dgl.graph(
        (
            torch.empty(0, dtype=torch.int64),
            torch.empty(0, dtype=torch.int64),
        ),
        num_nodes=2,
    )
    no_edge_node = torch.arange(256, dtype=torch.float32).reshape(2, 128)
    no_edge = stack(
        no_edge_graph,
        no_edge_node,
        torch.empty(0, 128),
    )
    assert no_edge.node_feat.shape == (2, 128)
    assert no_edge.message_edge_feat.shape == (0, 128)
    assert no_edge.route_gate.shape == (0, 1)
    assert torch.all(torch.isfinite(no_edge.node_feat))
    expected_batch_norms = {
        id(layer.edge_mpnn.norm_drop[0]) for layer in stack.layers
    }
    actual_batch_norms = {
        id(module)
        for module in stack.modules()
        if isinstance(module, nn.modules.batchnorm._BatchNorm)
    }
    assert actual_batch_norms == expected_batch_norms

    repeat = stack(batch_graph, node_feat, edge_feat)
    torch.testing.assert_close(
        output.node_feat,
        repeat.node_feat,
        rtol=0.0,
        atol=1e-7,
    )
    torch.testing.assert_close(
        output.message_edge_feat,
        repeat.message_edge_feat,
        rtol=0.0,
        atol=1e-7,
    )
    torch.testing.assert_close(
        output.route_gate,
        repeat.route_gate,
        rtol=0.0,
        atol=1e-7,
    )

    gradient_block = IBADMPBlock(drop=0.0)
    gradient_block.train()
    grad_node = node_a.clone().requires_grad_(True)
    grad_edge = edge_a.clone().requires_grad_(True)
    grad_output = gradient_block(graph_a, grad_node, grad_edge)
    node_weights = torch.linspace(
        -1.0,
        1.0,
        grad_output.node_feat.numel(),
    ).reshape_as(grad_output.node_feat)
    edge_weights = torch.linspace(
        1.0,
        -1.0,
        grad_output.message_edge_feat.numel(),
    ).reshape_as(grad_output.message_edge_feat)
    loss = (
        (grad_output.node_feat * node_weights).sum()
        + (grad_output.message_edge_feat * edge_weights).sum()
        + grad_output.route_gate.sum()
    )
    loss.backward()
    assert torch.all(torch.isfinite(grad_node.grad))
    assert torch.all(torch.isfinite(grad_edge.grad))
    assert_gradients(
        gradient_block,
        (
            "route_network",
            "continuity_message_network",
            "boundary_message_network",
            "node_update_network",
            "edge_mpnn",
        ),
    )
    print("IBA_DMP_CHECK_PASS")
    print("dual_channel_route_and_dynamic_edge_update=PASS")
    print("batch_isolation_zero_edge_seam=PASS")
    print("deterministic_forward_and_finite_gradients=PASS")


if __name__ == "__main__":
    main()
