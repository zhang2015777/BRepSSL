

import copy
import sys
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory

import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from configs.main_experiment_config import PRETRAIN_MAIN_CONFIG
from dataloader.brep_pretrain import (
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
    move_brep_pretrain_model_input_batch,
)
from dataset.quality_export.check_brep_graph_geometry_encoder import (
    make_batch,
    make_graph_a,
    make_graph_b,
    make_statistics,
    snapshot_model_input,
)
from engine.pretrain_brep_mask import (
    attach_edge_config,
    attach_edge_decoder_config,
    build_fixed_eval_mask_generator,
    fixed_eval_mask_seed,
    init_metric_lists,
    is_better_fixed_eval_loss,
    save_pretrainer_checkpoint,
    validate_pretrainer_checkpoint_payload,
)
from models.brep_physical_message_backbone import (
    BRepPhysicalMessageBackbone,
    FEATURE_PROTOCOL,
)
from models.brep_physical_message_pretrainer import (
    BRepPhysicalMessageMaskedPretrainer,
    PRETRAINER_CHECKPOINT_FORMAT,
)
from models.brep_pretrain_input_masking import (
    EDGE_CANDIDATE_POLICY,
    build_masked_brep_student_input,
    sample_brep_pretrain_mask_plan,
)
from models.graph_masking import BATCH_TOPOLOGY_CACHE_ATTR


def make_args(model):
    config = dict(PRETRAIN_MAIN_CONFIG)
    config["dataset_root"] = "PURE_MEMORY_ONLY"
    config["node_mask_ratio"] = config["mask_ratio"]
    config["edge_mask_ratio"] = config["mask_ratio"]
    args = SimpleNamespace(**config)
    attach_edge_config(args)
    attach_edge_decoder_config(args, model)
    return args


def main():
    torch.manual_seed(931)
    statistics = make_statistics()
    cpu_batch = make_batch(statistics, include_b=True)
    before = snapshot_model_input(cpu_batch.model_input)
    topology_src_before, topology_dst_before = (
        cpu_batch.physical_topology_graph.edges(order="eid")
    )
    cache_before = copy.deepcopy(
        getattr(
            cpu_batch.physical_topology_graph,
            BATCH_TOPOLOGY_CACHE_ATTR,
        )
    )
    moved = move_brep_pretrain_model_input_batch(cpu_batch, "cpu")
    assert moved is not cpu_batch
    assert moved.model_input is not cpu_batch.model_input
    assert moved.model_input.node_attr.data_ptr() != (
        cpu_batch.model_input.node_attr.data_ptr()
    )
    torch.testing.assert_close(cpu_batch.model_input.node_attr, before["node_attr"])
    torch.testing.assert_close(cpu_batch.model_input.node_grid, before["node_grid"])
    topology_src_after, topology_dst_after = (
        cpu_batch.physical_topology_graph.edges(order="eid")
    )
    assert torch.equal(topology_src_before, topology_src_after)
    assert torch.equal(topology_dst_before, topology_dst_after)
    assert getattr(
        moved.physical_topology_graph,
        BATCH_TOPOLOGY_CACHE_ATTR,
    ) == cache_before
    assert getattr(
        cpu_batch.physical_topology_graph,
        BATCH_TOPOLOGY_CACHE_ATTR,
    ) == cache_before
    tensors = (
        moved.model_input.node_attr,
        moved.model_input.node_grid,
        moved.model_input.message_view.message_edge_attr,
        moved.model_input.message_view.message_edge_grid,
        moved.model_input.message_view.message_edge_face_uv,
        moved.model_input.message_view.message_edge_face_uv_valid,
        moved.model_input.message_view.message_to_physical_edge,
    )
    assert all(value.device.type == "cpu" for value in tensors)
    assert moved.physical_topology_graph.device.type == "cpu"
    assert moved.model_input.message_view.message_graph.device.type == "cpu"

    seed_a = fixed_eval_mask_seed(moved, 424242)
    seed_b = fixed_eval_mask_seed(moved, 424242)
    assert seed_a == seed_b
    generator_a = build_fixed_eval_mask_generator(moved, 424242)
    generator_b = build_fixed_eval_mask_generator(moved, 424242)
    plan_a = sample_brep_pretrain_mask_plan(
        moved,
        node_mask_ratio=0.6,
        edge_mask_ratio=0.6,
        negative_edge_ratio=1.0,
        generator=generator_a,
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    plan_b = sample_brep_pretrain_mask_plan(
        moved,
        node_mask_ratio=0.6,
        edge_mask_ratio=0.6,
        negative_edge_ratio=1.0,
        generator=generator_b,
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    assert torch.equal(plan_a.node_mask, plan_b.node_mask)
    assert torch.equal(plan_a.physical_edge_mask, plan_b.physical_edge_mask)
    assert seed_a != fixed_eval_mask_seed(moved, 424243)
    plan_different_seed = sample_brep_pretrain_mask_plan(
        moved,
        node_mask_ratio=0.6,
        edge_mask_ratio=0.6,
        negative_edge_ratio=1.0,
        generator=build_fixed_eval_mask_generator(moved, 424243),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    assert (
        not torch.equal(plan_a.node_mask, plan_different_seed.node_mask)
        or not torch.equal(
            plan_a.physical_edge_mask,
            plan_different_seed.physical_edge_mask,
        )
    )

    reversed_batch = collate_brep_pretrain_model_input(
        [
            BRepPretrainModelInputSample("part_b", make_graph_b()),
            BRepPretrainModelInputSample("part_a", make_graph_a()),
        ],
        statistics=statistics,
    )
    assert seed_a != fixed_eval_mask_seed(reversed_batch, 424242)

    model = BRepPhysicalMessageMaskedPretrainer(
        node_mask_ratio=0.6,
        edge_mask_ratio=0.6,
        negative_edge_ratio=1.0,
        decoder_drop=0.0,
    )
    model.train()
    out = model(moved, mask_plan=plan_a)
    formal_metrics = set(init_metric_lists())
    assert formal_metrics.issubset(out)
    assert {
        "loss_node_embedding",
        "loss_edge_embedding",
    }.issubset(formal_metrics)
    assert not {
        "loss_node_attr",
        "loss_node_grid_continuous",
        "loss_node_inside",
        "loss_edge_attr",
        "loss_edge_grid",
        "loss_edge_uv_coordinate",
        "loss_edge_uv_valid",
        "num_edge_grid_valid_values",
        "num_edge_uv_valid_points",
    }.intersection(formal_metrics)
    out["loss"].backward()
    assert torch.isfinite(out["loss"])
    assert any(
        parameter.grad is not None
        for parameter in model.parameters()
        if parameter.requires_grad
    )

    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=2,
    )
    args = make_args(model)
    source_manifest = {"files": ["PURE_MEMORY_ONLY"], "version": 1}
    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        backbone_path = temp_dir / "backbone.pth"
        model.backbone.eval()
        student = build_masked_brep_student_input(moved, plan_a)
        expected = model.backbone.forward_student(student, plan_a.node_mask)
        model.backbone.save_backbone(backbone_path)
        loaded = BRepPhysicalMessageBackbone()
        loaded.load_backbone(backbone_path, strict=True)
        loaded.eval()
        actual = loaded.forward_student(student, plan_a.node_mask)
        for name in (
            "node_emb",
            "graph_emb",
            "local_global_feat",
            "message_edge_emb",
            "route_gate",
        ):
            torch.testing.assert_close(
                getattr(expected, name),
                getattr(actual, name),
                rtol=0.0,
                atol=1e-6,
            )

        bare_path = temp_dir / "bare.pth"
        torch.save(model.backbone.state_dict(), bare_path)
        try:
            loaded.load_backbone(bare_path)
        except (TypeError, ValueError):
            pass
        else:
            raise AssertionError("Bare legacy state_dict must be rejected")

        old_pretrainer_path = temp_dir / "old_pretrainer.pth"
        torch.save(
            {
                "checkpoint_format": "incompatible_graph_mask_pretrainer_v1",
                "model_state_dict": {},
            },
            old_pretrainer_path,
        )
        try:
            loaded.load_backbone(old_pretrainer_path)
        except (TypeError, ValueError):
            pass
        else:
            raise AssertionError("Legacy pretrainer checkpoint must be rejected")

        invalid_payload = torch.load(backbone_path)
        invalid_payload["feature_protocol"] = dict(FEATURE_PROTOCOL)
        invalid_payload["feature_protocol"]["face_attr_dim"] = 10
        invalid_path = temp_dir / "invalid_feature.pth"
        torch.save(invalid_payload, invalid_path)
        try:
            loaded.load_backbone(invalid_path, strict=False)
        except ValueError:
            pass
        else:
            raise AssertionError("Feature protocol mismatch must be rejected")

        pretrainer_path = temp_dir / "pretrainer.pth"
        payload = save_pretrainer_checkpoint(
            pretrainer_path,
            3,
            model,
            optimizer,
            scheduler,
            args,
            1.25,
            2,
            {"loss_total": 1.5},
            {"loss_total": 1.25},
            scaler=None,
            source_manifest=source_manifest,
        )
        required = {
            "checkpoint_format",
            "epoch",
            "pretrainer_state_dict",
            "optimizer_state_dict",
            "scheduler_state_dict",
            "scaler_state_dict",
            "args",
            "train_metrics",
            "eval_metrics",
            "best_eval_loss",
            "best_epoch",
            "input_protocol",
            "feature_protocol",
            "mask_policy",
            "edge_candidate_policy",
            "backbone_checkpoint_format",
            "eval_mask_seed",
            "source_manifest",
            "pretrain_method",
            "embedding_targets",
        }
        assert required.issubset(payload)
        assert payload["checkpoint_format"] == PRETRAINER_CHECKPOINT_FORMAT
        assert payload["checkpoint_format"] == (
            "brep_physical_message_pretrainer_v3"
        )
        assert payload["pretrain_method"] == (
            "physical_message_structured_mask_"
            "embedding_reconstruction_v1"
        )
        assert payload["edge_candidate_policy"] == EDGE_CANDIDATE_POLICY
        assert payload["source_manifest"] == source_manifest
        embedding_targets = payload["embedding_targets"]
        assert embedding_targets["target_encoder"] == (
            "shared_BRepGeometryEncoder_no_grad"
        )
        assert embedding_targets["target_backbone_scope"] == (
            "geometry_encoder_only"
        )
        assert embedding_targets["node_target_dim"] == 128
        assert embedding_targets["edge_target_dim"] == 128
        assert embedding_targets["teacher_backbone"] is False
        assert embedding_targets["ema_teacher"] is False
        assert "feature_targets" not in payload
        stored = torch.load(pretrainer_path)
        assert required.issubset(stored)
        validate_pretrainer_checkpoint_payload(stored)

        incompatible_v2 = dict(stored)
        incompatible_v2["checkpoint_format"] = (
            "incompatible_physical_message_pretrainer_v2"
        )
        try:
            validate_pretrainer_checkpoint_payload(incompatible_v2)
        except ValueError:
            pass
        else:
            raise AssertionError("v2 pretrainer checkpoint must be rejected")

    assert is_better_fixed_eval_loss(0.9, 1.0)
    assert not is_better_fixed_eval_loss(1.0, 1.0)
    assert not is_better_fixed_eval_loss(1.1, 1.0)
    assert args.pretrain_eval_split == "eval"
    assert not hasattr(args, "pretrain_test_split")

    print("PRETRAIN_BREP_GRAPH_PHYSICAL_MESSAGE_ENGINE_CHECK_PASS")


if __name__ == "__main__":
    main()
