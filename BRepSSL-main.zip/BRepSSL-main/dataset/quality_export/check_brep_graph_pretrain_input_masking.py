

import copy
import sys
from dataclasses import fields, replace
from pathlib import Path

import dgl
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import (
    BRepPretrainModelInputBatch,
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
)
from models.brep_pretrain_input_masking import (
    BRepMaskedStudentInput,
    BRepPretrainMaskPlan,
    build_masked_brep_student_input,
    compute_brep_pretrain_batch_signature,
    sample_brep_pretrain_mask_plan,
)
from models.graph_masking import (
    BATCH_TOPOLOGY_CACHE_ATTR,
    SINGLE_TOPOLOGY_CACHE_ATTR,
    build_single_graph_topology_cache,
)
from utils.brep_model_input_view import resolve_brep_model_input_statistics


def make_statistics():
    attr_stat = {
        "mean_face_attr": torch.linspace(-1.0, 1.0, 16),
        "std_face_attr": torch.linspace(0.5, 2.0, 16),
        "mean_edge_attr": torch.linspace(-2.0, 2.0, 16),
        "std_edge_attr": torch.linspace(0.75, 2.25, 16),
    }
    uv_stat = {
        "std_ddof": 0,
        "face_standardized_channels": [6, 7, 9],
        "mean_face_grid": torch.tensor([1.0, -2.0, 3.0]),
        "std_face_grid": torch.tensor([2.0, 4.0, 5.0]),
        "count_face_grid": torch.tensor([11, 12, 13]),
        "edge_standardized_channels": [12, 14, 15],
        "mean_edge_grid": torch.tensor([2.0, 1.0, 5.0]),
        "std_edge_grid": torch.tensor([3.0, 2.0, 4.0]),
        "count_edge_grid": torch.tensor([7, 3, 5]),
    }
    return resolve_brep_model_input_statistics(attr_stat, uv_stat)


def attach_raw_features(graph, value_offset):
    node_count = graph.num_nodes()
    edge_count = graph.num_edges()
    graph.ndata["x"] = (
        torch.arange(node_count * 16, dtype=torch.float32).reshape(
            node_count, 16
        )
        + value_offset
    )
    graph.ndata["grid"] = (
        torch.arange(
            node_count * 11 * 5 * 5,
            dtype=torch.float32,
        ).reshape(node_count, 11, 5, 5)
        + 100.0
        + value_offset
    )
    graph.ndata["grid"][:, 10] = (
        torch.arange(25, dtype=torch.float32).reshape(1, 5, 5) % 2
    )

    graph.edata["x"] = (
        torch.arange(edge_count * 16, dtype=torch.float32).reshape(
            edge_count, 16
        )
        + 200.0
        + value_offset
    )
    graph.edata["grid"] = (
        torch.arange(
            edge_count * 16 * 5,
            dtype=torch.float32,
        ).reshape(edge_count, 16, 5)
        + 300.0
        + value_offset
    )
    face_uv = torch.zeros(edge_count, 2, 5, 2, dtype=torch.float32)
    face_uv_valid = torch.ones(edge_count, 2, 5, dtype=torch.bool)
    for edge_index in range(edge_count):
        for side in range(2):
            for sample_index in range(5):
                face_uv[edge_index, side, sample_index] = torch.tensor(
                    [
                        -0.8 + 0.1 * sample_index + 0.03 * side,
                        0.8 - 0.1 * sample_index - 0.02 * edge_index,
                    ],
                    dtype=torch.float32,
                )
    if edge_count:
        face_uv_valid[0, 0, 2] = False
        face_uv[0, 0, 2] = 0.0
    graph.edata["face_uv"] = face_uv
    graph.edata["face_uv_valid"] = face_uv_valid
    setattr(
        graph,
        SINGLE_TOPOLOGY_CACHE_ATTR,
        build_single_graph_topology_cache(graph),
    )
    return graph


def make_graph_a():
    return attach_raw_features(
        dgl.graph(([0, 1, 2], [1, 2, 3]), num_nodes=4),
        0.0,
    )


def make_graph_b():
    return attach_raw_features(
        dgl.graph(([0], [0]), num_nodes=2),
        1000.0,
    )


def make_graph_parallel_seam():
    return attach_raw_features(
        dgl.graph(
            ([0, 0, 1, 2], [1, 1, 2, 2]),
            num_nodes=3,
        ),
        2000.0,
    )


def make_graph_a_reordered():
    return attach_raw_features(
        dgl.graph(([1, 0, 2], [2, 1, 3]), num_nodes=4),
        0.0,
    )


def make_batch(statistics, include_a=True, include_b=False):
    samples = []
    if include_a:
        samples.append(BRepPretrainModelInputSample("part_a", make_graph_a()))
    if include_b:
        samples.append(BRepPretrainModelInputSample("part_b", make_graph_b()))
    return collate_brep_pretrain_model_input(
        samples,
        statistics=statistics,
    )


def snapshot_batch(batch):
    topology_src, topology_dst = (
        batch.physical_topology_graph.edges(order="eid")
    )
    message = batch.model_input.message_view
    message_src, message_dst = message.message_graph.edges(order="eid")
    return {
        "node_attr": batch.model_input.node_attr.clone(),
        "node_grid": batch.model_input.node_grid.clone(),
        "message_edge_attr": message.message_edge_attr.clone(),
        "message_edge_grid": message.message_edge_grid.clone(),
        "message_edge_face_uv": message.message_edge_face_uv.clone(),
        "message_edge_face_uv_valid": (
            message.message_edge_face_uv_valid.clone()
        ),
        "message_to_physical_edge": (
            message.message_to_physical_edge.clone()
        ),
        "message_is_reverse": message.message_is_reverse.clone(),
        "message_is_self_loop": message.message_is_self_loop.clone(),
        "message_src": message_src.clone(),
        "message_dst": message_dst.clone(),
        "message_batch_nodes": message.message_graph.batch_num_nodes().clone(),
        "message_batch_edges": message.message_graph.batch_num_edges().clone(),
        "topology_src": topology_src.clone(),
        "topology_dst": topology_dst.clone(),
        "topology_batch_nodes": (
            batch.physical_topology_graph.batch_num_nodes().clone()
        ),
        "topology_batch_edges": (
            batch.physical_topology_graph.batch_num_edges().clone()
        ),
        "topology_cache": copy.deepcopy(
            getattr(
                batch.physical_topology_graph,
                BATCH_TOPOLOGY_CACHE_ATTR,
            )
        ),
    }


def assert_batch_unchanged(batch, before):
    model_input = batch.model_input
    message = model_input.message_view
    torch.testing.assert_close(model_input.node_attr, before["node_attr"])
    torch.testing.assert_close(model_input.node_grid, before["node_grid"])
    torch.testing.assert_close(
        message.message_edge_attr,
        before["message_edge_attr"],
    )
    torch.testing.assert_close(
        message.message_edge_grid,
        before["message_edge_grid"],
    )
    torch.testing.assert_close(
        message.message_edge_face_uv,
        before["message_edge_face_uv"],
    )
    assert torch.equal(
        message.message_edge_face_uv_valid,
        before["message_edge_face_uv_valid"],
    )
    assert torch.equal(
        message.message_to_physical_edge,
        before["message_to_physical_edge"],
    )
    assert torch.equal(
        message.message_is_reverse,
        before["message_is_reverse"],
    )
    assert torch.equal(
        message.message_is_self_loop,
        before["message_is_self_loop"],
    )
    message_src, message_dst = message.message_graph.edges(order="eid")
    assert torch.equal(message_src, before["message_src"])
    assert torch.equal(message_dst, before["message_dst"])
    assert torch.equal(
        message.message_graph.batch_num_nodes(),
        before["message_batch_nodes"],
    )
    assert torch.equal(
        message.message_graph.batch_num_edges(),
        before["message_batch_edges"],
    )
    topology_src, topology_dst = (
        batch.physical_topology_graph.edges(order="eid")
    )
    assert torch.equal(topology_src, before["topology_src"])
    assert torch.equal(topology_dst, before["topology_dst"])
    assert torch.equal(
        batch.physical_topology_graph.batch_num_nodes(),
        before["topology_batch_nodes"],
    )
    assert torch.equal(
        batch.physical_topology_graph.batch_num_edges(),
        before["topology_batch_edges"],
    )
    assert (
        getattr(
            batch.physical_topology_graph,
            BATCH_TOPOLOGY_CACHE_ATTR,
        )
        == before["topology_cache"]
    )


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def seeded_generator(seed):
    return torch.Generator().manual_seed(seed)


def assert_plan_protocol(batch, plan):
    assert isinstance(plan, BRepPretrainMaskPlan)
    node_count = batch.model_input.physical_num_nodes
    physical_edge_count = batch.model_input.physical_num_edges
    message_count = 2 * physical_edge_count
    assert plan.node_mask.dtype == torch.bool
    assert plan.node_mask.shape == (node_count,)
    assert plan.physical_edge_mask.dtype == torch.bool
    assert plan.physical_edge_mask.shape == (physical_edge_count,)
    assert plan.message_edge_mask.dtype == torch.bool
    assert plan.message_edge_mask.shape == (message_count,)
    assert plan.message_source_side_node_mask.shape == (message_count,)
    assert plan.message_destination_side_node_mask.shape == (message_count,)
    assert torch.equal(
        torch.nonzero(plan.node_mask, as_tuple=False).flatten(),
        plan.masked_node_indices,
    )
    assert torch.equal(
        torch.nonzero(plan.physical_edge_mask, as_tuple=False).flatten(),
        plan.masked_physical_edge_indices,
    )
    assert torch.equal(
        torch.nonzero(plan.message_edge_mask, as_tuple=False).flatten(),
        plan.masked_message_edge_indices,
    )
    assert torch.equal(
        torch.nonzero(~plan.message_edge_mask, as_tuple=False).flatten(),
        plan.kept_message_edge_indices,
    )
    assert torch.equal(
        plan.message_edge_mask[0::2],
        plan.physical_edge_mask,
    )
    assert torch.equal(
        plan.message_edge_mask[1::2],
        plan.physical_edge_mask,
    )
    for field in fields(BRepPretrainMaskPlan):
        value = getattr(plan, field.name)
        if isinstance(value, torch.Tensor):
            assert value.device == batch.physical_topology_graph.device


def check_node_only_mask(statistics):
    batch = make_batch(statistics, include_a=True)
    before = snapshot_batch(batch)
    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.0,
        negative_edge_ratio=0.0,
        generator=seeded_generator(11),
        min_mask_nodes=1,
        min_mask_edges=0,
    )
    assert_plan_protocol(batch, plan)
    assert plan.masked_node_indices.numel() == 1
    assert plan.masked_physical_edge_indices.numel() == 0
    student = build_masked_brep_student_input(batch, plan)
    assert isinstance(student, BRepMaskedStudentInput)
    assert student.message_graph.num_edges() == 6
    assert torch.equal(
        student.message_graph.batch_num_edges(),
        torch.tensor([6]),
    )
    assert torch.all(student.node_attr[plan.node_mask] == 0)
    assert torch.all(student.node_grid[plan.node_mask] == 0)
    torch.testing.assert_close(
        student.node_attr[~plan.node_mask],
        before["node_attr"][~plan.node_mask],
    )
    torch.testing.assert_close(
        student.node_grid[~plan.node_mask],
        before["node_grid"][~plan.node_mask],
    )

    source_mask = plan.message_source_side_node_mask
    destination_mask = plan.message_destination_side_node_mask
    incident = source_mask | destination_mask
    assert torch.all(student.message_edge_grid[source_mask, 6:9] == 0)
    assert torch.all(student.message_edge_grid[source_mask, 14] == 0)
    assert torch.all(student.message_edge_face_uv[source_mask, 0] == 0)
    assert not torch.any(
        student.message_edge_face_uv_valid[source_mask, 0]
    )
    assert torch.all(
        student.message_edge_grid[destination_mask, 9:12] == 0
    )
    assert torch.all(
        student.message_edge_grid[destination_mask, 15] == 0
    )
    assert torch.all(
        student.message_edge_face_uv[destination_mask, 1] == 0
    )
    assert not torch.any(
        student.message_edge_face_uv_valid[destination_mask, 1]
    )
    assert torch.all(student.message_edge_attr[incident, 0:3] == 0)
    assert torch.all(student.message_edge_grid[incident, 13] == 0)

    original_message = batch.model_input.message_view
    torch.testing.assert_close(
        student.message_edge_attr[:, 3:16],
        original_message.message_edge_attr[:, 3:16],
    )
    torch.testing.assert_close(
        student.message_edge_grid[:, 0:6],
        original_message.message_edge_grid[:, 0:6],
    )
    torch.testing.assert_close(
        student.message_edge_grid[:, 12],
        original_message.message_edge_grid[:, 12],
    )
    nonincident = ~incident
    torch.testing.assert_close(
        student.message_edge_attr[nonincident],
        original_message.message_edge_attr[nonincident],
    )
    torch.testing.assert_close(
        student.message_edge_grid[nonincident],
        original_message.message_edge_grid[nonincident],
    )
    torch.testing.assert_close(
        student.message_edge_face_uv[nonincident],
        original_message.message_edge_face_uv[nonincident],
    )
    assert torch.equal(
        student.message_edge_face_uv_valid[nonincident],
        original_message.message_edge_face_uv_valid[nonincident],
    )

    masked_node = int(plan.masked_node_indices.item())
    physical_src, physical_dst = (
        batch.physical_topology_graph.edges(order="eid")
    )
    incident_physical = torch.nonzero(
        (physical_src == masked_node) | (physical_dst == masked_node),
        as_tuple=False,
    ).flatten()
    assert incident_physical.numel() > 0
    for physical_edge_id in incident_physical.tolist():
        forward = 2 * physical_edge_id
        reverse = forward + 1
        assert (
            plan.message_source_side_node_mask[forward]
            == plan.message_destination_side_node_mask[reverse]
        )
        assert (
            plan.message_destination_side_node_mask[forward]
            == plan.message_source_side_node_mask[reverse]
        )
        assert (
            plan.message_source_side_node_mask[forward]
            != plan.message_destination_side_node_mask[forward]
        )
    assert_batch_unchanged(batch, before)


def check_edge_only_mask(statistics):
    batch = make_batch(statistics, include_a=True)
    before = snapshot_batch(batch)
    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.0,
        edge_mask_ratio=0.34,
        negative_edge_ratio=0.0,
        generator=seeded_generator(22),
        min_mask_nodes=0,
        min_mask_edges=1,
    )
    assert_plan_protocol(batch, plan)
    assert plan.masked_node_indices.numel() == 0
    assert plan.masked_physical_edge_indices.numel() == 1
    masked_physical = int(plan.masked_physical_edge_indices.item())
    assert torch.equal(
        plan.masked_message_edge_indices,
        torch.tensor([2 * masked_physical, 2 * masked_physical + 1]),
    )

    student = build_masked_brep_student_input(batch, plan)
    assert student.message_graph.num_nodes() == 4
    assert student.message_graph.num_edges() == 4
    assert torch.equal(
        student.message_graph.batch_num_nodes(),
        torch.tensor([4]),
    )
    assert torch.equal(
        student.message_graph.batch_num_edges(),
        torch.tensor([4]),
    )
    assert torch.equal(
        student.kept_original_message_indices,
        plan.kept_message_edge_indices,
    )
    assert not torch.any(
        student.message_to_physical_edge == masked_physical
    )
    expected_kept_mapping = before["message_to_physical_edge"].index_select(
        0,
        plan.kept_message_edge_indices,
    )
    assert torch.equal(
        student.message_to_physical_edge,
        expected_kept_mapping,
    )
    torch.testing.assert_close(student.node_attr, before["node_attr"])
    torch.testing.assert_close(student.node_grid, before["node_grid"])
    torch.testing.assert_close(
        student.message_edge_attr,
        before["message_edge_attr"].index_select(
            0,
            plan.kept_message_edge_indices,
        ),
    )
    torch.testing.assert_close(
        student.message_edge_grid,
        before["message_edge_grid"].index_select(
            0,
            plan.kept_message_edge_indices,
        ),
    )
    assert_batch_unchanged(batch, before)


def check_seam_masks(statistics):
    node_batch = make_batch(
        statistics,
        include_a=False,
        include_b=True,
    )
    node_plan = sample_brep_pretrain_mask_plan(
        node_batch,
        node_mask_ratio=1.0,
        edge_mask_ratio=0.0,
        negative_edge_ratio=0.0,
        generator=seeded_generator(33),
        min_mask_nodes=1,
        min_mask_edges=0,
    )
    assert node_plan.masked_node_indices.numel() == 2
    assert node_plan.masked_physical_edge_indices.numel() == 0
    assert torch.all(node_plan.message_source_side_node_mask)
    assert torch.all(node_plan.message_destination_side_node_mask)
    node_student = build_masked_brep_student_input(node_batch, node_plan)
    assert node_student.message_graph.num_edges() == 2
    seam_src, seam_dst = node_student.message_graph.edges(order="eid")
    assert torch.equal(seam_src, torch.tensor([0, 0]))
    assert torch.equal(seam_dst, torch.tensor([0, 0]))
    assert torch.all(node_student.message_edge_grid[:, 6:12] == 0)
    assert torch.all(node_student.message_edge_grid[:, 14:16] == 0)
    assert torch.all(node_student.message_edge_face_uv == 0)
    assert not torch.any(node_student.message_edge_face_uv_valid)
    assert torch.all(node_student.message_edge_attr[:, 0:3] == 0)
    assert torch.all(node_student.message_edge_grid[:, 13] == 0)
    original = node_batch.model_input.message_view
    torch.testing.assert_close(
        node_student.message_edge_attr[:, 3:16],
        original.message_edge_attr[:, 3:16],
    )
    torch.testing.assert_close(
        node_student.message_edge_grid[:, 0:6],
        original.message_edge_grid[:, 0:6],
    )
    torch.testing.assert_close(
        node_student.message_edge_grid[:, 12],
        original.message_edge_grid[:, 12],
    )

    edge_batch = make_batch(
        statistics,
        include_a=False,
        include_b=True,
    )
    edge_plan = sample_brep_pretrain_mask_plan(
        edge_batch,
        node_mask_ratio=0.0,
        edge_mask_ratio=1.0,
        negative_edge_ratio=0.0,
        generator=seeded_generator(44),
        min_mask_nodes=0,
        min_mask_edges=1,
    )
    assert torch.equal(
        edge_plan.message_edge_mask,
        torch.tensor([False, False]),
    )
    assert edge_plan.num_candidate_physical_edges == 0
    assert edge_plan.masked_physical_edge_indices.numel() == 0
    edge_student = build_masked_brep_student_input(edge_batch, edge_plan)
    assert edge_student.message_graph.num_edges() == 2
    assert torch.equal(
        edge_student.message_graph.batch_num_edges(),
        torch.tensor([2]),
    )
    assert edge_student.message_edge_attr.shape == (2, 16)
    assert edge_student.message_edge_grid.shape == (2, 16, 5)


def check_batched_graph(statistics):
    batch = make_batch(
        statistics,
        include_a=True,
        include_b=True,
    )
    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.5,
        negative_edge_ratio=1.0,
        generator=seeded_generator(55),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    assert_plan_protocol(batch, plan)
    assert plan.num_graphs == 2
    assert torch.equal(plan.physical_batch_num_nodes, torch.tensor([4, 2]))
    assert torch.equal(plan.physical_batch_num_edges, torch.tensor([3, 1]))
    assert set(plan.masked_node_graph_ids.tolist()) == {0, 1}
    assert set(plan.masked_physical_edge_graph_ids.tolist()) == {0}

    node_graph_ids = torch.repeat_interleave(
        torch.arange(2),
        torch.tensor([4, 2]),
    )
    if plan.negative_edge_src.numel():
        assert torch.equal(
            node_graph_ids[plan.negative_edge_src],
            plan.negative_edge_graph_ids,
        )
        assert torch.equal(
            node_graph_ids[plan.negative_edge_dst],
            plan.negative_edge_graph_ids,
        )
    assert torch.equal(
        node_graph_ids[plan.positive_edge_src],
        plan.positive_edge_graph_ids,
    )
    assert torch.equal(
        node_graph_ids[plan.positive_edge_dst],
        plan.positive_edge_graph_ids,
    )

    student = build_masked_brep_student_input(batch, plan)
    masked_per_graph = torch.bincount(
        plan.masked_physical_edge_graph_ids,
        minlength=2,
    )
    expected_message_counts = (
        torch.tensor([6, 2]) - 2 * masked_per_graph
    )
    assert torch.equal(
        student.message_graph.batch_num_edges(),
        expected_message_counts,
    )
    assert torch.equal(
        student.message_graph.batch_num_nodes(),
        torch.tensor([4, 2]),
    )
    student_src, student_dst = student.message_graph.edges(order="eid")
    assert torch.equal(node_graph_ids[student_src], node_graph_ids[student_dst])
    for field in fields(BRepPretrainMaskPlan):
        value = getattr(plan, field.name)
        if isinstance(value, torch.Tensor):
            assert value.device == batch.physical_topology_graph.device
    for field in fields(BRepMaskedStudentInput):
        value = getattr(student, field.name)
        if isinstance(value, torch.Tensor):
            assert value.device == batch.physical_topology_graph.device
    assert student.message_graph.device == batch.physical_topology_graph.device


def check_parallel_seam_eligibility(statistics):
    graph = make_graph_parallel_seam()
    batch = collate_brep_pretrain_model_input(
        [BRepPretrainModelInputSample("parallel_seam", graph)],
        statistics=statistics,
    )
    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.0,
        edge_mask_ratio=1.0,
        negative_edge_ratio=1.0,
        generator=seeded_generator(77),
        min_mask_nodes=0,
        min_mask_edges=1,
    )
    expected_eligible = torch.tensor([False, False, True, False])
    assert torch.equal(plan.eligible_physical_edge_mask, expected_eligible)
    assert torch.equal(
        plan.eligible_physical_edge_indices,
        torch.tensor([2]),
    )
    assert plan.num_candidate_physical_edges == 1
    assert plan.physical_num_edges == 4
    assert torch.equal(
        plan.masked_physical_edge_indices,
        torch.tensor([2]),
    )
    assert torch.equal(
        plan.positive_physical_edge_ids,
        torch.tensor([2]),
    )
    assert torch.equal(plan.positive_edge_src, torch.tensor([1]))
    assert torch.equal(plan.positive_edge_dst, torch.tensor([2]))
    assert not plan.physical_edge_mask[0]
    assert not plan.physical_edge_mask[1]
    assert not plan.physical_edge_mask[3]

    existing_pairs = {(0, 1), (1, 2)}
    for src, dst in zip(
        plan.negative_edge_src.tolist(),
        plan.negative_edge_dst.tolist(),
    ):
        pair = (min(src, dst), max(src, dst))
        assert pair not in existing_pairs
        assert src != dst

    student = build_masked_brep_student_input(batch, plan)
    assert student.message_graph.num_edges() == 6
    assert torch.equal(
        student.message_to_physical_edge,
        torch.tensor([0, 0, 1, 1, 3, 3]),
    )
    assert torch.equal(
        student.message_is_self_loop,
        torch.tensor([False, False, False, False, True, True]),
    )

    signature = compute_brep_pretrain_batch_signature(batch)
    assert signature == plan.batch_signature
    assert len(signature) == 64
    different_part_batch = replace(
        batch,
        part_ids=("same_size_different_part",),
    )
    expect_error(
        ValueError,
        lambda: build_masked_brep_student_input(
            different_part_batch,
            plan,
        ),
    )

    reordered_batch = collate_brep_pretrain_model_input(
        [BRepPretrainModelInputSample("parallel_seam", make_graph_a_reordered())],
        statistics=statistics,
    )
    same_shape_batch = make_batch(statistics, include_a=True)
    same_shape_plan = sample_brep_pretrain_mask_plan(
        same_shape_batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.34,
        negative_edge_ratio=0.0,
        generator=seeded_generator(78),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    reordered_same_part = replace(
        reordered_batch,
        part_ids=("part_a",),
    )
    expect_error(
        ValueError,
        lambda: build_masked_brep_student_input(
            reordered_same_part,
            same_shape_plan,
        ),
    )


def check_error_inputs(statistics):
    batch = make_batch(statistics, include_a=True)
    plan = sample_brep_pretrain_mask_plan(
        batch,
        node_mask_ratio=0.25,
        edge_mask_ratio=0.34,
        negative_edge_ratio=0.0,
        generator=seeded_generator(66),
        min_mask_nodes=1,
        min_mask_edges=1,
    )
    expect_error(
        TypeError,
        lambda: sample_brep_pretrain_mask_plan(
            object(),
            node_mask_ratio=0.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
        ),
    )
    expect_error(
        TypeError,
        lambda: build_masked_brep_student_input(batch, object()),
    )
    expect_error(
        ValueError,
        lambda: sample_brep_pretrain_mask_plan(
            batch,
            node_mask_ratio=1.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
        ),
    )
    expect_error(
        TypeError,
        lambda: sample_brep_pretrain_mask_plan(
            batch,
            node_mask_ratio=0.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
            generator="seed",
        ),
    )

    expect_error(
        TypeError,
        lambda: build_masked_brep_student_input(
            batch,
            replace(plan, node_mask=plan.node_mask.to(torch.float32)),
        ),
    )
    expect_error(
        ValueError,
        lambda: build_masked_brep_student_input(
            batch,
            replace(
                plan,
                physical_edge_mask=plan.physical_edge_mask[:-1],
            ),
        ),
    )

    message_view = batch.model_input.message_view
    bad_mapping = message_view.message_to_physical_edge.clone()
    bad_mapping[0] = (bad_mapping[0] + 1) % batch.model_input.physical_num_edges
    bad_message_view = replace(
        message_view,
        message_to_physical_edge=bad_mapping,
    )
    bad_mapping_batch = replace(
        batch,
        model_input=replace(
            batch.model_input,
            message_view=bad_message_view,
        ),
    )
    expect_error(
        ValueError,
        lambda: sample_brep_pretrain_mask_plan(
            bad_mapping_batch,
            node_mask_ratio=0.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
        ),
    )

    full_src, full_dst = message_view.message_graph.edges(order="eid")
    short_message_graph = dgl.graph(
        (full_src[:-1], full_dst[:-1]),
        num_nodes=message_view.message_graph.num_nodes(),
    )
    short_message_graph.set_batch_num_nodes(torch.tensor([4]))
    short_message_graph.set_batch_num_edges(torch.tensor([5]))
    short_batch = replace(
        batch,
        model_input=replace(
            batch.model_input,
            message_view=replace(
                message_view,
                message_graph=short_message_graph,
            ),
        ),
    )
    expect_error(
        ValueError,
        lambda: sample_brep_pretrain_mask_plan(
            short_batch,
            node_mask_ratio=0.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
        ),
    )

    seam_batch = make_batch(
        statistics,
        include_a=False,
        include_b=True,
    )
    expect_error(
        ValueError,
        lambda: build_masked_brep_student_input(seam_batch, plan),
    )
    expect_error(
        ValueError,
        lambda: build_masked_brep_student_input(
            batch,
            replace(
                plan,
                masked_node_indices=torch.tensor(
                    [batch.model_input.physical_num_nodes],
                    dtype=torch.int64,
                ),
            ),
        ),
    )
    duplicate_index = int(plan.masked_node_indices[0].item())
    expect_error(
        ValueError,
        lambda: build_masked_brep_student_input(
            batch,
            replace(
                plan,
                masked_node_indices=torch.tensor(
                    [duplicate_index, duplicate_index],
                    dtype=torch.int64,
                ),
            ),
        ),
    )

    invalid_uv = message_view.message_edge_face_uv.clone()
    invalid_position = ~message_view.message_edge_face_uv_valid
    invalid_uv[invalid_position][0] = torch.tensor([0.2, -0.2])
    first_invalid = torch.nonzero(
        invalid_position,
        as_tuple=False,
    )[0]
    invalid_uv[
        first_invalid[0],
        first_invalid[1],
        first_invalid[2],
    ] = torch.tensor([0.2, -0.2])
    uv_batch = replace(
        batch,
        model_input=replace(
            batch.model_input,
            message_view=replace(
                message_view,
                message_edge_face_uv=invalid_uv,
            ),
        ),
    )
    expect_error(
        ValueError,
        lambda: sample_brep_pretrain_mask_plan(
            uv_batch,
            node_mask_ratio=0.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
        ),
    )

    nan_node_attr = batch.model_input.node_attr.clone()
    nan_node_attr[0, 0] = float("nan")
    nan_batch = replace(
        batch,
        model_input=replace(
            batch.model_input,
            node_attr=nan_node_attr,
        ),
    )
    expect_error(
        ValueError,
        lambda: sample_brep_pretrain_mask_plan(
            nan_batch,
            node_mask_ratio=0.1,
            edge_mask_ratio=0.1,
            negative_edge_ratio=0.0,
        ),
    )


def main():
    statistics = make_statistics()
    check_node_only_mask(statistics)
    check_edge_only_mask(statistics)
    check_seam_masks(statistics)
    check_batched_graph(statistics)
    check_parallel_seam_eligibility(statistics)
    check_error_inputs(statistics)
    print("BREP_GRAPH_PRETRAIN_INPUT_MASKING_CHECK_PASS")
    print("node_only_mask=PASS physical_edge_only_mask=PASS")
    print("parallel_and_seam_eligibility=PASS batched_graph=PASS")
    print("input_immutability=PASS strict_error_checks=PASS")


if __name__ == "__main__":
    main()
