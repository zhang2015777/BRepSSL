

from dataclasses import replace
from pathlib import Path
import sys
import tempfile

import dgl
import torch
from torch import nn


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.brep_pretrain import BRepPretrainModelInputSample
from dataloader.mfinstseg_physical_message import (
    BRepSupervisedModelInputSample,
    collate_mfinstseg_physical_message,
)
from dataset.quality_export.check_brep_graph_pretrain_model_input_loader import (
    attach_raw_features,
    make_statistics,
)
from dataset.quality_export.check_mfinstseg_physical_message_loader import (
    make_supervised_samples,
)
from models.brep_physical_message_backbone import (
    BRepPhysicalMessageBackbone,
)
from models.brep_physical_message_quality_segmentor import (
    BRepPhysicalMessageQualitySegmentor,
)
from utils.brep_model_input_view import resolve_brep_model_input_statistics


def expect_error(error_type, callback):
    try:
        callback()
    except error_type:
        return
    raise AssertionError(f"Expected {error_type.__name__}")


def clone_input_state(batch):
    view = batch.model_input.message_view
    message_src, message_dst = view.message_graph.edges(order="eid")
    topology_src, topology_dst = batch.physical_topology_graph.edges(
        order="eid"
    )
    return {
        "node_attr": batch.model_input.node_attr.clone(),
        "node_grid": batch.model_input.node_grid.clone(),
        "edge_attr": view.message_edge_attr.clone(),
        "edge_grid": view.message_edge_grid.clone(),
        "face_uv": view.message_edge_face_uv.clone(),
        "valid": view.message_edge_face_uv_valid.clone(),
        "message_src": message_src.clone(),
        "message_dst": message_dst.clone(),
        "topology_src": topology_src.clone(),
        "topology_dst": topology_dst.clone(),
    }


def assert_input_unchanged(batch, before):
    view = batch.model_input.message_view
    message_src, message_dst = view.message_graph.edges(order="eid")
    topology_src, topology_dst = batch.physical_topology_graph.edges(
        order="eid"
    )
    pairs = (
        (batch.model_input.node_attr, before["node_attr"]),
        (batch.model_input.node_grid, before["node_grid"]),
        (view.message_edge_attr, before["edge_attr"]),
        (view.message_edge_grid, before["edge_grid"]),
        (view.message_edge_face_uv, before["face_uv"]),
        (view.message_edge_face_uv_valid, before["valid"]),
        (message_src, before["message_src"]),
        (message_dst, before["message_dst"]),
        (topology_src, before["topology_src"]),
        (topology_dst, before["topology_dst"]),
    )
    for actual, expected in pairs:
        assert torch.equal(actual, expected)
    assert len(view.message_graph.ndata) == 0
    assert len(view.message_graph.edata) == 0
    assert len(batch.physical_topology_graph.ndata) == 0
    assert len(batch.physical_topology_graph.edata) == 0


def make_batch():
    attr_stat, uv_stat = make_statistics()
    statistics = resolve_brep_model_input_statistics(attr_stat, uv_stat)
    sample_a, sample_b = make_supervised_samples()
    return collate_mfinstseg_physical_message(
        [sample_a, sample_b],
        statistics=statistics,
    ), statistics


def make_zero_message_batch(statistics):
    graph = attach_raw_features(
        dgl.graph(
            (
                torch.empty(0, dtype=torch.int64),
                torch.empty(0, dtype=torch.int64),
            ),
            num_nodes=1,
        ),
        2000.0,
    )
    sample = BRepSupervisedModelInputSample(
        part_id="isolated",
        geometry_sample=BRepPretrainModelInputSample("isolated", graph),
        seg_y=torch.tensor([0], dtype=torch.int64),
        inst_y=torch.ones(1, 1, dtype=torch.float32),
        quality=torch.tensor([[0.0, 0.0]], dtype=torch.float32),
        process_y=torch.tensor([-1], dtype=torch.int64),
    )
    return collate_mfinstseg_physical_message(
        [sample],
        statistics=statistics,
    )


def finite_backbone_gradients(model):
    gradients = [
        parameter.grad
        for parameter in model.backbone.parameters()
        if parameter.requires_grad and parameter.grad is not None
    ]
    assert gradients
    assert all(torch.all(torch.isfinite(value)) for value in gradients)


def main():
    torch.manual_seed(1234)
    batch, statistics = make_batch()
    before = clone_input_state(batch)
    model = BRepPhysicalMessageQualitySegmentor(num_classes=13)
    model.eval()

    backbone_instances = [
        module
        for module in model.modules()
        if isinstance(module, BRepPhysicalMessageBackbone)
    ]
    assert backbone_instances == [model.backbone]
    expected_batch_norms = {
        id(layer.edge_mpnn.norm_drop[0])
        for layer in model.backbone.iba_dmp.layers
    }
    actual_batch_norms = {
        id(module)
        for module in model.modules()
        if isinstance(module, nn.BatchNorm1d)
    }
    assert actual_batch_norms == expected_batch_norms
    assert not any(isinstance(module, nn.BatchNorm2d) for module in model.modules())

    full_calls = []
    student_calls = []
    original_full = model.backbone.forward_full
    original_student = model.backbone.forward_student

    def tracked_full(model_input):
        full_calls.append(True)
        return original_full(model_input)

    def tracked_student(*args, **kwargs):
        student_calls.append(True)
        return original_student(*args, **kwargs)

    model.backbone.forward_full = tracked_full
    model.backbone.forward_student = tracked_student
    with torch.no_grad():
        output_1 = model(batch)
        output_2 = model(batch)
    assert len(full_calls) == 2
    assert not student_calls
    seg_out, inst_out, process_out = output_1
    assert seg_out.shape == (5, 13)
    assert inst_out.shape == (2, 3, 3)
    assert process_out.shape == (5, 2)
    for first, second in zip(output_1, output_2):
        torch.testing.assert_close(first, second, rtol=0.0, atol=1e-7)
    assert_input_unchanged(batch, before)

    changed_geometry = replace(
        batch,
        model_input=replace(
            batch.model_input,
            node_attr=batch.model_input.node_attr + 0.75,
        ),
    )
    with torch.no_grad():
        changed_geometry_out = model(changed_geometry)
    torch.testing.assert_close(
        changed_geometry_out[2],
        process_out,
        rtol=0.0,
        atol=0.0,
    )

    changed_quality = replace(batch, quality=batch.quality + 1.25)
    with torch.no_grad():
        changed_quality_out = model(changed_quality)
    torch.testing.assert_close(
        changed_quality_out[0],
        seg_out,
        rtol=0.0,
        atol=0.0,
    )
    torch.testing.assert_close(
        changed_quality_out[1],
        inst_out,
        rtol=0.0,
        atol=0.0,
    )

    changed_labels = replace(
        batch,
        seg_y=torch.flip(batch.seg_y, dims=(0,)),
        inst_labels=torch.zeros_like(batch.inst_labels),
        inst_masks=torch.zeros_like(batch.inst_masks),
        process_y=torch.flip(batch.process_y, dims=(0,)),
    )
    with torch.no_grad():
        changed_label_out = model(changed_labels)
    for expected, actual in zip(output_1, changed_label_out):
        torch.testing.assert_close(actual, expected, rtol=0.0, atol=0.0)

    model.backbone.forward_full = original_full
    model.backbone.forward_student = original_student
    model.train()
    model.zero_grad(set_to_none=True)
    process_only = model(batch)[2].sum()
    process_only.backward()
    assert all(
        parameter.grad is None
        for parameter in model.backbone.parameters()
    )
    assert any(
        parameter.grad is not None
        for parameter in model.process_head.parameters()
    )

    model.zero_grad(set_to_none=True)
    semantic_only = model(batch)[0].square().mean()
    semantic_only.backward()
    finite_backbone_gradients(model)

    model.zero_grad(set_to_none=True)
    instance_only = model(batch)[1].square().mean()
    instance_only.backward()
    finite_backbone_gradients(model)

    all_params = list(model.parameters())
    backbone_params = list(model.backbone_parameters())
    non_backbone_params = list(model.non_backbone_parameters())
    assert not ({id(value) for value in backbone_params} & {
        id(value) for value in non_backbone_params
    })
    assert {id(value) for value in all_params} == {
        id(value) for value in backbone_params + non_backbone_params
    }
    model.freeze_backbone()
    assert not model.backbone.training
    assert all(
        not parameter.requires_grad for parameter in model.backbone.parameters()
    )
    assert any(
        parameter.requires_grad
        for parameter in model.non_backbone_parameters()
    )
    model.unfreeze_backbone()
    assert model.backbone.training
    assert all(
        parameter.requires_grad for parameter in model.backbone.parameters()
    )
    assert model.count_trainable_parameters() == model.count_total_parameters()

    model.eval()
    with tempfile.TemporaryDirectory() as directory:
        checkpoint = Path(directory) / "backbone.pt"
        model.backbone.save_backbone(checkpoint)
        restored = BRepPhysicalMessageQualitySegmentor(num_classes=13)
        restored.load_pretrained_backbone(checkpoint, strict=True)
        restored.eval()
        with torch.no_grad():
            expected = model.backbone.forward_full(batch.model_input)
            actual = restored.backbone.forward_full(batch.model_input)
        for name in (
            "node_emb",
            "graph_emb",
            "local_global_feat",
            "message_edge_emb",
            "route_gate",
        ):
            torch.testing.assert_close(
                getattr(actual, name),
                getattr(expected, name),
                rtol=0.0,
                atol=1e-7,
            )

        legacy = Path(directory) / "legacy.pt"
        torch.save(model.backbone.state_dict(), legacy)
        expect_error(
            ValueError,
            lambda: restored.load_pretrained_backbone(
                legacy,
                strict=False,
            ),
        )

    zero_batch = make_zero_message_batch(statistics)
    with torch.no_grad():
        zero_outputs = model(zero_batch)
    assert zero_outputs[0].shape == (1, 13)
    assert zero_outputs[1].shape == (1, 1, 1)
    assert zero_outputs[2].shape == (1, 2)
    assert all(torch.all(torch.isfinite(value)) for value in zero_outputs)
    assert_input_unchanged(batch, before)
    print("BREP_GRAPH_PHYSICAL_MESSAGE_QUALITY_SEGMENTOR_CHECK_PASS")


if __name__ == "__main__":
    main()
