

import sys
from pathlib import Path

import dgl
import torch
from torch import nn


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.damped_diffusion import DampedHeatDiffusionGraphPropagation


class RecordingDiffusion(DampedHeatDiffusionGraphPropagation):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.propagation_counts = []

    def _compute_diffusion(self, h, src, dst, edge_weight):
        self.propagation_counts.append(int(src.numel()))
        return super()._compute_diffusion(h, src, dst, edge_weight)


def expect_error(expected_type, callback):
    try:
        callback()
    except expected_type:
        return
    raise AssertionError(f"Expected {expected_type.__name__}")


def main():
    torch.manual_seed(401)
    physical_graph = dgl.graph(([0], [1]), num_nodes=2)
    directed_graph = dgl.graph(([0, 1], [1, 0]), num_nodes=2)
    node_feat = torch.linspace(-1.0, 1.0, 256).reshape(2, 128)
    physical_edge_feat = torch.linspace(-0.5, 0.5, 128).reshape(1, 128)
    directed_edge_feat = physical_edge_feat.repeat(2, 1)

    legacy = RecordingDiffusion(
        feat_dim=128,
        edge_dim=128,
        steps=2,
        drop=0.0,
        edge_direction_mode="legacy_physical_edges",
    )
    directed = RecordingDiffusion(
        feat_dim=128,
        edge_dim=128,
        steps=2,
        drop=0.0,
        edge_direction_mode="directed_messages",
    )
    directed.load_state_dict(legacy.state_dict())
    legacy.eval()
    directed.eval()
    node_before = node_feat.clone()
    physical_edge_before = physical_edge_feat.clone()
    directed_edge_before = directed_edge_feat.clone()
    legacy_output = legacy(physical_graph, node_feat, physical_edge_feat)
    directed_output = directed(
        directed_graph,
        node_feat,
        directed_edge_feat,
    )
    torch.testing.assert_close(
        legacy_output,
        directed_output,
        rtol=0.0,
        atol=1e-7,
    )
    assert legacy.propagation_counts == [2, 2]
    assert directed.propagation_counts == [2, 2]
    assert torch.equal(node_feat, node_before)
    assert torch.equal(physical_edge_feat, physical_edge_before)
    assert torch.equal(directed_edge_feat, directed_edge_before)

    multi_in_graph = dgl.graph(([0, 1, 2], [2, 2, 0]), num_nodes=3)
    multi_node = torch.arange(384, dtype=torch.float32).reshape(3, 128) / 50
    edge_axis = torch.linspace(-2.0, 2.0, 128)
    asymmetric_edge = torch.stack(
        (
            edge_axis,
            torch.sin(edge_axis * 2.3) + 0.2 * edge_axis,
            torch.cos(edge_axis * 1.7) - 0.1 * edge_axis,
        ),
        dim=0,
    )
    directional_model = DampedHeatDiffusionGraphPropagation(
        feat_dim=128,
        edge_dim=128,
        steps=2,
        drop=0.0,
        edge_direction_mode="directed_messages",
    )
    directional_model.eval()
    asymmetric_output = directional_model(
        multi_in_graph,
        multi_node,
        asymmetric_edge,
    )
    swapped_edge = asymmetric_edge.clone()
    swapped_edge[[0, 1]] = swapped_edge[[1, 0]]
    swapped_output = directional_model(
        multi_in_graph,
        multi_node,
        swapped_edge,
    )
    assert not torch.allclose(asymmetric_output, swapped_output)

    no_edge_graph = dgl.graph(
        (
            torch.empty(0, dtype=torch.int64),
            torch.empty(0, dtype=torch.int64),
        ),
        num_nodes=2,
    )
    no_edge_output = directional_model(
        no_edge_graph,
        node_feat,
        torch.empty(0, 128),
    )
    assert no_edge_output.shape == (2, 128)
    assert torch.all(torch.isfinite(no_edge_output))

    seam_graph = dgl.graph(([0], [0]), num_nodes=1)
    seam_output = directional_model(
        seam_graph,
        node_feat[:1],
        physical_edge_feat,
    )
    assert seam_output.shape == (1, 128)
    assert torch.all(torch.isfinite(seam_output))
    assert not any(
        isinstance(module, nn.modules.batchnorm._BatchNorm)
        for module in directional_model.modules()
    )

    first = directional_model(
        multi_in_graph,
        multi_node,
        asymmetric_edge,
    )
    second = directional_model(
        multi_in_graph,
        multi_node,
        asymmetric_edge,
    )
    torch.testing.assert_close(first, second, rtol=0.0, atol=1e-7)
    expect_error(
        ValueError,
        lambda: DampedHeatDiffusionGraphPropagation(
            edge_direction_mode="automatic"
        ),
    )
    print("DAMPED_DIFFUSION_DIRECTION_CHECK_PASS")
    print("legacy_physical_edge_messages=2 directed_messages=2")
    print("directed_messages_not_expanded_to_four=PASS")
    print("zero_edge_seam_directional_determinism=PASS")


if __name__ == "__main__":
    main()
