

from __future__ import annotations

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def source(path):
    return (PROJECT_ROOT / path).read_text(encoding="utf-8")


def main():
    stream_text = source("utils/graph_json_stream.py")
    assert 'separators=(",", ":")' in stream_text
    assert "allow_nan=False" in stream_text
    assert "records = list(" not in stream_text
    assert "iter_graph_records" in stream_text

    loader_text = source("dataloader/brep_pretrain.py")
    assert "class BRepCompactGraphStore" in loader_text
    assert loader_text.count("self._sample_by_id = {}") == 1
    assert "iter_graph_records(self.graphs_path)" in loader_text
    assert "json.load(" not in loader_text
    assert "graph_store.ensure_loaded(self.part_ids)" in loader_text
    assert "self.data = list(graph_store.get_samples(self.part_ids))" in loader_text
    assert "def pin_memory(self):" in loader_text
    assert "pin_brep_model_input_view" in loader_text
    assert "graph_construction_count" in loader_text
    store_section = loader_text[
        loader_text.index("class BRepCompactGraphStore") :
        loader_text.index("class BRepPretrainDataset")
    ]
    for token in (
        "message_view =",
        "model_input =",
        "mask_plan =",
        "target_embedding",
        "predictions",
    ):
        assert token not in store_section

    model_input_text = source("utils/brep_model_input_view.py")
    assert "build_physical_edge_message_view(" in model_input_text
    assert "def pin_brep_model_input_view" in model_input_text
    assert "physical_graph_is_standardized=False" in loader_text

    data_io_text = source("utils/brep_data_io.py")
    assert 'dtype=np.float32, order="C"' in data_io_text
    assert 'dtype=np.bool_, order="C"' in data_io_text
    assert 'dtype=np.int64, order="C"' in data_io_text
    assert "torch.from_numpy" in data_io_text

    pretrain_text = source("engine/pretrain_brep_mask.py")
    assert pretrain_text.count("BRepCompactGraphStore(") == 1
    assert "graph_store.ensure_loaded(train_ids + eval_ids)" in pretrain_text
    assert pretrain_text.count("graph_store=graph_store") >= 2
    assert "test_ids" in pretrain_text
    assert "graph_store.ensure_loaded(test_ids)" not in pretrain_text
    assert "non_blocking=True" in pretrain_text
    assert "pin_memory=bool(args.pin_memory and device.type == \"cuda\")" in pretrain_text
    assert "torch.autocast(" in pretrain_text
    assert "GradScaler(enabled=args.amp)" in pretrain_text
    assert "torch.cuda.reset_peak_memory_stats" in pretrain_text
    assert "torch.cuda.max_memory_allocated" in pretrain_text
    assert "torch.cuda.max_memory_reserved" in pretrain_text
    assert "metric_lists[key].append" not in pretrain_text
    assert "all_outputs.append" not in pretrain_text
    assert "all_predictions.append" not in pretrain_text
    assert "all_losses.append" not in pretrain_text

    finetune_text = source("engine/inst_trainer.py")
    assert finetune_text.count("BRepCompactGraphStore(") == 1
    assert "graph_store.ensure_loaded(train_ids + eval_ids)" in finetune_text
    assert "graph_store.ensure_loaded(test_ids)" in finetune_text
    assert finetune_text.count("graph_store=graph_store") >= 3
    assert not any(
        token in finetune_text
        for token in ("train_store", "eval_store", "test_store")
    )
    assert "non_blocking=True" in finetune_text
    assert "pin_memory=pin_memory" in finetune_text
    assert "torch.cuda.amp.autocast(enabled=args.amp)" in finetune_text
    assert "GradScaler(enabled=args.amp)" in finetune_text
    assert "torch.cuda.reset_peak_memory_stats" in finetune_text
    assert "torch.cuda.max_memory_allocated" in finetune_text
    assert "torch.cuda.max_memory_reserved" in finetune_text
    for token in (
        "train_losses = []",
        "total_losses = []",
        "all_outputs.append",
        "all_predictions.append",
        "all_losses.append",
        "graph_store.to(",
        ".graph_store.to(",
    ):
        assert token not in finetune_text

    supervised_text = source("dataloader/mfinstseg_physical_message.py")
    assert "geometry_sample=geometry_sample" in supervised_text
    assert "copy.deepcopy(geometry_sample)" not in supervised_text
    assert "geometry_sample.physical_graph.clone()" not in supervised_text
    assert "def pin_memory(self):" in supervised_text

    assert not (PROJECT_ROOT / "environment.yaml").exists()
    forbidden_cache_outputs = (
        "train_graphs.pkl",
        "eval_graphs.pkl",
        "test_graphs.pkl",
        "graphs.pt",
        "graphs.bin",
    )
    formal_sources = "\n".join(
        source(path)
        for path in (
            "dataloader/brep_pretrain.py",
            "engine/pretrain_brep_mask.py",
            "engine/inst_trainer.py",
        )
    )
    for token in forbidden_cache_outputs:
        assert token not in formal_sources

    print("MEMORY_SAFE_GRAPH_RUNTIME_CHECK_PASS")


if __name__ == "__main__":
    main()
