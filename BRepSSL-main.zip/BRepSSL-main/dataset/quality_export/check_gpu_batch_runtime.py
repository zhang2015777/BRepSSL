

from __future__ import annotations

import sys
from pathlib import Path

import torch
from torch import nn


PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dataloader.mfinstseg_physical_message import (
    move_brep_supervised_model_input_batch,
)
from dataset.quality_export.check_brep_graph_physical_message_quality_segmentor import (
    make_batch as make_supervised_batch,
)
from dataset.quality_export.check_brep_graph_physical_message_pretrainer import (
    make_batch as make_pretrain_batch,
    make_statistics,
)
from models.brep_physical_message_pretrainer import (
    BRepPhysicalMessageMaskedPretrainer,
)
from models.brep_physical_message_quality_segmentor import (
    BRepPhysicalMessageQualitySegmentor,
)


def source(path):
    return (PROJECT_ROOT / path).read_text(encoding="utf-8")


def cuda_build_can_run_current_device():
    if not torch.cuda.is_available():
        return False
    major, minor = torch.cuda.get_device_capability(0)
    current_arch = f"sm_{major}{minor}"
    return current_arch in set(torch.cuda.get_arch_list())


def static_protocol_checks():
    pretrain = source("engine/pretrain_brep_mask.py")
    finetune = source("engine/inst_trainer.py")
    pretrain_loader = source("dataloader/brep_pretrain.py")
    supervised_loader = source("dataloader/mfinstseg_physical_message.py")
    config = source("configs/main_experiment_config.py")

    assert "pin_memory=bool(args.pin_memory and device.type == \"cuda\")" in pretrain
    assert "pin_memory=pin_memory" in finetune
    assert "non_blocking=True" in pretrain
    assert "non_blocking=True" in finetune
    assert "def pin_memory(self):" in pretrain_loader
    assert "def pin_memory(self):" in supervised_loader
    assert "torch.autocast(" in pretrain
    assert "torch.cuda.amp.autocast(enabled=args.amp)" in finetune
    assert "GradScaler(enabled=args.amp)" in pretrain
    assert "GradScaler(enabled=args.amp)" in finetune
    assert "torch.cuda.reset_peak_memory_stats" in pretrain
    assert "torch.cuda.max_memory_allocated" in pretrain
    assert "torch.cuda.max_memory_reserved" in pretrain
    assert "torch.cuda.reset_peak_memory_stats" in finetune
    assert "torch.cuda.max_memory_allocated" in finetune
    assert "torch.cuda.max_memory_reserved" in finetune
    assert '"pin_memory": True' in config
    assert "AMP_ENABLED = True" in config
    assert ".graph_store.to(" not in pretrain + finetune


def dynamic_cuda_checks():
    device = torch.device("cuda:0")
    supervised_batch, _ = make_supervised_batch()
    moved = move_brep_supervised_model_input_batch(
        supervised_batch,
        device,
        non_blocking=True,
    )
    assert supervised_batch.model_input.node_attr.device.type == "cpu"
    assert moved.physical_topology_graph.device == device
    assert moved.model_input.message_view.message_graph.device == device
    for value in (
        moved.model_input.node_attr,
        moved.model_input.node_grid,
        moved.model_input.message_view.message_edge_attr,
        moved.model_input.message_view.message_edge_grid,
        moved.model_input.message_view.message_edge_face_uv,
        moved.model_input.message_view.message_edge_face_uv_valid,
        moved.seg_y,
        moved.inst_labels,
        moved.inst_masks,
        moved.quality,
        moved.process_y,
    ):
        assert value.device == device

    model = BRepPhysicalMessageQualitySegmentor(num_classes=13).to(device)
    torch.cuda.reset_peak_memory_stats(0)
    with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
        seg_pred, inst_pred, process_pred = model(moved)
        seg_loss = nn.CrossEntropyLoss()(seg_pred, moved.seg_y)
        inst_values = nn.BCEWithLogitsLoss(reduction="none")(
            inst_pred,
            moved.inst_labels,
        )
        inst_loss = (
            inst_values * moved.inst_masks
        ).sum() / moved.inst_masks.sum().clamp_min(1.0)
        process_loss = nn.CrossEntropyLoss(ignore_index=-1)(
            process_pred,
            moved.process_y,
        )
        loss = seg_loss + inst_loss + process_loss
    assert loss.device == device and torch.isfinite(loss)
    loss.backward()
    assert any(
        parameter.grad is not None
        for parameter in model.backbone.parameters()
        if parameter.requires_grad
    )
    assert torch.cuda.max_memory_allocated(0) > 0
    assert torch.cuda.max_memory_reserved(0) > 0

    del loss, seg_loss, inst_loss, process_loss
    del seg_pred, inst_pred, process_pred, moved, model

    statistics = make_statistics()
    pretrain_batch = make_pretrain_batch(statistics, include_b=True)
    from dataloader.brep_pretrain import move_brep_pretrain_model_input_batch

    moved_pretrain = move_brep_pretrain_model_input_batch(
        pretrain_batch,
        device,
        non_blocking=True,
    )
    pretrainer = BRepPhysicalMessageMaskedPretrainer().to(device)
    with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
        output = pretrainer(moved_pretrain, return_predictions=True)
    assert output["target_node_embedding"].requires_grad is False
    assert output["target_node_embedding"].grad_fn is None
    assert output["target_edge_embedding"].requires_grad is False
    output["loss"].backward()
    assert any(
        parameter.grad is not None
        for parameter in pretrainer.backbone.geometry_encoder.parameters()
        if parameter.requires_grad
    )

    del output, moved_pretrain, pretrainer


def main():
    static_protocol_checks()
    if not cuda_build_can_run_current_device():
        print("GPU_BATCH_RUNTIME_STATIC_CHECK_PASS")
        return
    dynamic_cuda_checks()
    print("GPU_BATCH_RUNTIME_CHECK_PASS")


if __name__ == "__main__":
    main()
