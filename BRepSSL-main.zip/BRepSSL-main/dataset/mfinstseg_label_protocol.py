

from __future__ import annotations

from typing import Mapping

import numpy as np


TINY_RAW_CLASS_IDS = (0, 1, 3, 6, 8, 11, 12, 14, 17, 19, 22, 23, 24)
TINY_CLASS_NAMES = (
    "chamfer",
    "through_hole",
    "rectangular_passage",
    "rectangular_through_slot",
    "rectangular_through_step",
    "Oring",
    "blind_hole",
    "rectangular_pocket",
    "rectangular_blind_slot",
    "h_circular_end_blind_slot",
    "rectangular_blind_step",
    "round",
    "stock",
)
RAW_TO_TINY_CLASS = {
    raw_class: tiny_class
    for tiny_class, raw_class in enumerate(TINY_RAW_CLASS_IDS)
}
VALID_PROCESS_TYPES = frozenset((-1, 0, 1))
STOCK_RAW_CLASS_ID = 24


def _require_face_mapping(part_id, labels, field_name, expected_keys):
    value = labels.get(field_name)
    if not isinstance(value, Mapping):
        raise TypeError(f"part={part_id}: {field_name} must be a mapping")
    actual_keys = set(value)
    if actual_keys != expected_keys:
        raise ValueError(
            f"part={part_id}: {field_name} face IDs must exactly equal "
            f"0..{len(expected_keys) - 1}; "
            f"missing={sorted(expected_keys - actual_keys)[:20]}, "
            f"extra={sorted(actual_keys - expected_keys)[:20]}"
        )
    return value


def _integer_label(value, context):
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise TypeError(f"{context} must be an integer")
    return int(value)


def _finite_float(value, context):
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise TypeError(f"{context} must be convertible to float") from exc
    if not np.isfinite(result):
        raise ValueError(f"{context} must be finite")
    return result


def validate_mfinstseg_label_payload(
    part_id,
    labels_data,
    *,
    num_nodes,
):
    
    if not isinstance(part_id, str) or not part_id:
        raise ValueError("part_id must be a non-empty string")
    if isinstance(num_nodes, bool) or not isinstance(
        num_nodes, (int, np.integer)
    ):
        raise TypeError("num_nodes must be an integer")
    num_nodes = int(num_nodes)
    if num_nodes <= 0:
        raise ValueError(f"part={part_id}: num_nodes must be positive")
    if (
        not isinstance(labels_data, list)
        or len(labels_data) != 1
        or not isinstance(labels_data[0], list)
        or len(labels_data[0]) != 2
    ):
        raise ValueError(
            f"part={part_id}: label file must be exactly [[part_id, labels]]"
        )
    embedded_part_id, labels = labels_data[0]
    if embedded_part_id != part_id:
        raise ValueError(
            f"part={part_id}: embedded part ID is {embedded_part_id!r}"
        )
    if not isinstance(labels, Mapping):
        raise TypeError(f"part={part_id}: labels must be a mapping")
    required = {"seg", "inst", "process_type", "roughness", "tolerance"}
    missing = sorted(required - set(labels))
    if missing:
        raise KeyError(f"part={part_id}: labels missing fields {missing}")

    expected_keys = {str(index) for index in range(num_nodes)}
    seg_mapping = _require_face_mapping(
        part_id, labels, "seg", expected_keys
    )
    process_mapping = _require_face_mapping(
        part_id, labels, "process_type", expected_keys
    )
    roughness_mapping = _require_face_mapping(
        part_id, labels, "roughness", expected_keys
    )
    tolerance_mapping = _require_face_mapping(
        part_id, labels, "tolerance", expected_keys
    )

    raw_seg = np.empty(num_nodes, dtype=np.int64)
    process = np.empty(num_nodes, dtype=np.int64)
    quality = np.empty((num_nodes, 2), dtype=np.float32)
    for face_index in range(num_nodes):
        key = str(face_index)
        raw_class = _integer_label(
            seg_mapping[key], f"part={part_id}: seg[{key}]"
        )
        if raw_class not in RAW_TO_TINY_CLASS:
            raise ValueError(
                f"part={part_id}: seg[{key}]={raw_class} is not one of "
                f"{TINY_RAW_CLASS_IDS}"
            )
        process_type = _integer_label(
            process_mapping[key],
            f"part={part_id}: process_type[{key}]",
        )
        if process_type not in VALID_PROCESS_TYPES:
            raise ValueError(
                f"part={part_id}: process_type[{key}]={process_type} is invalid"
            )
        roughness = _finite_float(
            roughness_mapping[key],
            f"part={part_id}: roughness[{key}]",
        )
        tolerance = _finite_float(
            tolerance_mapping[key],
            f"part={part_id}: tolerance[{key}]",
        )
        if raw_class == STOCK_RAW_CLASS_ID:
            if process_type != -1 or roughness != 0.0 or tolerance != 0.0:
                raise ValueError(
                    f"part={part_id}: stock face {face_index} requires "
                    "process=-1, roughness=0, tolerance=0"
                )
        elif process_type not in (0, 1):
            raise ValueError(
                f"part={part_id}: non-stock face {face_index} requires "
                "process_type 0 or 1"
            )
        raw_seg[face_index] = raw_class
        process[face_index] = process_type
        quality[face_index] = (roughness, tolerance)

    instance = np.asarray(labels["inst"])
    if instance.shape != (num_nodes, num_nodes):
        raise ValueError(
            f"part={part_id}: inst shape must be "
            f"({num_nodes},{num_nodes}), got {instance.shape}"
        )
    if not np.issubdtype(instance.dtype, np.number):
        raise TypeError(f"part={part_id}: inst must contain numeric values")
    instance = instance.astype(np.float32, copy=True)
    if not np.all(np.isfinite(instance)):
        raise ValueError(f"part={part_id}: inst contains NaN or Inf")
    if not np.all((instance == 0.0) | (instance == 1.0)):
        raise ValueError(f"part={part_id}: inst values must be exactly 0 or 1")
    if not np.array_equal(instance, instance.T):
        raise ValueError(f"part={part_id}: inst must be symmetric")

    stock = raw_seg == STOCK_RAW_CLASS_ID
    nonstock = ~stock
    if np.any(instance[stock] != 0.0) or np.any(instance[:, stock] != 0.0):
        raise ValueError(
            f"part={part_id}: stock rows and columns in inst must be zero"
        )
    
    
    
    nonstock_indices = np.flatnonzero(nonstock)
    instance[nonstock_indices, nonstock_indices] = 1.0
    for face_index in nonstock_indices:
        linked = np.flatnonzero(instance[face_index] == 1.0)
        if np.any(raw_seg[linked] != raw_seg[face_index]):
            raise ValueError(
                f"part={part_id}: instance containing face {face_index} "
                "mixes semantic classes"
            )
        for linked_index in linked:
            if not np.array_equal(
                instance[face_index],
                instance[linked_index],
            ):
                raise ValueError(
                    f"part={part_id}: inst relation is not transitive for "
                    f"faces {face_index} and {linked_index}"
                )

    tiny_seg = np.asarray(
        [RAW_TO_TINY_CLASS[int(value)] for value in raw_seg],
        dtype=np.int64,
    )
    return {
        "part_id": part_id,
        "raw_seg": raw_seg,
        "tiny_seg": tiny_seg,
        "inst": instance,
        "process_type": process,
        "quality": quality,
    }
