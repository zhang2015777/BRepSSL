import argparse
import hashlib
import json
import os
import platform
import random
import shutil
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from tqdm import tqdm


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
os.chdir(PROJECT_ROOT)

from dataloader.brep_pretrain import (
    BRepCompactGraphStore,
    BRepPretrainDataset,
    BRepPretrainModelInputBatch,
    move_brep_pretrain_model_input_batch,
    read_linux_process_memory_kib,
)
from configs.main_experiment_config import (
    FORMAL_DATASET_ROOT,
    FORMAL_GRAPH_RUNTIME_PROTOCOL,
    FORMAL_GRAPH_STORAGE_PROTOCOL,
    FORMAL_INPUT_PROTOCOL,
    PRETRAIN_MAIN_CONFIG,
)
from models.brep_physical_message_backbone import (
    BACKBONE_CHECKPOINT_FORMAT,
    FEATURE_PROTOCOL,
    INPUT_PROTOCOL,
)
from models.brep_physical_message_pretrainer import (
    BRepPhysicalMessageMaskedPretrainer,
    PRETRAINER_CHECKPOINT_FORMAT,
    PRETRAIN_METHOD,
)
from models.brep_pretrain_input_masking import (
    EDGE_CANDIDATE_POLICY,
    compute_brep_pretrain_batch_signature,
    sample_brep_pretrain_mask_plan,
)
from models.graph_masking import MASK_POLICY, MASK_SCOPE


CHECKPOINT_FORMAT = PRETRAINER_CHECKPOINT_FORMAT
EVAL_MASK_PROTOCOL = (
    "centered_graph_region_node_edge_mask/"
    "unique_nonself_physical_edges_v1"
)


class SimpleLogger:
    def __init__(self, log_path, mode="a"):
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.fp = self.log_path.open(mode, encoding="utf-8")

    def info(self, message):
        print(message, flush=True)
        self.fp.write(str(message) + "\n")
        self.fp.flush()

    def close(self):
        self.fp.close()


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Formal data3 physical-message masked pretraining."
    )
    parser.parse_args(argv)
    config = dict(PRETRAIN_MAIN_CONFIG)
    config.update(
        {
            "dataset_root": str(FORMAL_DATASET_ROOT),
            "input_protocol": FORMAL_INPUT_PROTOCOL,
            "node_mask_ratio": float(config["mask_ratio"]),
            "edge_mask_ratio": float(config["mask_ratio"]),
            "save_every": 0,
            "max_train_samples": None,
            "resume": None,
        }
    )
    return SimpleNamespace(**config)


def validate_args(args):
    make_device(args.device)
    if args.epochs <= 0:
        raise ValueError(f"--epochs must be positive, got {args.epochs}.")
    if args.batch_size <= 0:
        raise ValueError(f"--batch_size must be positive, got {args.batch_size}.")
    if args.num_workers < 0:
        raise ValueError(f"--num_workers must be non-negative, got {args.num_workers}.")
    if args.max_train_samples is not None:
        raise ValueError("Formal pretraining always uses the complete train split.")
    if args.save_every < 0:
        raise ValueError(f"--save_every must be non-negative, got {args.save_every}.")
    if args.eval_every <= 0:
        raise ValueError(f"--eval_every must be positive, got {args.eval_every}.")
    if args.save_last_every <= 0:
        raise ValueError(
            f"--save_last_every must be positive, got {args.save_last_every}."
        )
    if args.feat_smooth_l1_beta <= 0:
        raise ValueError(
            "--feat_smooth_l1_beta must be positive, got "
            f"{args.feat_smooth_l1_beta}."
        )
    if args.negative_edge_ratio < 0:
        raise ValueError(
            "--negative_edge_ratio must be non-negative, got "
            f"{args.negative_edge_ratio}."
        )
    if args.min_mask_nodes < 0:
        raise ValueError(
            f"--min_mask_nodes must be non-negative, got {args.min_mask_nodes}."
        )
    if args.min_mask_edges < 0:
        raise ValueError(
            f"--min_mask_edges must be non-negative, got {args.min_mask_edges}."
        )
    for name in (
        "node_loss_weight",
        "edge_loss_weight",
        "topology_loss_weight",
    ):
        value = getattr(args, name)
        if value < 0:
            raise ValueError(f"--{name} must be non-negative, got {value}.")
    if args.decoder_drop < 0 or args.decoder_drop >= 1:
        raise ValueError("--decoder_drop must be in [0,1)")
    expected_dimensions = {
        "face_attr_dim": 16,
        "face_grid_channels": 11,
        "edge_attr_dim": 16,
        "edge_grid_channels": 16,
    }
    for name, expected in expected_dimensions.items():
        actual = getattr(args, name)
        if actual != expected:
            raise ValueError(
                f"Formal physical-message pretraining requires {name}="
                f"{expected}, got {actual}."
            )
    if args.input_protocol != FORMAL_INPUT_PROTOCOL:
        raise ValueError("Pretraining input protocol must be physical_message_v1")
    if args.eval_mask_seed < 0:
        raise ValueError("eval_mask_seed must be non-negative")
    if args.learnable_loss_weighting is not False:
        raise ValueError("learnable_loss_weighting must be False")


def validate_main_pretrain_config(args):
    expected = {
        "seed": 42,
        "pretrain_train_split": "train",
        "pretrain_eval_split": "eval",
        "input_protocol": FORMAL_INPUT_PROTOCOL,
        "graph_storage_protocol": FORMAL_GRAPH_STORAGE_PROTOCOL,
        "graph_runtime_protocol": FORMAL_GRAPH_RUNTIME_PROTOCOL,
        "mask_policy": MASK_POLICY,
        "mask_scope": MASK_SCOPE,
        "learnable_loss_weighting": False,
        "amp": True,
        "resume": None,
        "save_every": 0,
        "eval_every": 5,
        "save_last_every": 10,
        "normalize": True,
        "eval_mask_seed": 424242,
    }
    mismatches = []
    for name, expected_value in expected.items():
        actual_value = getattr(args, name)
        if actual_value != expected_value:
            mismatches.append(
                "{} must be {!r}, got {!r}".format(name, expected_value, actual_value)
            )
    if mismatches:
        raise ValueError(
            "Invalid PRETRAIN_MAIN_CONFIG for physical-message pretraining: "
            + "; ".join(mismatches)
        )


def make_device(device_arg):
    try:
        device = torch.device(device_arg)
    except (TypeError, ValueError, RuntimeError) as exc:
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            f"Invalid device: {device_arg!r}."
        ) from exc
    if device.type != "cuda":
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            f"Got device={device_arg!r}."
        )
    if not torch.cuda.is_available():
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            "torch.cuda.is_available() is False."
        )
    if device.index is not None and device.index >= torch.cuda.device_count():
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            f"Requested {device}, but only {torch.cuda.device_count()} CUDA device(s) "
            "are available."
        )
    return device


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def fixed_eval_mask_seed(batch, eval_mask_seed):
    if not isinstance(batch, BRepPretrainModelInputBatch):
        raise TypeError("batch must be a BRepPretrainModelInputBatch")
    if not isinstance(eval_mask_seed, int) or eval_mask_seed < 0:
        raise ValueError("eval_mask_seed must be a non-negative integer")
    payload = {
        "eval_mask_seed": eval_mask_seed,
        "part_ids": list(batch.part_ids),
        "batch_signature": compute_brep_pretrain_batch_signature(batch),
        "mask_protocol": EVAL_MASK_PROTOCOL,
    }
    digest = hashlib.sha256(
        json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big") & ((1 << 63) - 1)


def build_fixed_eval_mask_generator(batch, eval_mask_seed):
    seed = fixed_eval_mask_seed(batch, eval_mask_seed)
    generator = torch.Generator(device=batch.model_input.node_attr.device)
    generator.manual_seed(seed)
    return generator


def attach_edge_config(args):
    args.message_propagation_protocol = "directed_physical_messages"
    args.edge_decoder_source = "masked_physical_edge_endpoint_relation"
    return args.message_propagation_protocol, args.edge_decoder_source


def attach_edge_decoder_config(args, model):
    args.edge_decoder_relation_mode = (
        "canonical_forward_geometry_embedding_v1"
    )
    args.target_encoder = "shared_geometry_encoder_no_grad"
    args.node_target_dim = 128
    args.edge_target_dim = 128
    args.node_feat_dim = 128
    args.edge_feat_dim = 128
    args.node_decoder_input_dim = 256
    args.node_decoder_output_dim = 128
    args.edge_decoder_input_dim = 768
    args.edge_decoder_output_dim = 128
    args.topology_decoder_input_dim = 640
    return args.edge_decoder_input_dim, args.edge_decoder_relation_mode


def build_pretrain_metadata(args):
    return {
        "checkpoint_format": CHECKPOINT_FORMAT,
        "pretrain_method": PRETRAIN_METHOD,
        "input_protocol": INPUT_PROTOCOL,
        "feature_protocol": dict(FEATURE_PROTOCOL),
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "mask_policy": MASK_POLICY,
        "mask_scope": MASK_SCOPE,
        "edge_candidate_policy": EDGE_CANDIDATE_POLICY,
        "mask_ratio": float(args.mask_ratio),
        "node_mask_ratio": float(args.node_mask_ratio),
        "edge_mask_ratio": float(args.edge_mask_ratio),
        "embedding_targets": {
            "target_encoder": "shared_BRepGeometryEncoder_no_grad",
            "target_backbone_scope": "geometry_encoder_only",
            "node_target": "full_geometry.node_feat[masked_node_ids]",
            "node_target_dim": 128,
            "edge_target": (
                "full_geometry.message_edge_feat[2*physical_edge_id]"
            ),
            "edge_target_dim": 128,
            "canonical_edge_direction": "2*i=forward",
            "teacher_backbone": False,
            "ema_teacher": False,
        },
        "backbone_config": {
            "architecture": "BRepPhysicalMessageBackbone",
            "message_direction_mode": "directed_messages",
            "iba_dmp_layers": 3,
        },
        "mask_config": {
            "mask_policy": MASK_POLICY,
            "mask_scope": MASK_SCOPE,
            "mask_ratio": float(args.mask_ratio),
            "node_mask_ratio": float(args.node_mask_ratio),
            "edge_mask_ratio": float(args.edge_mask_ratio),
            "negative_edge_ratio": float(args.negative_edge_ratio),
            "edge_candidate_policy": EDGE_CANDIDATE_POLICY,
            "min_mask_nodes": int(args.min_mask_nodes),
            "min_mask_edges": int(args.min_mask_edges),
            "eval_mask_seed": int(args.eval_mask_seed),
        },
        "loss_config": {
            "node_loss_weight": float(args.node_loss_weight),
            "edge_loss_weight": float(args.edge_loss_weight),
            "topology_loss_weight": float(args.topology_loss_weight),
            "embedding_smooth_l1_beta": float(
                args.feat_smooth_l1_beta
            ),
            "learnable_loss_weighting": False,
            "loss_tasks": [
                "node_embedding",
                "physical_edge_embedding",
                "topology",
            ],
        },
    }


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def append_jsonl(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def write_text(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def timestamp_now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime())


def resolve_run_dir(args):
    return Path(args.output_dir).resolve()


def prepare_run_dirs(run_dir):
    if run_dir.exists():
        if not run_dir.is_dir():
            raise FileExistsError(
                f"Pretrain run_dir exists and is not a directory: {run_dir}"
            )
        if any(run_dir.iterdir()):
            raise FileExistsError(
                f"Pretrain run_dir already exists and is not empty: {run_dir}. "
                "Use a different --run_name or omit --run_name to create a "
                "timestamped run."
            )
    else:
        run_dir.mkdir(parents=True, exist_ok=False)

    dirs = {
        "logs": run_dir / "logs",
        "checkpoints": run_dir / "checkpoints",
        "splits": run_dir / "splits",
    }
    for path in dirs.values():
        path.mkdir(parents=False, exist_ok=False)
    return dirs


def get_dgl_version():
    try:
        import dgl
    except Exception as exc:  # pragma: no cover - defensive environment capture
        return "unavailable: {}".format(exc)
    return getattr(dgl, "__version__", "unknown")


def build_env_payload(device):
    cuda_device_name = None
    if torch.cuda.is_available() and torch.cuda.device_count() > 0:
        try:
            cuda_device_name = torch.cuda.get_device_name(0)
        except Exception as exc:  # pragma: no cover
            cuda_device_name = "unavailable: {}".format(exc)
    return {
        "python_version": sys.version,
        "platform": platform.platform(),
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "cuda_available": bool(torch.cuda.is_available()),
        "cuda_device_count": int(torch.cuda.device_count()) if torch.cuda.is_available() else 0,
        "cuda_device_name": cuda_device_name,
        "dgl_version": get_dgl_version(),
        "cwd": str(Path.cwd()),
        "device": str(device),
        "time": timestamp_now(),
    }


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def should_skip_manifest_path(path):
    skip_parts = {".git", "__pycache__", "output", "outputs", "wandb", "runs"}
    return any(part in skip_parts for part in path.parts)


def build_source_manifest(project_root):
    project_root = Path(project_root).resolve()
    files = []
    for path in project_root.rglob("*.py"):
        rel = path.relative_to(project_root)
        if should_skip_manifest_path(rel):
            continue
        stat = path.stat()
        files.append(
            {
                "path": str(rel),
                "sha256": sha256_file(path),
                "mtime": stat.st_mtime,
                "size": stat.st_size,
            }
        )
    expected = [
        "configs/main_experiment_config.py",
        "engine/pretrain_brep_mask.py",
        "dataloader/brep_pretrain.py",
        "utils/brep_data_io.py",
        "models/brep_geometry_encoder.py",
        "models/brep_pretrain_input_masking.py",
        "models/iba_dmp.py",
        "models/brep_physical_message_backbone.py",
        "models/brep_physical_message_pretrainer.py",
        "models/attention_refinement.py",
        "models/damped_diffusion.py",
        "models/graph_masking.py",
        "utils/physical_edge_message_adapter.py",
        "utils/message_edge_standardization.py",
        "utils/brep_model_input_view.py",
    ]
    existing_paths = {item["path"].replace("\\", "/") for item in files}
    return {
        "project_root": str(project_root),
        "created_time": timestamp_now(),
        "files": sorted(files, key=lambda item: item["path"]),
        "expected_files": expected,
        "missing_expected_files": [
            path for path in expected if path not in existing_paths
        ],
    }


def copy_required_split_files(dataset_root, split_dir):
    partition_dir = Path(dataset_root) / "MFInstseg_partition"
    required = {
        "train": partition_dir / "train.txt",
        "eval": partition_dir / "eval.txt",
        "test": partition_dir / "test.txt",
        "partition_info": partition_dir / "partition_info.json",
    }
    missing = [str(path) for path in required.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            "Required train/eval/test partition artifacts are missing: {}".format(missing)
        )
    copied = {}
    for key, src in required.items():
        dst = split_dir / src.name
        shutil.copy2(src, dst)
        copied[key] = str(dst)
    return copied


def ensure_label_free_graph(graph, context):
    forbidden = ("quality", "process_y", "seg_y", "inst_y", "bottom_y")
    found_node = [key for key in forbidden if key in graph.ndata.keys()]
    found_edge = [key for key in forbidden if key in graph.edata.keys()]
    if found_node or found_edge:
        raise ValueError(
            "{} received supervised graph fields: ndata={}, edata={}".format(
                context,
                found_node,
                found_edge,
            )
        )


def count_parameters(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total, trainable


def mean(values):
    return float(np.mean(values)) if values else 0.0


def scalar(value):
    if torch.is_tensor(value):
        return float(value.detach().cpu().item())
    return float(value)


def _cpu_state_dict(module):
    return {
        key: value.detach().cpu().clone()
        for key, value in module.state_dict().items()
    }


def is_better_fixed_eval_loss(candidate_loss, best_loss):
    candidate_loss = float(candidate_loss)
    best_loss = float(best_loss)
    if not np.isfinite(candidate_loss):
        raise ValueError("candidate eval loss must be finite")
    return candidate_loss < best_loss


def validate_pretrainer_checkpoint_payload(payload):
    if not isinstance(payload, dict):
        raise TypeError("Pretrainer checkpoint payload must be a dict")
    if payload.get("checkpoint_format") != PRETRAINER_CHECKPOINT_FORMAT:
        raise ValueError(
            "Incompatible pretrainer checkpoint format; expected "
            f"{PRETRAINER_CHECKPOINT_FORMAT!r}"
        )
    if payload.get("pretrain_method") != PRETRAIN_METHOD:
        raise ValueError("Pretrainer checkpoint method is incompatible")
    if payload.get("input_protocol") != INPUT_PROTOCOL:
        raise ValueError("Pretrainer checkpoint input protocol is incompatible")
    if payload.get("feature_protocol") != FEATURE_PROTOCOL:
        raise ValueError("Pretrainer checkpoint feature protocol is incompatible")
    embedding_targets = payload.get("embedding_targets")
    if not isinstance(embedding_targets, dict):
        raise ValueError("Pretrainer checkpoint lacks embedding target metadata")
    expected = {
        "target_encoder": "shared_BRepGeometryEncoder_no_grad",
        "target_backbone_scope": "geometry_encoder_only",
        "node_target": "full_geometry.node_feat[masked_node_ids]",
        "node_target_dim": 128,
        "edge_target": (
            "full_geometry.message_edge_feat[2*physical_edge_id]"
        ),
        "edge_target_dim": 128,
        "canonical_edge_direction": "2*i=forward",
        "teacher_backbone": False,
        "ema_teacher": False,
    }
    for key, value in expected.items():
        if embedding_targets.get(key) != value:
            raise ValueError(
                f"Pretrainer checkpoint embedding target {key} is incompatible"
            )
    return payload


def save_pretrainer_checkpoint(
    path,
    epoch,
    model,
    optimizer,
    scheduler,
    args,
    best_eval_loss,
    best_epoch,
    train_metrics,
    eval_metrics,
    scaler=None,
    source_manifest=None,
):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pretrain_metadata = build_pretrain_metadata(args)
    payload = {
        "checkpoint_format": PRETRAINER_CHECKPOINT_FORMAT,
        "epoch": int(epoch),
        "pretrainer_state_dict": _cpu_state_dict(model),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict(),
        "scaler_state_dict": (
            None if scaler is None else scaler.state_dict()
        ),
        "args": vars(args) if hasattr(args, "__dict__") else dict(args),
        "train_metrics": train_metrics,
        "eval_metrics": eval_metrics,
        "best_eval_loss": float(best_eval_loss),
        "best_epoch": int(best_epoch),
        "input_protocol": INPUT_PROTOCOL,
        "feature_protocol": dict(FEATURE_PROTOCOL),
        "mask_policy": MASK_POLICY,
        "edge_candidate_policy": EDGE_CANDIDATE_POLICY,
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "eval_mask_seed": int(args.eval_mask_seed),
        "source_manifest": source_manifest,
        **pretrain_metadata,
    }
    validate_pretrainer_checkpoint_payload(payload)
    torch.save(payload, path)
    return payload


def build_model(args):
    return BRepPhysicalMessageMaskedPretrainer(
        node_mask_ratio=args.node_mask_ratio,
        edge_mask_ratio=args.edge_mask_ratio,
        negative_edge_ratio=args.negative_edge_ratio,
        node_loss_weight=args.node_loss_weight,
        edge_loss_weight=args.edge_loss_weight,
        topology_loss_weight=args.topology_loss_weight,
        smooth_l1_beta=args.feat_smooth_l1_beta,
        min_mask_nodes=args.min_mask_nodes,
        min_mask_edges=args.min_mask_edges,
        decoder_drop=args.decoder_drop,
    )


def init_metric_lists():
    
    keys = (
        "loss_total",
        "loss_node_embedding",
        "loss_edge_embedding",
        "loss_topology",
        "num_mask_nodes",
        "num_mask_physical_edges",
        "num_mask_message_edges",
        "num_topology_pos",
        "num_topology_neg",
        "num_graphs",
        "num_candidate_nodes",
        "num_candidate_physical_edges",
        "node_mask_ratio_actual",
        "edge_mask_ratio_actual",
        "route_gate_mean",
        "route_gate_std",
        "route_gate_min",
        "route_gate_max",
        "route_gate_fraction_below_0_1",
        "route_gate_fraction_above_0_9",
    )
    return {key: {"sum": 0.0, "count": 0} for key in keys}


def record_batch_metrics(metric_lists, out):
    missing = [key for key in metric_lists if key not in out]
    if missing:
        raise KeyError(f"Pretrainer output is missing metrics: {missing}")
    for key in metric_lists:
        metric_lists[key]["sum"] += scalar(out[key])
        metric_lists[key]["count"] += 1


def build_epoch_log(epoch, split, dataset_split, lr, metric_lists, args, num_samples, num_batches, time_sec):
    result = {
        "epoch": epoch,
        "split": split,
        "dataset_split": dataset_split,
        "pretrain_method": PRETRAIN_METHOD,
        "mask_policy": MASK_POLICY,
        "mask_scope": MASK_SCOPE,
        "num_samples": int(num_samples),
        "num_batches": int(num_batches),
        "lr": lr,
        "time_sec": float(time_sec),
        "message_propagation_protocol": args.message_propagation_protocol,
        "edge_decoder_source": args.edge_decoder_source,
        "input_protocol": INPUT_PROTOCOL,
        "eval_mask_seed": int(args.eval_mask_seed),
    }
    for key, accumulator in metric_lists.items():
        count = accumulator["count"]
        result[key] = (
            accumulator["sum"] / count if count else 0.0
        )
    for key in (
        "num_mask_nodes",
        "num_mask_physical_edges",
        "num_mask_message_edges",
        "num_topology_pos",
        "num_topology_neg",
    ):
        result[f"total_{key}"] = int(metric_lists[key]["sum"])
    return result


def reset_gpu_peak_memory(device):
    device = torch.device(device)
    if device.type == "cuda":
        index = device.index if device.index is not None else 0
        torch.cuda.reset_peak_memory_stats(index)


def gpu_peak_memory(device):
    device = torch.device(device)
    if device.type != "cuda":
        return {
            "gpu_peak_allocated_bytes": 0,
            "gpu_peak_reserved_bytes": 0,
        }
    index = device.index if device.index is not None else 0
    return {
        "gpu_peak_allocated_bytes": int(
            torch.cuda.max_memory_allocated(index)
        ),
        "gpu_peak_reserved_bytes": int(
            torch.cuda.max_memory_reserved(index)
        ),
    }


def log_epoch(logger, epoch_log):
    lr_text = (
        "n/a"
        if epoch_log["lr"] is None
        else "{:.8f}".format(epoch_log["lr"])
    )
    logger.info(
        "Epoch {epoch:03d} [{split}] | lr={lr} | "
        "loss={loss:.6f} | node_embedding={node:.6f} | "
        "edge_embedding={edge:.6f} | "
        "topo={topo:.6f} | mask_n={mask_n:.4f} | mask_e={mask_e:.4f} | "
        "time={time:.1f}s".format(
            epoch=epoch_log["epoch"],
            split=epoch_log["split"],
            lr=lr_text,
            loss=epoch_log["loss_total"],
            node=epoch_log["loss_node_embedding"],
            edge=epoch_log["loss_edge_embedding"],
            topo=epoch_log["loss_topology"],
            mask_n=epoch_log["node_mask_ratio_actual"],
            mask_e=epoch_log["edge_mask_ratio_actual"],
            time=epoch_log["time_sec"],
        )
    )


def run_train_epoch(model, loader, optimizer, scaler, device, args, epoch, lr):
    model.train()
    metric_lists = init_metric_lists()
    start_time = time.time()

    bar = tqdm(loader, desc="train epoch {}/{}".format(epoch, args.epochs))
    for batch_idx, batch in enumerate(bar, start=1):
        if not isinstance(batch, BRepPretrainModelInputBatch):
            raise TypeError(
                "physical_message_v1 train loader returned an invalid batch"
            )
        batch = move_brep_pretrain_model_input_batch(
            batch,
            device,
            non_blocking=True,
        )
        optimizer.zero_grad(set_to_none=True)

        if args.amp:
            with torch.autocast(
                device_type="cuda",
                dtype=torch.float16,
                enabled=True,
            ):
                out = model(batch)
                loss = out["loss"]
            if not torch.isfinite(loss):
                raise RuntimeError(f"Non-finite train loss at epoch {epoch}: {loss.item()}")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            scaler.step(optimizer)
            scaler.update()
        else:
            out = model(batch)
            loss = out["loss"]
            if not torch.isfinite(loss):
                raise RuntimeError(f"Non-finite train loss at epoch {epoch}: {loss.item()}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

        record_batch_metrics(metric_lists, out)
        bar.set_postfix(loss="{:.6f}".format(scalar(out["loss_total"])))
        del loss, out, batch

    return build_epoch_log(
        epoch,
        "train",
        args.pretrain_train_split,
        lr,
        metric_lists,
        args,
        len(loader.dataset),
        len(loader),
        time.time() - start_time,
    )


def run_eval_epoch(model, loader, device, args, epoch):
    model.eval()
    metric_lists = init_metric_lists()
    start_time = time.time()

    with torch.no_grad():
        bar = tqdm(loader, desc="eval epoch {}/{}".format(epoch, args.epochs))
        for batch_idx, batch in enumerate(bar, start=1):
            if not isinstance(batch, BRepPretrainModelInputBatch):
                raise TypeError(
                    "physical_message_v1 eval loader returned an invalid batch"
                )
            batch = move_brep_pretrain_model_input_batch(
                batch,
                device,
                non_blocking=True,
            )
            generator = build_fixed_eval_mask_generator(
                batch,
                args.eval_mask_seed,
            )
            mask_plan = sample_brep_pretrain_mask_plan(
                batch,
                node_mask_ratio=args.node_mask_ratio,
                edge_mask_ratio=args.edge_mask_ratio,
                negative_edge_ratio=args.negative_edge_ratio,
                generator=generator,
                min_mask_nodes=args.min_mask_nodes,
                min_mask_edges=args.min_mask_edges,
            )
            if args.amp:
                with torch.autocast(
                    device_type="cuda",
                    dtype=torch.float16,
                    enabled=True,
                ):
                    out = model(batch, mask_plan=mask_plan)
            else:
                out = model(batch, mask_plan=mask_plan)
            loss = out["loss"]
            if not torch.isfinite(loss):
                raise RuntimeError(f"Non-finite eval loss at epoch {epoch}: {loss.item()}")
            record_batch_metrics(metric_lists, out)
            bar.set_postfix(loss="{:.6f}".format(scalar(out["loss_total"])))
            del loss, out, mask_plan, generator, batch

    return build_epoch_log(
        epoch,
        "eval",
        args.pretrain_eval_split,
        None,
        metric_lists,
        args,
        len(loader.dataset),
        len(loader),
        time.time() - start_time,
    )


def save_backbone(model, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not isinstance(model, BRepPhysicalMessageMaskedPretrainer):
        raise TypeError("model must be the physical-message pretrainer")
    payload = model.backbone.checkpoint_metadata()
    payload["state_dict"] = _cpu_state_dict(model.backbone)
    torch.save(payload, path)
    del payload


def build_summary(
    args,
    run_dir,
    paths,
    train_dataset,
    eval_dataset,
    best_epoch,
    best_eval_loss,
    last_epoch,
    last_train_loss,
    last_eval_loss,
    created_time,
    status,
    finished_time=None,
    error=None,
):
    summary = {
        "run_dir": str(run_dir),
        "dataset_root": str(Path(args.dataset_root).resolve()),
        "graphs_path": str(train_dataset.graphs_path),
        "train_split": args.pretrain_train_split,
        "eval_split": args.pretrain_eval_split,
        "train_count": len(train_dataset),
        "eval_count": len(eval_dataset),
        "test_split_file": getattr(args, "test_split_file", None),
        "test_count": int(getattr(args, "test_count", 0)),
        "test_used_for_pretraining": False,
        "epochs": int(args.epochs),
        "batch_size": int(args.batch_size),
        "eval_every": int(args.eval_every),
        "save_last_every": int(args.save_last_every),
        "best_epoch": int(best_epoch),
        "best_eval_loss": None if best_eval_loss == float("inf") else float(best_eval_loss),
        "last_epoch": int(last_epoch),
        "last_train_loss": last_train_loss,
        "last_eval_loss": last_eval_loss,
        "best_pretrainer_path": str(paths["best_pretrainer"]),
        "best_pretrained_backbone_path": str(paths["best_backbone"]),
        "last_pretrainer_path": str(paths["last_pretrainer"]),
        "last_pretrained_backbone_path": str(paths["last_backbone"]),
        "args_json": str(paths["args"]),
        "command_txt": str(paths["command"]),
        "env_json": str(paths["env"]),
        "source_manifest_json": str(paths["manifest"]),
        "train_log_jsonl": str(paths["train_log"]),
        "eval_log_jsonl": str(paths["eval_log"]),
        "main_experiment_config": dict(vars(args)),
        "created_time": created_time,
        "finished_time": finished_time,
        "status": status,
        "error": error,
        "graph_storage_protocol": FORMAL_GRAPH_STORAGE_PROTOCOL,
        "graph_runtime_protocol": FORMAL_GRAPH_RUNTIME_PROTOCOL,
        "loaded_graph_count": train_dataset.graph_store.loaded_graph_count,
        "stream_scan_count": train_dataset.graph_store.stream_scan_count,
        "estimated_compact_tensor_bytes": (
            train_dataset.graph_store.estimated_tensor_bytes
        ),
    }
    summary.update(build_pretrain_metadata(args))
    return summary


def main():
    args = parse_args()
    validate_args(args)
    validate_main_pretrain_config(args)
    attach_edge_config(args)
    args.checkpoint_format = CHECKPOINT_FORMAT
    args.pretrain_method = PRETRAIN_METHOD
    args.mask_policy = MASK_POLICY
    args.mask_scope = MASK_SCOPE
    device = make_device(args.device)
    seed_everything(args.seed)

    created_time = timestamp_now()
    run_dir = resolve_run_dir(args)
    dirs = prepare_run_dirs(run_dir)
    paths = {
        "args": run_dir / "args.json",
        "command": run_dir / "command.txt",
        "env": run_dir / "env.json",
        "manifest": run_dir / "source_manifest.json",
        "summary": run_dir / "summary.json",
        "log": dirs["logs"] / "log.txt",
        "train_log": dirs["logs"] / "train_log.jsonl",
        "eval_log": dirs["logs"] / "eval_log.jsonl",
        "best_pretrainer": dirs["checkpoints"] / "best_pretrainer.pth",
        "last_pretrainer": dirs["checkpoints"] / "last_pretrainer.pth",
        "best_backbone": dirs["checkpoints"] / "best_backbone.pth",
        "last_backbone": dirs["checkpoints"] / "last_backbone.pth",
    }

    write_text(paths["command"], " ".join(sys.argv) + "\n")
    write_json(paths["env"], build_env_payload(device))
    source_manifest = build_source_manifest(PROJECT_ROOT)
    write_json(paths["manifest"], source_manifest)
    write_text(paths["train_log"], "")
    write_text(paths["eval_log"], "")

    args.run_dir = str(run_dir)
    args.created_time = created_time

    logger = SimpleLogger(paths["log"], mode="w")
    best_eval_loss = float("inf")
    best_epoch = -1
    last_train_loss = None
    last_eval_loss = None
    last_epoch = 0

    try:
        logger.info("torch.__version__: {}".format(torch.__version__))
        logger.info("torch.cuda.is_available(): {}".format(torch.cuda.is_available()))
        if torch.cuda.is_available():
            logger.info("torch.cuda.get_device_name(0): {}".format(torch.cuda.get_device_name(0)))
        else:
            logger.info("torch.cuda.get_device_name(0): unavailable")
        logger.info("device: {}".format(device))
        logger.info("run_dir: {}".format(run_dir))
        logger.info("args_path: {}".format(paths["args"]))
        logger.info("train_log_path: {}".format(paths["train_log"]))
        logger.info("eval_log_path: {}".format(paths["eval_log"]))
        logger.info("pretrain_train_split: {}".format(args.pretrain_train_split))
        logger.info("pretrain_eval_split: {}".format(args.pretrain_eval_split))
        logger.info("pretrain_method: {}".format(args.pretrain_method))
        logger.info("input_protocol: {}".format(args.input_protocol))
        logger.info("eval_mask_seed: {}".format(args.eval_mask_seed))
        logger.info("mask_policy: {}".format(args.mask_policy))
        logger.info("mask_scope: {}".format(args.mask_scope))
        logger.info(
            "Message propagation protocol: {}".format(
                args.message_propagation_protocol
            )
        )
        logger.info("Edge reconstruction source: {}".format(args.edge_decoder_source))
        logger.info("mask_ratio: {}".format(args.mask_ratio))
        logger.info("resolved_node_mask_ratio: {}".format(args.node_mask_ratio))
        logger.info("resolved_edge_mask_ratio: {}".format(args.edge_mask_ratio))
        logger.info("negative_edge_ratio: {}".format(args.negative_edge_ratio))
        logger.info("min_mask_nodes: {}".format(args.min_mask_nodes))
        logger.info("min_mask_edges: {}".format(args.min_mask_edges))
        logger.info("max_train_samples: {}".format(args.max_train_samples))
        logger.info("pin_memory: {}".format(args.pin_memory))

        copied_splits = copy_required_split_files(args.dataset_root, dirs["splits"])
        logger.info("copied_splits: {}".format(copied_splits))
        test_split_path = Path(copied_splits["test"])
        test_ids = [
            line.strip()
            for line in test_split_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        if not test_ids:
            raise ValueError(f"Pretraining split snapshot is empty: {test_split_path}")
        args.test_split_file = str(test_split_path)
        args.test_count = len(test_ids)
        args.test_used_for_pretraining = False

        graph_store = BRepCompactGraphStore(
            args.dataset_root,
            normalize=True,
        )
        train_ids = graph_store.resolve_part_ids(
            split=args.pretrain_train_split,
            max_samples=args.max_train_samples,
        )
        eval_ids = graph_store.resolve_part_ids(
            split=args.pretrain_eval_split,
        )
        graph_store.ensure_loaded(train_ids + eval_ids)
        logger.info("graph_store_loaded_before_dataloader=True")
        logger.info(
            "requested_graph_count: {}".format(len(train_ids) + len(eval_ids))
        )
        logger.info(
            "loaded_graph_count: {}".format(graph_store.loaded_graph_count)
        )
        logger.info(
            "graph_construction_count: {}".format(
                graph_store.graph_construction_count
            )
        )
        logger.info(
            "estimated_compact_tensor_bytes: {}".format(
                graph_store.estimated_tensor_bytes
            )
        )
        logger.info("stream_scan_count: {}".format(graph_store.stream_scan_count))
        process_memory = read_linux_process_memory_kib()
        if process_memory is None:
            logger.info("process_memory_status: unavailable")
        else:
            logger.info("process_memory_kib: {}".format(process_memory))

        train_dataset = BRepPretrainDataset(
            dataset_root=args.dataset_root,
            split=args.pretrain_train_split,
            normalize=args.normalize,
            max_samples=args.max_train_samples,
            graph_store=graph_store,
        )
        eval_dataset = BRepPretrainDataset(
            dataset_root=args.dataset_root,
            split=args.pretrain_eval_split,
            normalize=args.normalize,
            max_samples=None,
            graph_store=graph_store,
        )
        if len(train_dataset) == 0:
            raise RuntimeError("Train BRepPretrainDataset is empty.")
        if len(eval_dataset) == 0:
            raise RuntimeError("Eval BRepPretrainDataset is empty.")
        logger.info("train_dataset: {}".format(train_dataset))
        logger.info("eval_dataset: {}".format(eval_dataset))

        train_loader = train_dataset.get_dataloader(
            batch_size=args.batch_size,
            shuffle=True,
            drop_last=False,
            num_workers=args.num_workers,
            pin_memory=bool(args.pin_memory and device.type == "cuda"),
        )
        eval_loader = eval_dataset.get_dataloader(
            batch_size=args.batch_size,
            shuffle=False,
            drop_last=False,
            num_workers=args.num_workers,
            pin_memory=bool(args.pin_memory and device.type == "cuda"),
        )
        if len(train_loader) == 0:
            raise RuntimeError("train_loader is empty.")
        if len(eval_loader) == 0:
            raise RuntimeError("eval_loader is empty.")
        logger.info("train_num_samples: {}".format(len(train_dataset)))
        logger.info("eval_num_samples: {}".format(len(eval_dataset)))
        logger.info("train_num_batches_per_epoch: {}".format(len(train_loader)))
        logger.info("eval_num_batches_per_epoch: {}".format(len(eval_loader)))

        model = build_model(args).to(device)
        attach_edge_decoder_config(args, model)
        args.train_count = len(train_dataset)
        args.eval_count = len(eval_dataset)
        args.graphs_path = str(train_dataset.graphs_path)
        args.train_split_file = str(train_dataset.split_file)
        args.eval_split_file = str(eval_dataset.split_file)
        write_json(paths["args"], vars(args))
        total_params, trainable_params = count_parameters(model)
        logger.info("total_params: {}".format(total_params))
        logger.info("trainable_params: {}".format(trainable_params))
        logger.info(
            "edge_decoder_relation_mode: {}".format(args.edge_decoder_relation_mode)
        )
        logger.info("node_feat_dim: {}".format(args.node_feat_dim))
        logger.info("edge_feat_dim: {}".format(args.edge_feat_dim))
        logger.info(
            "node_decoder_input_dim: {}".format(args.node_decoder_input_dim)
        )
        logger.info(
            "node_decoder_output_dim: {}".format(
                args.node_decoder_output_dim
            )
        )
        logger.info(
            "edge_decoder_input_dim: {}".format(args.edge_decoder_input_dim)
        )
        logger.info(
            "edge_decoder_output_dim: {}".format(
                args.edge_decoder_output_dim
            )
        )
        logger.info("target_encoder: {}".format(args.target_encoder))
        logger.info("node_target_dim: {}".format(args.node_target_dim))
        logger.info("edge_target_dim: {}".format(args.edge_target_dim))
        logger.info(
            "topology_decoder_input_dim: {}".format(
                args.topology_decoder_input_dim
            )
        )
        logger.info("learnable_loss_weighting: {}".format(args.learnable_loss_weighting))
        logger.info(
            "node_loss_weight: {}".format(args.node_loss_weight)
        )
        logger.info(
            "edge_loss_weight: {}".format(args.edge_loss_weight)
        )
        logger.info(
            "topology_loss_weight: {}".format(args.topology_loss_weight)
        )
        logger.info(
            "embedding_smooth_l1_beta: {}".format(
                args.feat_smooth_l1_beta
            )
        )
        logger.info("decoder_drop: {}".format(args.decoder_drop))

        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay,
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=args.epochs,
            eta_min=0.0,
        )
        scaler = torch.cuda.amp.GradScaler(enabled=args.amp)

        summary = build_summary(
            args,
            run_dir,
            paths,
            train_dataset,
            eval_dataset,
            best_epoch,
            best_eval_loss,
            last_epoch,
            last_train_loss,
            last_eval_loss,
            created_time,
            "running",
        )
        write_json(paths["summary"], summary)

        latest_eval_metrics = None
        for epoch in range(1, args.epochs + 1):
            reset_gpu_peak_memory(device)
            current_lr = float(optimizer.param_groups[0]["lr"])
            train_metrics = run_train_epoch(
                model,
                train_loader,
                optimizer,
                scaler,
                device,
                args,
                epoch,
                current_lr,
            )
            train_metrics.update(gpu_peak_memory(device))
            should_eval = (epoch % args.eval_every == 0) or (epoch == args.epochs)
            if should_eval:
                reset_gpu_peak_memory(device)
                eval_metrics = run_eval_epoch(model, eval_loader, device, args, epoch)
                eval_metrics.update(gpu_peak_memory(device))
                latest_eval_metrics = eval_metrics
            else:
                eval_metrics = None
            scheduler.step()

            log_epoch(logger, train_metrics)
            append_jsonl(paths["train_log"], train_metrics)
            if eval_metrics is not None:
                log_epoch(logger, eval_metrics)
                append_jsonl(paths["eval_log"], eval_metrics)

            last_epoch = epoch
            last_train_loss = float(train_metrics["loss_total"])
            is_best = False
            if eval_metrics is not None:
                last_eval_loss = float(eval_metrics["loss_total"])
                is_best = is_better_fixed_eval_loss(
                    last_eval_loss,
                    best_eval_loss,
                )
                if is_best:
                    best_eval_loss = last_eval_loss
                    best_epoch = epoch
                    save_backbone(model, paths["best_backbone"])
                    save_pretrainer_checkpoint(
                        paths["best_pretrainer"],
                        epoch,
                        model,
                        optimizer,
                        scheduler,
                        args,
                        best_eval_loss,
                        best_epoch,
                        train_metrics,
                        eval_metrics,
                        scaler=scaler,
                        source_manifest=source_manifest,
                    )

            should_save_last = (
                epoch % args.save_last_every == 0
            ) or (epoch == args.epochs)
            if should_save_last:
                save_backbone(model, paths["last_backbone"])
                save_pretrainer_checkpoint(
                    paths["last_pretrainer"],
                    epoch,
                    model,
                    optimizer,
                    scheduler,
                    args,
                    best_eval_loss,
                    best_epoch,
                    train_metrics,
                    latest_eval_metrics,
                    scaler=scaler,
                    source_manifest=source_manifest,
                )

            summary = build_summary(
                args,
                run_dir,
                paths,
                train_dataset,
                eval_dataset,
                best_epoch,
                best_eval_loss,
                last_epoch,
                last_train_loss,
                last_eval_loss,
                created_time,
                "running",
            )
            write_json(paths["summary"], summary)
            eval_text = (
                "eval=skipped"
                if eval_metrics is None
                else "eval_total={:.6f}".format(last_eval_loss)
            )
            best_text = (
                "n/a"
                if best_eval_loss == float("inf")
                else "{:.6f}".format(best_eval_loss)
            )
            logger.info(
                "[Epoch {epoch:03d}] train_total={train:.6f} {eval_text} "
                "best_eval={best} best_epoch={best_epoch} lr={lr:.8f}".format(
                    epoch=epoch,
                    train=last_train_loss,
                    eval_text=eval_text,
                    best=best_text,
                    best_epoch=best_epoch,
                    lr=current_lr,
                )
            )

        summary = build_summary(
            args,
            run_dir,
            paths,
            train_dataset,
            eval_dataset,
            best_epoch,
            best_eval_loss,
            last_epoch,
            last_train_loss,
            last_eval_loss,
            created_time,
            "complete",
            finished_time=timestamp_now(),
        )
        write_json(paths["summary"], summary)

        logger.info("[OK] B-Rep graph masked pretraining finished.")
        logger.info("best_pretrainer: {}".format(paths["best_pretrainer"]))
        logger.info("best_pretrained_backbone: {}".format(paths["best_backbone"]))
        logger.info("last_pretrainer: {}".format(paths["last_pretrainer"]))
        logger.info("last_pretrained_backbone: {}".format(paths["last_backbone"]))
        logger.info("train_log: {}".format(paths["train_log"]))
        logger.info("eval_log: {}".format(paths["eval_log"]))
        logger.info("summary: {}".format(paths["summary"]))
        logger.info("args: {}".format(paths["args"]))
    except Exception as exc:
        logger.info("[FAILED] B-Rep graph masked pretraining failed: {}".format(exc))
        fallback_train_dataset = locals().get("train_dataset")
        fallback_eval_dataset = locals().get("eval_dataset")
        if fallback_train_dataset is not None and fallback_eval_dataset is not None:
            summary = build_summary(
                args,
                run_dir,
                paths,
                fallback_train_dataset,
                fallback_eval_dataset,
                best_epoch,
                best_eval_loss,
                last_epoch,
                last_train_loss,
                last_eval_loss,
                created_time,
                "failed",
                finished_time=timestamp_now(),
                error=str(exc),
            )
            write_json(paths["summary"], summary)
        raise
    finally:
        logger.close()


if __name__ == "__main__":
    main()
