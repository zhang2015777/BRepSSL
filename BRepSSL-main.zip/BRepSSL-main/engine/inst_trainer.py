import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import shutil
import sys
import time
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn
from torch_ema import ExponentialMovingAverage
from torchmetrics.classification import (
    MulticlassAccuracy,
    MulticlassJaccardIndex,
)
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
os.chdir(PROJECT_ROOT)

from dataloader.mfinstseg_physical_message import (
    BRepSupervisedModelInputBatch,
    MFInstSegPhysicalMessageDataset,
    move_brep_supervised_model_input_batch,
)
from dataloader.brep_pretrain import (
    BRepCompactGraphStore,
    read_linux_process_memory_kib,
)
from dataset.mfinstseg_label_protocol import TINY_CLASS_NAMES
from configs.main_experiment_config import (
    FINETUNE_MAIN_CONFIG,
    FORMAL_DATASET_ROOT,
    FORMAL_GRAPH_RUNTIME_PROTOCOL,
    FORMAL_GRAPH_STORAGE_PROTOCOL,
)
from models.brep_physical_message_backbone import (
    BACKBONE_CHECKPOINT_FORMAT,
    BRepPhysicalMessageBackbone,
)
from models.brep_physical_message_quality_segmentor import (
    BRepPhysicalMessageQualitySegmentor,
)
from utils.instance_metrics import (
    batch_instance_cluster_iou,
    pairwise_instance_counts,
    pairwise_instance_metrics_from_counts,
    safe_div,
)
from utils.evaluation_artifacts import (
    classification_metrics_from_confusion,
    instance_confusion_matrix_from_counts,
    make_confusion_matrix,
    update_confusion_matrix,
    write_confusion_matrix_csv,
    write_confusion_matrix_png,
    write_per_class_metrics_csv,
)
from utils.misc import init_logger, seed_torch
from utils.graph_json_stream import sha256_part_ids, stream_graph_part_ids


FINETUNE_CHECKPOINT_FORMAT = "brep_physical_message_finetune_v1"
FINETUNE_ARCHITECTURE = "BRepPhysicalMessageQualitySegmentor"
INPUT_PROTOCOL = "physical_message_v1"
SPLIT_PROTOCOL = "train_eval_test_80_10_10_seed42"
BEST_METRIC_NAME = "mean_eval_semantic_iou_and_instance_pair_iou"
BEST_TIE_TOLERANCE = 1e-12


SOURCE_MANIFEST_EXCLUDE_DIRS = {
    ".git",
    "__pycache__",
    "output",
    "outputs",
    "output_finetune",
    "wandb",
    "runs",
}

EPOCH_METRICS_FIELDS = (
    "epoch",
    "split",
    "train_percent",
    "sample_count",
    "num_batches",
    "loss_total",
    "semantic_loss",
    "instance_loss",
    "process_loss",
    "semantic_acc",
    "semantic_iou",
    "instance_pair_acc",
    "instance_pair_precision",
    "instance_pair_recall",
    "instance_pair_f1",
    "instance_pair_iou",
    "instance_cluster_iou",
    "instance_cluster_iou_matched",
    "process_acc",
    "process_iou",
    "best_metric",
    "best_so_far",
    "best_epoch",
    "is_best",
    "time_sec",
    "backbone_lr",
    "head_lr",
)

METRICS_SCHEMA = {
    "semantic_acc": {
        "description": "Face-level semantic classification accuracy.",
        "aggregation": "existing torchmetrics multiclass accuracy",
    },
    "semantic_iou": {
        "description": "Multiclass semantic Jaccard index.",
        "aggregation": "torchmetrics multiclass aggregation",
    },
    "instance_pair_acc": {
        "description": "Accuracy of valid face-pair same-instance predictions.",
        "formula": "(TP + TN) / (TP + FP + FN + TN)",
    },
    "instance_pair_precision": {
        "description": "Precision of valid face-pair same-instance predictions.",
        "formula": "TP / (TP + FP)",
    },
    "instance_pair_recall": {
        "description": "Recall of valid face-pair same-instance predictions.",
        "formula": "TP / (TP + FN)",
    },
    "instance_pair_f1": {
        "description": "F1 of valid face-pair same-instance predictions.",
        "formula": "2TP / (2TP + FP + FN)",
    },
    "instance_pair_iou": {
        "description": "IoU of valid face-pair same-instance predictions.",
        "formula": "TP / (TP + FP + FN)",
    },
    "instance_cluster_iou": {
        "description": (
            "Mean per-graph instance-set IoU after Hungarian matching, with "
            "unmatched predicted or ground-truth instances penalized as zero."
        ),
        "formula": "matched IoU sum / max(num_pred_instances, num_gt_instances)",
    },
    "instance_cluster_iou_matched": {
        "description": (
            "Mean per-graph IoU over Hungarian-matched predicted and "
            "ground-truth instance pairs only."
        ),
        "formula": "matched IoU sum / num_matched_pairs",
    },
    "process_acc": {
        "description": "Accuracy of valid quality-only process predictions.",
        "aggregation": (
            "existing torchmetrics multiclass accuracy over faces with "
            "process label != -1"
        ),
    },
    "process_iou": {
        "description": "Binary-class process Jaccard index.",
        "aggregation": "torchmetrics multiclass aggregation",
    },
    "instance_threshold": 0.5,
}


def update_process_metrics(process_pred, process_label, process_acc, process_iou):
    valid_mask = process_label != -1
    if valid_mask.any().item():
        process_acc.update(process_pred[valid_mask], process_label[valid_mask])
        process_iou.update(process_pred[valid_mask], process_label[valid_mask])


def compute_process_loss(process_loss_fn, process_pred, process_label):
    valid_mask = process_label != -1
    if valid_mask.any().item():
        return process_loss_fn(process_pred, process_label)
    return process_pred.sum() * 0.0


def compute_masked_instance_loss(instance_loss_fn, inst_pred, inst_label, inst_mask):
    raw_loss = instance_loss_fn(inst_pred, inst_label)
    if raw_loss.shape != inst_mask.shape:
        raise ValueError(
            "Instance loss shape {} does not match mask shape {}.".format(
                tuple(raw_loss.shape), tuple(inst_mask.shape)
            )
        )
    masked_loss = raw_loss * inst_mask
    denom = inst_mask.sum().clamp_min(1.0)
    return masked_loss.sum() / denom


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Train the physical-message B-Rep segmentor for MFInstSeg."
    )
    parser.add_argument("--train_percent", type=float, required=True)
    parser.add_argument("--run_dir", type=str, required=True)
    parser.add_argument("--pretrained_backbone", type=str, required=True)

    config = dict(FINETUNE_MAIN_CONFIG)
    overrides = vars(parser.parse_args(argv))
    config.update(overrides)
    config["dataset_root"] = str(FORMAL_DATASET_ROOT)
    config["initialization_mode"] = "pretrained"
    return SimpleNamespace(**config)


def make_device(device_arg):
    try:
        device = torch.device(device_arg)
    except (TypeError, ValueError, RuntimeError) as exc:
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            f"Invalid device: {device_arg!r}."
        ) from exc
    if device.type != "cuda":
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            f"Got device={device_arg!r}."
        )
    if not torch.cuda.is_available():
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            "torch.cuda.is_available() is False."
        )
    if device.index is not None and device.index >= torch.cuda.device_count():
        raise RuntimeError(
            "This experiment requires CUDA/GPU and does not support CPU fallback. "
            f"Requested {device}, but only {torch.cuda.device_count()} CUDA device(s) "
            "are available."
        )
    return device


def log_torch_device_info(logger, requested_device):
    logger.info("torch.__version__: {}".format(torch.__version__))
    logger.info("torch.version.cuda: {}".format(torch.version.cuda))
    logger.info("requested device: {}".format(requested_device))
    logger.info("torch.cuda.is_available(): {}".format(torch.cuda.is_available()))
    if requested_device.startswith("cuda") and torch.cuda.is_available():
        device_index = torch.device(requested_device).index
        if device_index is None:
            device_index = torch.cuda.current_device()
        logger.info("GPU name: {}".format(torch.cuda.get_device_name(device_index)))
        capability = torch.cuda.get_device_capability(device_index)
        logger.info("GPU compute capability: sm_{}{}".format(capability[0], capability[1]))


def set_backbone_freeze_for_epoch(model, epoch, freeze_backbone_epochs):
    if freeze_backbone_epochs > 0 and epoch <= freeze_backbone_epochs:
        model.freeze_backbone()
        return True
    model.unfreeze_backbone()
    return False


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def append_jsonl(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def initialize_csv(path, fieldnames):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        csv.DictWriter(f, fieldnames=fieldnames).writeheader()


def append_csv_row(path, fieldnames, row):
    with Path(path).open("a", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writerow({field: row.get(field) for field in fieldnames})


def write_single_row_csv(path, row):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)


def read_id_file(path):
    path = Path(path)
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]


def write_id_file(path, ids):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        for part_id in ids:
            f.write("{}\n".format(part_id))


def get_param_group_lrs(optimizer):
    return {
        group.get("name", str(idx)): group["lr"]
        for idx, group in enumerate(optimizer.param_groups)
    }


def format_percent_tag(train_percent):
    value = float(train_percent)
    text = "{:.6f}".format(value).rstrip("0").rstrip(".")
    if "." not in text:
        text = text + ".0"
    return "pct_" + text.replace(".", "p")


def resolve_path(path_arg, base=PROJECT_ROOT):
    path = Path(path_arg)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def validate_args(args):
    if not args.pretrained_backbone:
        raise ValueError("--pretrained_backbone is required.")
    make_device(args.device)
    if args.train_percent <= 0 or args.train_percent > 100:
        raise ValueError("--train_percent must satisfy 0 < train_percent <= 100.")
    if args.freeze_backbone_epochs < 0:
        raise ValueError("--freeze_backbone_epochs must be non-negative.")
    if args.backbone_lr <= 0:
        raise ValueError("--backbone_lr must be positive.")
    if args.head_lr <= 0:
        raise ValueError("--head_lr must be positive.")
    if args.weight_decay < 0:
        raise ValueError("--weight_decay must be non-negative.")
    if args.head_hidden_dim <= 0:
        raise ValueError("--head_hidden_dim must be positive.")
    if args.quality_hidden_dim <= 0:
        raise ValueError("--quality_hidden_dim must be positive.")
    if args.process_head_depth < 1:
        raise ValueError("--process_head_depth must be >= 1.")
    if args.task_adapter_hidden_dim <= 0:
        raise ValueError("--task_adapter_hidden_dim must be positive.")
    if args.task_adapter_depth < 0:
        raise ValueError("--task_adapter_depth must be non-negative.")
    if args.task_adapter_init_scale < 0:
        raise ValueError("--task_adapter_init_scale must be non-negative.")
    for name in (
        "quality_drop",
        "task_adapter_drop",
    ):
        value = getattr(args, name)
        if value < 0 or value >= 1:
            raise ValueError("--{} must be in [0, 1).".format(name))
    if args.epochs <= 0:
        raise ValueError("--epochs must be positive.")
    if args.batch_size <= 0:
        raise ValueError("--batch_size must be positive.")
    if args.num_workers < 0:
        raise ValueError("--num_workers must be non-negative.")
    if args.eval_every <= 0:
        raise ValueError(
            f"--eval_every must be positive, got {args.eval_every}."
        )
    if args.save_last_every <= 0:
        raise ValueError(
            f"--save_last_every must be positive, got {args.save_last_every}."
        )


def validate_main_finetune_config(args):
    dataset_root = Path(args.dataset_root)
    if not dataset_root.is_dir():
        raise ValueError("dataset_root must exist and be a directory: {}".format(dataset_root))
    if not Path(args.pretrained_backbone).is_file():
        raise ValueError(
            "pretrained_backbone must exist: {}".format(args.pretrained_backbone)
        )
    if not Path(args.quality_stat_path).is_file():
        raise ValueError(
            "quality_stat_path does not exist: {}. Pass --quality_stat_path "
            "with the correct quality statistics file.".format(args.quality_stat_path)
        )

    if args.input_protocol != INPUT_PROTOCOL:
        raise ValueError(f"input_protocol must be {INPUT_PROTOCOL!r}.")
    if args.graph_storage_protocol != FORMAL_GRAPH_STORAGE_PROTOCOL:
        raise ValueError("graph_storage_protocol mismatch.")
    if args.graph_runtime_protocol != FORMAL_GRAPH_RUNTIME_PROTOCOL:
        raise ValueError("graph_runtime_protocol mismatch.")
    if args.backbone_architecture != "BRepPhysicalMessageBackbone":
        raise ValueError(
            "backbone_architecture must be 'BRepPhysicalMessageBackbone'."
        )
    if args.backbone_checkpoint_format != BACKBONE_CHECKPOINT_FORMAT:
        raise ValueError("backbone checkpoint protocol mismatch.")
    if args.finetune_checkpoint_format != FINETUNE_CHECKPOINT_FORMAT:
        raise ValueError("finetune checkpoint protocol mismatch.")
    if args.split_protocol != SPLIT_PROTOCOL:
        raise ValueError("split_protocol mismatch.")
    if args.best_metric_name != BEST_METRIC_NAME:
        raise ValueError("best_metric_name mismatch.")
    if args.pretrained_strict is not True:
        raise ValueError("pretrained_strict must remain True.")
    if args.process_branch != "quality_only":
        raise ValueError("process_branch must be 'quality_only'.")
    if args.process_input != "normalized_[roughness,tolerance]":
        raise ValueError(
            "process_input must be 'normalized_[roughness,tolerance]'."
        )
    if args.process_backpropagates_to_backbone is not False:
        raise ValueError("process_backpropagates_to_backbone must be False.")
    if args.train_split != "train":
        raise ValueError("train_split must be 'train'.")
    if args.eval_split != "eval":
        raise ValueError("eval_split must be 'eval'.")
    if args.test_split != "test":
        raise ValueError("test_split must be 'test'.")


def validate_pretrained_backbone_source(args):
    backbone_path = Path(args.pretrained_backbone).resolve()
    payload = torch.load(backbone_path, map_location="cpu")
    BRepPhysicalMessageBackbone._validate_checkpoint_payload(payload)
    source_run_dir = backbone_path.parent.parent
    args.pretrained_source_run_dir = str(source_run_dir)
    args.pretrained_source_run_name = source_run_dir.name
    return source_run_dir


def make_run_dir(args):
    percent_tag = format_percent_tag(args.train_percent)
    args.percent_tag = percent_tag
    run_dir = resolve_path(args.run_dir)
    if run_dir.exists():
        if not run_dir.is_dir():
            raise FileExistsError(
                "Finetune run_dir exists and is not a directory: {}".format(run_dir)
            )
        if any(run_dir.iterdir()):
            raise FileExistsError(
                "Finetune run_dir already exists and is not empty: {}. "
                "Resume must restart this incomplete stage after removing its "
                "invalid formal output.".format(run_dir)
            )
    dirs = {
        "run": run_dir,
        "logs": run_dir / "logs",
        "checkpoints": run_dir / "checkpoints",
        "metrics": run_dir / "metrics",
        "splits": run_dir / "splits",
    }
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)
    return run_dir, dirs


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def should_exclude_manifest_path(path):
    rel = path.relative_to(PROJECT_ROOT)
    return any(part in SOURCE_MANIFEST_EXCLUDE_DIRS for part in rel.parts)


def build_source_manifest():
    files = []
    for path in sorted(PROJECT_ROOT.rglob("*.py")):
        if should_exclude_manifest_path(path):
            continue
        stat = path.stat()
        files.append(
            {
                "path": str(path.relative_to(PROJECT_ROOT)).replace("\\", "/"),
                "sha256": file_sha256(path),
                "mtime": stat.st_mtime,
                "size": stat.st_size,
            }
        )
    expected = [
        "configs/main_experiment_config.py",
        "engine/inst_trainer.py",
        "dataloader/brep_pretrain.py",
        "dataloader/mfinstseg_protocol.py",
        "dataloader/mfinstseg_physical_message.py",
        "models/brep_geometry_encoder.py",
        "models/iba_dmp.py",
        "models/attention_refinement.py",
        "models/damped_diffusion.py",
        "models/brep_physical_message_backbone.py",
        "models/brep_physical_message_quality_segmentor.py",
        "models/task_heads.py",
        "utils/brep_data_io.py",
        "utils/physical_edge_message_adapter.py",
        "utils/message_edge_standardization.py",
        "utils/brep_model_input_view.py",
    ]
    expected_existing = [p for p in expected if (PROJECT_ROOT / p).is_file()]
    present = {entry["path"] for entry in files}
    return {
        "files": files,
        "expected_files": expected_existing,
        "missing_expected_files": [p for p in expected_existing if p not in present],
        "excluded_dirs": sorted(SOURCE_MANIFEST_EXCLUDE_DIRS),
    }


def build_env_info():
    cuda_device_name = None
    if torch.cuda.is_available() and torch.cuda.device_count() > 0:
        cuda_device_name = torch.cuda.get_device_name(0)
    dgl_version = None
    try:
        import dgl

        dgl_version = getattr(dgl, "__version__", None)
    except Exception:
        dgl_version = None
    return {
        "python_version": sys.version,
        "platform": platform.platform(),
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device_count": torch.cuda.device_count(),
        "cuda_device_name": cuda_device_name,
        "dgl_version": dgl_version,
        "cwd": str(Path.cwd()),
        "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
    }


def validate_formal_partition_metadata(partition_info):
    expected = {
        "split_protocol": SPLIT_PROTOCOL,
        "train_ratio": 0.8,
        "eval_ratio": 0.1,
        "requested_test_ratio": 0.1,
        "split_seed": 42,
        "test_split_enabled": True,
        "val_split_enabled": False,
    }
    for key, expected_value in expected.items():
        actual = partition_info.get(key)
        if key in ("train_ratio", "eval_ratio", "requested_test_ratio"):
            try:
                actual = float(actual)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"partition_info {key} must be numeric"
                ) from exc
        if actual != expected_value:
            raise ValueError(
                f"partition_info {key} must be {expected_value!r}, "
                f"got {actual!r}"
            )
    return partition_info


def prepare_splits_and_sample(args, run_dir):
    dataset_root = Path(args.dataset_root)
    partition_dir = dataset_root / "MFInstseg_partition"
    train_file = partition_dir / "train.txt"
    eval_file = partition_dir / "eval.txt"
    test_file = partition_dir / "test.txt"
    partition_info_file = partition_dir / "partition_info.json"
    for path in (train_file, eval_file, test_file, partition_info_file):
        if not path.is_file():
            raise FileNotFoundError(
                "Required train/eval/test partition file missing: {}".format(path)
            )

    train_full_ids = read_id_file(train_file)
    eval_ids = read_id_file(eval_file)
    test_ids = read_id_file(test_file)
    split_values = {
        "train": train_full_ids,
        "eval": eval_ids,
        "test": test_ids,
    }
    for name, values in split_values.items():
        if not values:
            raise ValueError(f"{name}.txt is empty")
        if len(values) != len(set(values)):
            raise ValueError(f"{name}.txt contains duplicate IDs")
    split_sets = {name: set(values) for name, values in split_values.items()}
    for left, right in (
        ("train", "eval"),
        ("train", "test"),
        ("eval", "test"),
    ):
        overlap = split_sets[left] & split_sets[right]
        if overlap:
            raise ValueError(
                f"{left}/{right} split overlap: {sorted(overlap)[:20]}"
            )
    graph_ids = stream_graph_part_ids(dataset_root / "brep_graph" / "graphs.json")
    graph_set = set(graph_ids)
    split_union = (
        split_sets["train"] | split_sets["eval"] | split_sets["test"]
    )
    if split_union != graph_set or len(graph_set) != len(graph_ids):
        raise ValueError(
            "Formal train/eval/test union does not exactly match graphs.json"
        )
    partition_info = json.loads(
        partition_info_file.read_text(encoding="utf-8")
    )
    validate_formal_partition_metadata(partition_info)
    for split_name, values in split_values.items():
        if partition_info.get(f"{split_name}_count") != len(values):
            raise ValueError(
                f"{partition_info_file}: {split_name}_count mismatch"
            )
    if partition_info.get("total_count") != len(graph_ids):
        raise ValueError(f"{partition_info_file}: total_count mismatch")
    if partition_info.get("train_ids_sha256") != sha256_part_ids(
        train_full_ids
    ):
        raise ValueError(
            f"{partition_info_file}: train_ids_sha256 mismatch"
        )
    train_subset_ids, sample_method = sample_train_subset(
        train_full_ids,
        args.train_percent,
        args.sample_seed,
    )

    splits_dir = run_dir / "splits"
    train_full_out = splits_dir / "train_full.txt"
    train_subset_out = splits_dir / "train_subset.txt"
    eval_out = splits_dir / "eval.txt"
    test_out = splits_dir / "test.txt"
    partition_info_out = splits_dir / "partition_info.json"
    shutil.copyfile(train_file, train_full_out)
    write_id_file(train_subset_out, train_subset_ids)
    shutil.copyfile(eval_file, eval_out)
    shutil.copyfile(test_file, test_out)
    shutil.copyfile(partition_info_file, partition_info_out)

    sample_info = {
        "sample_protocol": "train_percent_from_train_split",
        "dataset_root": args.dataset_root,
        "run_dir": str(run_dir),
        "train_total_count": len(train_full_ids),
        "train_subset_count": len(train_subset_ids),
        "eval_total_count": len(eval_ids),
        "test_total_count": len(test_ids),
        "train_percent": float(args.train_percent),
        "sample_count": len(train_subset_ids),
        "sample_seed": int(args.sample_seed),
        "sample_method": sample_method,
        "source_train_file": str(train_file),
        "source_eval_file": str(eval_file),
        "source_test_file": str(test_file),
        "saved_train_subset_file": str(train_subset_out),
        "eval_effective_count": len(eval_ids),
        "eval_used_for": "validation_and_best_checkpoint_selection",
        "test_used_for": "one_time_final_evaluation_only",
        "initialization_mode": args.initialization_mode,
        "pretrained_backbone": args.pretrained_backbone,
        "pretrained_source_run_dir": getattr(
            args, "pretrained_source_run_dir", None
        ),
        "pretrained_source_run_name": getattr(
            args, "pretrained_source_run_name", None
        ),
        "pretrained_backbone_filename": (
            None
            if args.pretrained_backbone is None
            else Path(args.pretrained_backbone).name
        ),
        "quality_stat_path": args.quality_stat_path,
        "input_protocol": INPUT_PROTOCOL,
        "split_protocol": SPLIT_PROTOCOL,
        "train_subset_ids_sha256": sha256_part_ids(train_subset_ids),
        "freeze_backbone_epochs": int(args.freeze_backbone_epochs),
        "backbone_lr": float(args.backbone_lr),
        "head_lr": float(args.head_lr),
        "weight_decay": float(args.weight_decay),
        "amp": bool(args.amp),
        "eval_every": int(args.eval_every),
        "save_last_every": int(args.save_last_every),
        "quality_drop": float(args.quality_drop),
        "process_branch": args.process_branch,
        "process_backpropagates_to_backbone": bool(
            args.process_backpropagates_to_backbone
        ),
    }
    write_json(splits_dir / "sample_info.json", sample_info)
    return {
        "train_file": train_file,
        "eval_file": eval_file,
        "test_file": test_file,
        "partition_info_file": partition_info_file,
        "train_full_ids": train_full_ids,
        "train_subset_ids": train_subset_ids,
        "eval_ids": eval_ids,
        "test_ids": test_ids,
        "train_full_out": train_full_out,
        "train_subset_out": train_subset_out,
        "eval_out": eval_out,
        "test_out": test_out,
        "partition_info_out": partition_info_out,
        "sample_info": sample_info,
        "sample_info_file": splits_dir / "sample_info.json",
    }


def sample_train_subset(train_ids, train_percent, sample_seed):
    
    values = list(train_ids)
    if not values or len(values) != len(set(values)):
        raise ValueError("train_ids must be non-empty and unique")
    percent = float(train_percent)
    if not math.isfinite(percent) or percent <= 0 or percent > 100:
        raise ValueError("train_percent must satisfy 0 < value <= 100")
    if math.isclose(percent, 100.0, rel_tol=0.0, abs_tol=1e-12):
        return values, "full_train"
    shuffled = list(values)
    random.Random(int(sample_seed)).shuffle(shuffled)
    count = max(1, int(math.ceil(len(values) * percent / 100.0)))
    return shuffled[:count], "random_shuffle_take_ceil"


def make_metric_bundle(n_classes, device):
    return {
        "seg_acc": MulticlassAccuracy(num_classes=n_classes).to(device),
        "process_acc": MulticlassAccuracy(num_classes=2).to(device),
        "seg_iou": MulticlassJaccardIndex(num_classes=n_classes).to(device),
        "process_iou": MulticlassJaccardIndex(num_classes=2).to(device),
        "inst_pair_counts": {"tp": 0, "fp": 0, "fn": 0, "tn": 0},
    }


def reset_metrics(metrics):
    for name, metric in metrics.items():
        if name == "inst_pair_counts":
            metric.update({"tp": 0, "fp": 0, "fn": 0, "tn": 0})
        else:
            metric.reset()


def compute_metric_values(metrics, prefix):
    counts = metrics["inst_pair_counts"]
    pair_metrics = pairwise_instance_metrics_from_counts(
        counts["tp"],
        counts["fp"],
        counts["fn"],
        counts["tn"],
    )
    return {
        "{}_seg_acc".format(prefix): metrics["seg_acc"].compute().item(),
        "{}_seg_iou".format(prefix): metrics["seg_iou"].compute().item(),
        "{}_inst_acc".format(prefix): pair_metrics["acc"],
        "{}_inst_f1".format(prefix): pair_metrics["f1"],
        "{}_inst_pair_acc".format(prefix): pair_metrics["acc"],
        "{}_inst_pair_precision".format(prefix): pair_metrics["precision"],
        "{}_inst_pair_recall".format(prefix): pair_metrics["recall"],
        "{}_inst_pair_f1".format(prefix): pair_metrics["f1"],
        "{}_inst_pair_iou".format(prefix): pair_metrics["iou"],
        "{}_process_acc".format(prefix): metrics["process_acc"].compute().item(),
        "{}_process_iou".format(prefix): metrics["process_iou"].compute().item(),
    }


def update_all_metrics(
    metrics,
    seg_pred,
    seg_label,
    inst_pred,
    inst_label,
    inst_mask,
    process_pred,
    process_label,
):
    metrics["seg_acc"].update(seg_pred, seg_label)
    metrics["seg_iou"].update(seg_pred, seg_label)
    tp, fp, fn, tn = pairwise_instance_counts(
        inst_pred,
        inst_label,
        inst_mask,
    )
    counts = metrics["inst_pair_counts"]
    counts["tp"] += tp
    counts["fp"] += fp
    counts["fn"] += fn
    counts["tn"] += tn
    update_process_metrics(
        process_pred,
        process_label,
        metrics["process_acc"],
        metrics["process_iou"],
    )


def reset_gpu_peak_memory(device):
    device = torch.device(device)
    if device.type == "cuda":
        index = device.index if device.index is not None else 0
        torch.cuda.reset_peak_memory_stats(index)


def gpu_peak_memory(device):
    device = torch.device(device)
    if device.type != "cuda":
        return {
            "gpu_peak_allocated_bytes": 0,
            "gpu_peak_reserved_bytes": 0,
        }
    index = device.index if device.index is not None else 0
    return {
        "gpu_peak_allocated_bytes": int(
            torch.cuda.max_memory_allocated(index)
        ),
        "gpu_peak_reserved_bytes": int(
            torch.cuda.max_memory_reserved(index)
        ),
    }


def _cpu_state_dict(module):
    return {
        key: value.detach().cpu().clone()
        for key, value in module.state_dict().items()
    }


def run_eval(
    model,
    loader,
    metrics,
    seg_loss,
    instance_loss,
    process_loss,
    device,
    loss_weights,
    use_autocast=True,
    metric_prefix="eval",
    detailed_confusion_matrices=None,
):
    if metric_prefix not in ("eval", "test"):
        raise ValueError(
            f"metric_prefix must be 'eval' or 'test', got {metric_prefix!r}"
        )
    model.eval()
    reset_metrics(metrics)
    loss_sums = {
        "total": 0.0,
        "semantic": 0.0,
        "instance": 0.0,
        "process": 0.0,
    }
    loss_batch_count = 0
    cluster_iou_sum = 0.0
    cluster_iou_matched_sum = 0.0
    cluster_graph_count = 0
    with torch.no_grad():
        for data in tqdm(loader):
            batch = move_brep_supervised_model_input_batch(
                data,
                device,
                non_blocking=True,
            )
            seg_label = batch.seg_y
            inst_label = batch.inst_labels
            inst_mask = batch.inst_masks.bool()
            process_label = batch.process_y

            autocast_ctx = (
                torch.autocast(device_type="cuda", dtype=torch.float16)
                if use_autocast and device.type == "cuda"
                else nullcontext()
            )
            with autocast_ctx:
                seg_pred, inst_pred, process_pred = model(batch)
                assert process_pred.dim() == 2
                assert process_pred.shape[1] == 2
                assert process_label.dim() == 1
                assert process_pred.shape[0] == process_label.shape[0]

                loss_seg = seg_loss(seg_pred, seg_label)
                loss_inst = compute_masked_instance_loss(
                    instance_loss,
                    inst_pred,
                    inst_label,
                    inst_mask.float(),
                )
                loss_process = compute_process_loss(process_loss, process_pred, process_label)
                loss = (
                    loss_weights["semantic"] * loss_seg
                    + loss_weights["instance"] * loss_inst
                    + loss_weights["process"] * loss_process
                )

            loss_sums["total"] += float(loss.detach().float().cpu())
            loss_sums["semantic"] += float(loss_seg.detach().float().cpu())
            loss_sums["instance"] += float(loss_inst.detach().float().cpu())
            loss_sums["process"] += float(loss_process.detach().float().cpu())
            loss_batch_count += 1
            update_all_metrics(
                metrics,
                seg_pred,
                seg_label,
                inst_pred,
                inst_label,
                inst_mask,
                process_pred,
                process_label,
            )
            if detailed_confusion_matrices is not None:
                update_confusion_matrix(
                    detailed_confusion_matrices["semantic"],
                    seg_pred,
                    seg_label,
                )
                update_confusion_matrix(
                    detailed_confusion_matrices["process"],
                    process_pred,
                    process_label,
                    ignore_index=-1,
                )
            cluster_metrics = batch_instance_cluster_iou(
                inst_pred,
                inst_label,
                inst_mask,
            )
            batch_graph_count = cluster_metrics["graph_count"]
            cluster_iou_sum += (
                cluster_metrics["inst_cluster_iou"] * batch_graph_count
            )
            cluster_iou_matched_sum += (
                cluster_metrics["inst_cluster_iou_matched"] * batch_graph_count
            )
            cluster_graph_count += batch_graph_count
            del (
                loss,
                loss_seg,
                loss_inst,
                loss_process,
                seg_pred,
                inst_pred,
                process_pred,
                seg_label,
                inst_label,
                inst_mask,
                process_label,
                batch,
            )

    metric_values = compute_metric_values(metrics, metric_prefix)
    metric_values.update(
        {
            f"{metric_prefix}_inst_cluster_iou": safe_div(
                cluster_iou_sum,
                cluster_graph_count,
            ),
            f"{metric_prefix}_inst_cluster_iou_matched": safe_div(
                cluster_iou_matched_sum,
                cluster_graph_count,
            ),
        }
    )
    return {
        "loss_total": loss_sums["total"] / max(loss_batch_count, 1),
        "semantic_loss": loss_sums["semantic"] / max(loss_batch_count, 1),
        "instance_loss": loss_sums["instance"] / max(loss_batch_count, 1),
        "process_loss": loss_sums["process"] / max(loss_batch_count, 1),
        **metric_values,
    }


def build_model(args, n_classes):
    return BRepPhysicalMessageQualitySegmentor(
        num_classes=n_classes,
        head_hidden_dim=args.head_hidden_dim,
        quality_hidden_dim=args.quality_hidden_dim,
        quality_drop=args.quality_drop,
        process_head_depth=args.process_head_depth,
        use_task_adapters=True,
        task_adapter_hidden_dim=args.task_adapter_hidden_dim,
        task_adapter_depth=args.task_adapter_depth,
        task_adapter_drop=args.task_adapter_drop,
        task_adapter_init_scale=args.task_adapter_init_scale,
    )


def compute_finetune_segmentation_score(eval_metrics):
    return 0.5 * (
        float(eval_metrics["eval_seg_iou"])
        + float(eval_metrics["eval_inst_pair_iou"])
    )


def make_best_candidate(eval_metrics, epoch):
    return {
        "segmentation_score": compute_finetune_segmentation_score(
            eval_metrics
        ),
        "semantic_iou": float(eval_metrics["eval_seg_iou"]),
        "instance_pair_iou": float(
            eval_metrics["eval_inst_pair_iou"]
        ),
        "process_iou": float(eval_metrics["eval_process_iou"]),
        "eval_loss": float(eval_metrics["loss_total"]),
        "epoch": int(epoch),
    }


def is_better_finetune_candidate(candidate, current_best):
    
    if current_best is None:
        return True
    score_delta = (
        candidate["segmentation_score"]
        - current_best["segmentation_score"]
    )
    if score_delta > BEST_TIE_TOLERANCE:
        return True
    if abs(score_delta) > BEST_TIE_TOLERANCE:
        return False
    process_delta = (
        candidate["process_iou"] - current_best["process_iou"]
    )
    if process_delta > BEST_TIE_TOLERANCE:
        return True
    if abs(process_delta) > BEST_TIE_TOLERANCE:
        return False
    loss_delta = candidate["eval_loss"] - current_best["eval_loss"]
    if loss_delta < -BEST_TIE_TOLERANCE:
        return True
    if abs(loss_delta) > BEST_TIE_TOLERANCE:
        return False
    return candidate["epoch"] < current_best["epoch"]


def finetune_model_config(args):
    return {
        "architecture": FINETUNE_ARCHITECTURE,
        "input_protocol": INPUT_PROTOCOL,
        "backbone_architecture": "BRepPhysicalMessageBackbone",
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "num_classes": 13,
        "head_hidden_dim": int(args.head_hidden_dim),
        "quality_hidden_dim": int(args.quality_hidden_dim),
        "quality_drop": float(args.quality_drop),
        "process_head_depth": int(args.process_head_depth),
        "use_task_adapters": True,
        "task_adapter_hidden_dim": int(args.task_adapter_hidden_dim),
        "task_adapter_depth": int(args.task_adapter_depth),
        "task_adapter_drop": float(args.task_adapter_drop),
        "task_adapter_init_scale": float(
            args.task_adapter_init_scale
        ),
    }


def _checkpoint_metadata(args, split_info, epoch, role):
    return {
        "checkpoint_format": FINETUNE_CHECKPOINT_FORMAT,
        "checkpoint_role": role,
        "architecture": FINETUNE_ARCHITECTURE,
        "input_protocol": INPUT_PROTOCOL,
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "split_protocol": SPLIT_PROTOCOL,
        "epoch": int(epoch),
        "train_percent": float(args.train_percent),
        "sample_seed": int(args.sample_seed),
        "train_subset_ids_sha256": sha256_part_ids(
            split_info["train_subset_ids"]
        ),
        "best_metric_name": BEST_METRIC_NAME,
        "model_config": finetune_model_config(args),
        "pretrained_backbone": args.pretrained_backbone,
        "initialization_mode": args.initialization_mode,
    }


def build_best_finetune_checkpoint(
    model,
    args,
    split_info,
    epoch,
    candidate,
):
    payload = _checkpoint_metadata(
        args,
        split_info,
        epoch,
        "best",
    )
    payload.update(
        {
            "best_segmentation_score": float(
                candidate["segmentation_score"]
            ),
            "best_semantic_iou": float(candidate["semantic_iou"]),
            "best_instance_pair_iou": float(
                candidate["instance_pair_iou"]
            ),
            "best_process_iou": float(candidate["process_iou"]),
            "best_eval_loss": float(candidate["eval_loss"]),
            "best_epoch": int(candidate["epoch"]),
            "model_state_dict": _cpu_state_dict(model),
            "ema_weights_applied": True,
        }
    )
    validate_finetune_checkpoint(payload, expected_role="best")
    return payload


def build_last_finetune_checkpoint(
    model,
    optimizer,
    scheduler,
    scaler,
    ema,
    args,
    split_info,
    epoch,
    best_candidate,
):
    payload = _checkpoint_metadata(
        args,
        split_info,
        epoch,
        "last",
    )
    payload.update(
        {
            "model_state_dict": _cpu_state_dict(model),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state_dict": scheduler.state_dict(),
            "scaler_state_dict": scaler.state_dict(),
            "ema_state_dict": ema.state_dict(),
            "best_candidate": best_candidate,
            "ema_weights_applied": False,
        }
    )
    validate_finetune_checkpoint(payload, expected_role="last")
    return payload


def validate_finetune_checkpoint(payload, expected_role=None):
    if not isinstance(payload, dict):
        raise TypeError("Finetune checkpoint must be a mapping")
    common = {
        "checkpoint_format": FINETUNE_CHECKPOINT_FORMAT,
        "architecture": FINETUNE_ARCHITECTURE,
        "input_protocol": INPUT_PROTOCOL,
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "split_protocol": SPLIT_PROTOCOL,
        "best_metric_name": BEST_METRIC_NAME,
    }
    for key, expected in common.items():
        if payload.get(key) != expected:
            raise ValueError(
                f"Finetune checkpoint {key} does not match the formal protocol"
            )
    role = payload.get("checkpoint_role")
    if role not in ("best", "last"):
        raise ValueError("Finetune checkpoint role must be best or last")
    if expected_role is not None and role != expected_role:
        raise ValueError(
            f"Expected checkpoint role {expected_role!r}, got {role!r}"
        )
    required = {
        "epoch",
        "train_percent",
        "sample_seed",
        "train_subset_ids_sha256",
        "model_config",
        "model_state_dict",
        "initialization_mode",
    }
    if role == "best":
        required.update(
            {
                "best_segmentation_score",
                "best_semantic_iou",
                "best_instance_pair_iou",
                "best_process_iou",
                "best_eval_loss",
                "best_epoch",
            }
        )
        if payload.get("ema_weights_applied") is not True:
            raise ValueError("Best checkpoint must contain EMA weights")
    else:
        required.update(
            {
                "optimizer_state_dict",
                "scheduler_state_dict",
                "scaler_state_dict",
                "ema_state_dict",
            }
        )
    missing = sorted(required.difference(payload))
    if missing:
        raise ValueError(f"Finetune checkpoint missing fields: {missing}")
    if not isinstance(payload["model_state_dict"], dict):
        raise TypeError("model_state_dict must be a mapping")
    model_config = payload["model_config"]
    if not isinstance(model_config, dict):
        raise TypeError("model_config must be a mapping")
    expected_model_values = {
        "architecture": FINETUNE_ARCHITECTURE,
        "input_protocol": INPUT_PROTOCOL,
        "backbone_architecture": "BRepPhysicalMessageBackbone",
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "num_classes": 13,
    }
    for key, expected in expected_model_values.items():
        if model_config.get(key) != expected:
            raise ValueError(
                f"Finetune checkpoint model_config {key} mismatch"
            )
    return payload


def main():
    args = parse_args()
    created_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    dataset_root_path = resolve_path(args.dataset_root)
    args.dataset_root = str(dataset_root_path)
    quality_stat_path = resolve_path(args.quality_stat_path)
    args.quality_stat_path = str(quality_stat_path)
    args.pretrained_backbone = str(resolve_path(args.pretrained_backbone))
    args.run_dir = str(resolve_path(args.run_dir))
    args.initialization_mode = "pretrained"
    validate_args(args)
    validate_main_finetune_config(args)
    validate_pretrained_backbone_source(args)
    args.loss_weights = {
        "semantic": 1.0,
        "instance": 1.0,
        "process": 1.0,
    }

    run_dir, dirs = make_run_dir(args)
    args.run_dir = str(run_dir)
    epoch_metrics_csv = dirs["metrics"] / "epoch_metrics.csv"
    final_test_metrics_csv = dirs["metrics"] / "final_test_metrics.csv"
    metrics_schema_json = dirs["metrics"] / "metrics_schema.json"
    initialize_csv(epoch_metrics_csv, EPOCH_METRICS_FIELDS)
    write_json(metrics_schema_json, METRICS_SCHEMA)
    pretrained_backbone_filename = (
        None
        if args.pretrained_backbone is None
        else Path(args.pretrained_backbone).name
    )
    pretrain_info = {
        "initialization_mode": args.initialization_mode,
        "pretrained_backbone": args.pretrained_backbone,
        "pretrained_source_run_dir": getattr(
            args, "pretrained_source_run_dir", None
        ),
        "pretrained_source_run_name": getattr(
            args, "pretrained_source_run_name", None
        ),
        "pretrained_backbone_filename": pretrained_backbone_filename,
    }
    write_json(run_dir / "pretrain_info.json", pretrain_info)
    split_info = prepare_splits_and_sample(args, run_dir)

    command_txt = run_dir / "command.txt"
    command_txt.write_text(" ".join(sys.argv), encoding="utf-8")
    env_json = run_dir / "env.json"
    write_json(env_json, build_env_info())
    source_manifest_json = run_dir / "source_manifest.json"
    write_json(source_manifest_json, build_source_manifest())

    summary = {
        "run_dir": str(run_dir),
        "dataset_root": args.dataset_root,
        "output_dir": str(run_dir.parent),
        "train_percent": float(args.train_percent),
        "percent_tag": args.percent_tag,
        "sample_seed": int(args.sample_seed),
        "train_count": len(split_info["train_full_ids"]),
        "train_total_count": len(split_info["train_full_ids"]),
        "train_subset_count": len(split_info["train_subset_ids"]),
        "eval_count": len(split_info["eval_ids"]),
        "eval_total_count": len(split_info["eval_ids"]),
        "eval_effective_count": len(split_info["eval_ids"]),
        "test_count": len(split_info["test_ids"]),
        "train_subset_file": str(split_info["train_subset_out"]),
        "eval_file": str(split_info["eval_out"]),
        "test_file": str(split_info["test_out"]),
        "initialization_mode": args.initialization_mode,
        "pretrained_backbone": args.pretrained_backbone,
        "pretrained_source_run_dir": getattr(
            args, "pretrained_source_run_dir", None
        ),
        "pretrained_source_run_name": getattr(
            args, "pretrained_source_run_name", None
        ),
        "pretrained_backbone_filename": pretrained_backbone_filename,
        "pretrain_info_json": str(run_dir / "pretrain_info.json"),
        "quality_stat_path": args.quality_stat_path,
        "split_protocol": SPLIT_PROTOCOL,
        "input_protocol": INPUT_PROTOCOL,
        "backbone_architecture": "BRepPhysicalMessageBackbone",
        "backbone_checkpoint_format": BACKBONE_CHECKPOINT_FORMAT,
        "finetune_checkpoint_format": FINETUNE_CHECKPOINT_FORMAT,
        "graph_storage_protocol": FORMAL_GRAPH_STORAGE_PROTOCOL,
        "graph_runtime_protocol": FORMAL_GRAPH_RUNTIME_PROTOCOL,
        "train_subset_ids_sha256": sha256_part_ids(
            split_info["train_subset_ids"]
        ),
        "freeze_backbone_epochs": int(args.freeze_backbone_epochs),
        "backbone_lr": float(args.backbone_lr),
        "head_lr": float(args.head_lr),
        "weight_decay": float(args.weight_decay),
        "amp": bool(args.amp),
        "eval_every": int(args.eval_every),
        "save_last_every": int(args.save_last_every),
        "quality_drop": float(args.quality_drop),
        "semantic_fusion_mode": args.semantic_fusion_mode,
        "semantic_fusion_direction": args.semantic_fusion_direction,
        "semantic_fusion_input": args.semantic_fusion_input,
        "semantic_fusion_adaptation": args.semantic_fusion_adaptation,
        "semantic_fusion_output": args.semantic_fusion_output,
        "semantic_fusion_affects_instance_head": bool(
            args.semantic_fusion_affects_instance_head
        ),
        "semantic_fusion_affects_process_head": bool(
            args.semantic_fusion_affects_process_head
        ),
        "process_branch": args.process_branch,
        "process_backpropagates_to_backbone": bool(
            args.process_backpropagates_to_backbone
        ),
        "best_epoch": -1,
        "best_metric_name": BEST_METRIC_NAME,
        "best_segmentation_score": None,
        "best_semantic_iou": None,
        "best_instance_pair_iou": None,
        "best_process_iou": None,
        "best_eval_loss": None,
        "best_checkpoint_path": str(dirs["checkpoints"] / "best.pth"),
        "last_checkpoint_path": str(dirs["checkpoints"] / "last.pth"),
        "final_test_metrics_path": str(dirs["metrics"] / "final_test_metrics.json"),
        "epoch_metrics_csv": str(epoch_metrics_csv),
        "final_test_metrics_csv": str(final_test_metrics_csv),
        "metrics_schema_json": str(metrics_schema_json),
        "final_test_metrics": None,
        "status": "running",
        "created_time": created_time,
        "finished_time": None,
        "config_json": str(run_dir / "config.json"),
        "command_txt": str(command_txt),
        "env_json": str(env_json),
        "source_manifest_json": str(source_manifest_json),
        "train_log_jsonl": str(dirs["logs"] / "train_log.jsonl"),
        "eval_log_jsonl": str(dirs["logs"] / "eval_log.jsonl"),
        "log_txt": str(dirs["logs"] / "log.txt"),
        "sample_info_json": str(split_info["sample_info_file"]),
    }
    write_json(run_dir / "summary.json", summary)

    config = {
        **vars(args),
        "run_dir": str(run_dir),
        "percent_tag": args.percent_tag,
        "train_total_count": len(split_info["train_full_ids"]),
        "train_subset_count": len(split_info["train_subset_ids"]),
        "eval_count": len(split_info["eval_ids"]),
        "eval_total_count": len(split_info["eval_ids"]),
        "eval_effective_count": len(split_info["eval_ids"]),
        "test_count": len(split_info["test_ids"]),
        "initialization_mode": args.initialization_mode,
        "pretrained_backbone": args.pretrained_backbone,
        "pretrained_source_run_dir": getattr(
            args, "pretrained_source_run_dir", None
        ),
        "pretrained_source_run_name": getattr(
            args, "pretrained_source_run_name", None
        ),
        "pretrained_backbone_filename": pretrained_backbone_filename,
        "quality_stat_path": args.quality_stat_path,
    }
    write_json(run_dir / "config.json", config)

    logger = init_logger(str(dirs["logs"] / "log.txt"))
    log_torch_device_info(logger, args.device)

    try:
        logger.info("device request: {}".format(args.device))
        logger.info("dataset_root: {}".format(args.dataset_root))
        logger.info("quality_stat_path: {}".format(args.quality_stat_path))
        logger.info("output_dir: {}".format(run_dir))
        logger.info("percent_tag: {}".format(args.percent_tag))
        logger.info("train_percent: {}".format(args.train_percent))
        logger.info("sample_seed: {}".format(args.sample_seed))
        logger.info("train_total_count: {}".format(len(split_info["train_full_ids"])))
        logger.info("train_subset_count: {}".format(len(split_info["train_subset_ids"])))
        logger.info("eval_total_count: {}".format(len(split_info["eval_ids"])))
        logger.info("eval_effective_count: {}".format(len(split_info["eval_ids"])))
        logger.info("eval.txt is copied and evaluated in full.")
        logger.info("Initialization mode: {}".format(args.initialization_mode))
        logger.info("pretrained_backbone: {}".format(args.pretrained_backbone))
        logger.info(
            "pretrained_source_run_dir: {}".format(
                args.pretrained_source_run_dir
            )
        )
        logger.info("pretrained_strict: {}".format(args.pretrained_strict))
        logger.info("input_protocol: {}".format(INPUT_PROTOCOL))
        logger.info(
            "backbone_architecture: BRepPhysicalMessageBackbone"
        )
        logger.info(
            "backbone_checkpoint_format: {}".format(
                BACKBONE_CHECKPOINT_FORMAT
            )
        )
        logger.info(
            "finetune_checkpoint_format: {}".format(
                FINETUNE_CHECKPOINT_FORMAT
            )
        )
        logger.info("freeze_backbone_epochs: {}".format(args.freeze_backbone_epochs))
        logger.info("backbone_lr: {}".format(args.backbone_lr))
        logger.info("head_lr: {}".format(args.head_lr))
        logger.info("weight_decay: {}".format(args.weight_decay))
        logger.info("amp: {}".format(args.amp))
        logger.info("eval_every: {}".format(args.eval_every))
        logger.info("save_last_every: {}".format(args.save_last_every))
        logger.info("process_branch: {}".format(args.process_branch))
        logger.info("process_input: {}".format(args.process_input))
        logger.info(
            "process_backpropagates_to_backbone: {}".format(
                args.process_backpropagates_to_backbone
            )
        )
        logger.info("loss_weights: {}".format(args.loss_weights))
        logger.info("head_hidden_dim: {}".format(args.head_hidden_dim))
        logger.info("task_adapter_hidden_dim: {}".format(args.task_adapter_hidden_dim))
        logger.info("semantic_fusion_mode: {}".format(args.semantic_fusion_mode))
        logger.info(
            "semantic_fusion_direction: {}".format(args.semantic_fusion_direction)
        )
        logger.info("semantic_fusion_input: {}".format(args.semantic_fusion_input))
        logger.info(
            "semantic_fusion_adaptation: {}".format(
                args.semantic_fusion_adaptation
            )
        )
        logger.info("semantic_fusion_output: {}".format(args.semantic_fusion_output))
        logger.info(
            "semantic_fusion_affects_instance_head: {}".format(
                args.semantic_fusion_affects_instance_head
            )
        )
        logger.info(
            "semantic_fusion_affects_process_head: {}".format(
                args.semantic_fusion_affects_process_head
            )
        )
        logger.info("quality_hidden_dim: {}".format(args.quality_hidden_dim))
        logger.info("process_head_depth: {}".format(args.process_head_depth))

        torch.set_float32_matmul_precision("high")
        seed_torch(args.seed)
        device = make_device(args.device)
        pin_memory = device.type == "cuda"
        logger.info("device: {}".format(device))

        dataset = args.dataset_root
        dataset_type = "tiny"
        n_classes = 13
        model = build_model(args, n_classes)
        logger.info(
            "backbone_order: BRepGeometryEncoder -> IBA-DMP -> "
            "Directed DHD-GP -> GATv2-ARL -> pooling"
        )
        logger.info(
            "Loading pretrained backbone from: {}".format(
                args.pretrained_backbone
            )
        )
        load_info = model.load_pretrained_backbone(
            args.pretrained_backbone,
            strict=True,
        )
        logger.info("Pretrained backbone load info: {}".format(load_info))

        model = model.to(device)
        logger.info("total_params: {}".format(model.count_total_parameters()))
        logger.info("trainable_params_initial: {}".format(model.count_trainable_parameters()))

        graph_store = BRepCompactGraphStore(
            dataset,
            normalize=True,
        )
        train_ids = graph_store.resolve_part_ids(
            split=args.train_split,
            filelist_override=split_info["train_subset_ids"],
        )
        eval_ids = graph_store.resolve_part_ids(split=args.eval_split)
        test_ids = graph_store.resolve_part_ids(split=args.test_split)
        graph_store.ensure_loaded(train_ids + eval_ids)
        logger.info("graph_store_loaded_before_dataloader=True")
        logger.info(
            "requested_graph_count_before_training: {}".format(
                len(train_ids) + len(eval_ids)
            )
        )
        logger.info(
            "loaded_graph_count_before_training: {}".format(
                graph_store.loaded_graph_count
            )
        )
        logger.info(
            "graph_construction_count_before_training: {}".format(
                graph_store.graph_construction_count
            )
        )
        logger.info(
            "estimated_compact_tensor_bytes_before_training: {}".format(
                graph_store.estimated_tensor_bytes
            )
        )
        logger.info(
            "stream_scan_count_before_training: {}".format(
                graph_store.stream_scan_count
            )
        )
        process_memory = read_linux_process_memory_kib()
        if process_memory is None:
            logger.info("process_memory_status: unavailable")
        else:
            logger.info("process_memory_kib_before_training: {}".format(process_memory))

        train_dataset = MFInstSegPhysicalMessageDataset(
            root_dir=dataset,
            split=args.train_split,
            dataset_type=dataset_type,
            quality_stat_path=args.quality_stat_path,
            filelist_override=split_info["train_subset_ids"],
            normalize=True,
            random_rotate=False,
            center_and_scale=False,
            graph_store=graph_store,
        )
        logger.info("train_dataset_split: train_subset (sampled from train.txt)")
        eval_dataset = MFInstSegPhysicalMessageDataset(
            root_dir=dataset,
            split=args.eval_split,
            dataset_type=dataset_type,
            quality_stat_path=args.quality_stat_path,
            filelist_override=None,
            normalize=True,
            random_rotate=False,
            center_and_scale=False,
            graph_store=graph_store,
        )
        logger.info(
            "eval_dataset_split: eval (validation uses {} eval samples from eval.txt)".format(
                len(split_info["eval_ids"])
            )
        )
        train_loader = train_dataset.get_dataloader(
            batch_size=args.batch_size,
            shuffle=True,
            drop_last=False,
            num_workers=args.num_workers,
            pin_memory=pin_memory,
        )
        eval_loader = eval_dataset.get_dataloader(
            batch_size=args.batch_size,
            shuffle=False,
            drop_last=False,
            num_workers=args.num_workers,
            pin_memory=pin_memory,
        )
        if len(train_loader) == 0:
            raise RuntimeError("train_loader is empty. Check batch_size and train_subset.")

        seg_loss = nn.CrossEntropyLoss()
        instance_loss = nn.BCEWithLogitsLoss(reduction="none")
        process_loss = nn.CrossEntropyLoss(ignore_index=-1)
        opt = torch.optim.AdamW(
            [
                {
                    "params": list(model.backbone_parameters()),
                    "lr": args.backbone_lr,
                    "name": "backbone",
                },
                {
                    "params": list(model.non_backbone_parameters()),
                    "lr": args.head_lr,
                    "name": "heads",
                },
            ],
            weight_decay=args.weight_decay,
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            opt, T_max=args.epochs, eta_min=0
        )
        scaler = torch.cuda.amp.GradScaler(enabled=args.amp)
        logger.info("optimizer_param_group_lrs: {}".format(get_param_group_lrs(opt)))

        train_metrics = make_metric_bundle(n_classes, device)
        epoch_eval_metrics_bundle = make_metric_bundle(n_classes, device)
        final_test_metrics_bundle = make_metric_bundle(n_classes, device)

        ema_decay = (1.0 / 2.0) ** (1 / len(train_loader))
        logger.info("EMA decay: {}".format(ema_decay))
        ema = ExponentialMovingAverage(model.parameters(), decay=ema_decay)

        best_candidate = None
        best_model_path = dirs["checkpoints"] / "best.pth"
        last_model_path = dirs["checkpoints"] / "last.pth"
        best_epoch = -1
        last_train_loss = None
        last_eval_loss = None
        loss_weights = args.loss_weights

        for epoch_idx in range(args.epochs):
            epoch = epoch_idx + 1
            epoch_start = time.time()
            reset_gpu_peak_memory(device)
            model.train()
            backbone_frozen = set_backbone_freeze_for_epoch(
                model, epoch, args.freeze_backbone_epochs
            )
            reset_metrics(train_metrics)
            train_loss_sums = {
                "total": 0.0,
                "semantic": 0.0,
                "instance": 0.0,
                "process": 0.0,
            }
            train_loss_batch_count = 0
            train_start = time.time()
            train_bar = tqdm(
                train_loader,
                desc="train epoch {}/{}".format(epoch, args.epochs),
            )
            for data in train_bar:
                batch = move_brep_supervised_model_input_batch(
                    data,
                    device,
                    non_blocking=True,
                )
                seg_label = batch.seg_y
                inst_label = batch.inst_labels
                inst_mask = batch.inst_masks.bool()
                process_label = batch.process_y

                opt.zero_grad(set_to_none=True)

                with torch.cuda.amp.autocast(enabled=args.amp):
                    seg_pred, inst_pred, process_pred = model(batch)
                    assert process_pred.dim() == 2
                    assert process_pred.shape[1] == 2
                    assert process_label.dim() == 1
                    assert process_pred.shape[0] == process_label.shape[0]

                    loss_seg = seg_loss(seg_pred, seg_label)
                    loss_inst = compute_masked_instance_loss(
                        instance_loss,
                        inst_pred,
                        inst_label,
                        inst_mask.float(),
                    )
                    loss_process = compute_process_loss(
                        process_loss,
                        process_pred,
                        process_label,
                    )
                    loss = (
                        loss_weights["semantic"] * loss_seg
                        + loss_weights["instance"] * loss_inst
                        + loss_weights["process"] * loss_process
                    )
                train_loss_sums["total"] += float(
                    loss.detach().float().cpu()
                )
                train_loss_sums["semantic"] += float(
                    loss_seg.detach().float().cpu()
                )
                train_loss_sums["instance"] += float(
                    loss_inst.detach().float().cpu()
                )
                train_loss_sums["process"] += float(
                    loss_process.detach().float().cpu()
                )
                train_loss_batch_count += 1

                train_bar.set_postfix(
                    loss="{:.6f}".format(loss.item())
                )

                scaler.scale(loss).backward()
                scaler.step(opt)
                scaler.update()
                ema.update()

                update_all_metrics(
                    train_metrics,
                    seg_pred,
                    seg_label,
                    inst_pred,
                    inst_label,
                    inst_mask,
                    process_pred,
                    process_label,
                )
                del (
                    loss,
                    loss_seg,
                    loss_inst,
                    loss_process,
                    seg_pred,
                    inst_pred,
                    process_pred,
                    seg_label,
                    inst_label,
                    inst_mask,
                    process_label,
                    batch,
                )

            scheduler.step()
            train_time_sec = time.time() - train_start
            epoch_lrs = get_param_group_lrs(opt)
            train_metric_values = compute_metric_values(train_metrics, "train")
            train_log = {
                "epoch": epoch,
                "split": "train_subset",
                "train_percent": float(args.train_percent),
                "sample_count": len(split_info["train_subset_ids"]),
                "num_batches": len(train_loader),
                "loss_total": (
                    train_loss_sums["total"]
                    / max(train_loss_batch_count, 1)
                ),
                "semantic_loss": (
                    train_loss_sums["semantic"]
                    / max(train_loss_batch_count, 1)
                ),
                "instance_loss": (
                    train_loss_sums["instance"]
                    / max(train_loss_batch_count, 1)
                ),
                "process_loss": (
                    train_loss_sums["process"]
                    / max(train_loss_batch_count, 1)
                ),
                "learning_rates": epoch_lrs,
                "time_sec": train_time_sec,
                **train_metric_values,
                **gpu_peak_memory(device),
            }
            last_train_loss = train_log["loss_total"]
            append_jsonl(dirs["logs"] / "train_log.jsonl", train_log)
            should_eval = (epoch % args.eval_every == 0) or (epoch == args.epochs)
            eval_log = None
            cur_metric = None
            is_best = False
            if should_eval:
                eval_start = time.time()
                reset_gpu_peak_memory(device)
                with ema.average_parameters():
                    eval_metrics = run_eval(
                        model,
                        eval_loader,
                        epoch_eval_metrics_bundle,
                        seg_loss,
                        instance_loss,
                        process_loss,
                        device,
                        loss_weights,
                    )
                eval_time_sec = time.time() - eval_start
                candidate = make_best_candidate(eval_metrics, epoch)
                cur_metric = candidate["segmentation_score"]
                is_best = is_better_finetune_candidate(
                    candidate,
                    best_candidate,
                )
                if is_best:
                    best_candidate = candidate
                    best_epoch = epoch
                    with ema.average_parameters():
                        best_payload = build_best_finetune_checkpoint(
                            model,
                            args,
                            split_info,
                            epoch,
                            candidate,
                        )
                        torch.save(best_payload, best_model_path)
                        del best_payload

                best_metric_for_log = (
                    None if best_candidate is None else float(
                        best_candidate["segmentation_score"]
                    )
                )
                eval_log = {
                    "epoch": epoch,
                    "split": "eval",
                    "eval_count": len(split_info["eval_ids"]),
                    "eval_total_count": len(split_info["eval_ids"]),
                    "eval_effective_count": len(split_info["eval_ids"]),
                    "num_batches": len(eval_loader),
                    "loss_total": eval_metrics["loss_total"],
                    "semantic_loss": eval_metrics["semantic_loss"],
                    "instance_loss": eval_metrics["instance_loss"],
                    "process_loss": eval_metrics["process_loss"],
                    "best_so_far": best_metric_for_log,
                    "best_epoch": best_epoch,
                    "is_best": is_best,
                    "time_sec": eval_time_sec,
                    **gpu_peak_memory(device),
                    **{
                        key: value
                        for key, value in eval_metrics.items()
                        if key.startswith("eval_")
                    },
                }
                last_eval_loss = eval_log["loss_total"]

            should_save_last = (
                epoch % args.save_last_every == 0
            ) or (epoch == args.epochs)
            if should_save_last:
                last_payload = build_last_finetune_checkpoint(
                    model,
                    opt,
                    scheduler,
                    scaler,
                    ema,
                    args,
                    split_info,
                    epoch,
                    best_candidate,
                )
                torch.save(last_payload, last_model_path)
                del last_payload

            best_metric_for_log = (
                None if best_candidate is None else float(
                    best_candidate["segmentation_score"]
                )
            )
            append_csv_row(
                epoch_metrics_csv,
                EPOCH_METRICS_FIELDS,
                {
                    "epoch": epoch,
                    "split": "train",
                    "train_percent": float(args.train_percent),
                    "sample_count": len(split_info["train_subset_ids"]),
                    "num_batches": len(train_loader),
                    "loss_total": train_log["loss_total"],
                    "semantic_loss": train_log["semantic_loss"],
                    "instance_loss": train_log["instance_loss"],
                    "process_loss": train_log["process_loss"],
                    "semantic_acc": train_log["train_seg_acc"],
                    "semantic_iou": train_log["train_seg_iou"],
                    "instance_pair_acc": train_log["train_inst_pair_acc"],
                    "instance_pair_precision": train_log[
                        "train_inst_pair_precision"
                    ],
                    "instance_pair_recall": train_log[
                        "train_inst_pair_recall"
                    ],
                    "instance_pair_f1": train_log["train_inst_pair_f1"],
                    "instance_pair_iou": train_log["train_inst_pair_iou"],
                    "instance_cluster_iou": None,
                    "instance_cluster_iou_matched": None,
                    "process_acc": train_log["train_process_acc"],
                    "process_iou": train_log["train_process_iou"],
                    "best_metric": None if cur_metric is None else float(cur_metric),
                    "best_so_far": best_metric_for_log,
                    "best_epoch": best_epoch,
                    "is_best": is_best,
                    "time_sec": train_time_sec,
                    "backbone_lr": epoch_lrs["backbone"],
                    "head_lr": epoch_lrs["heads"],
                },
            )
            if eval_log is not None:
                append_csv_row(
                    epoch_metrics_csv,
                    EPOCH_METRICS_FIELDS,
                    {
                        "epoch": epoch,
                        "split": "eval",
                        "train_percent": float(args.train_percent),
                        "sample_count": len(split_info["eval_ids"]),
                        "num_batches": len(eval_loader),
                        "loss_total": eval_log["loss_total"],
                        "semantic_loss": eval_log["semantic_loss"],
                        "instance_loss": eval_log["instance_loss"],
                        "process_loss": eval_log["process_loss"],
                        "semantic_acc": eval_log["eval_seg_acc"],
                        "semantic_iou": eval_log["eval_seg_iou"],
                        "instance_pair_acc": eval_log["eval_inst_pair_acc"],
                        "instance_pair_precision": eval_log[
                            "eval_inst_pair_precision"
                        ],
                        "instance_pair_recall": eval_log[
                            "eval_inst_pair_recall"
                        ],
                        "instance_pair_f1": eval_log["eval_inst_pair_f1"],
                        "instance_pair_iou": eval_log["eval_inst_pair_iou"],
                        "instance_cluster_iou": eval_log[
                            "eval_inst_cluster_iou"
                        ],
                        "instance_cluster_iou_matched": eval_log[
                            "eval_inst_cluster_iou_matched"
                        ],
                        "process_acc": eval_log["eval_process_acc"],
                        "process_iou": eval_log["eval_process_iou"],
                        "best_metric": float(cur_metric),
                        "best_so_far": best_metric_for_log,
                        "best_epoch": best_epoch,
                        "is_best": is_best,
                        "time_sec": eval_time_sec,
                        "backbone_lr": epoch_lrs["backbone"],
                        "head_lr": epoch_lrs["heads"],
                    },
                )
                append_jsonl(dirs["logs"] / "eval_log.jsonl", eval_log)

            eval_text = (
                "eval=skipped"
                if eval_log is None
                else (
                    "eval_seg_iou={:.6f} eval_inst_pair_iou={:.6f} "
                    "eval_proc_iou={:.6f}"
                ).format(
                    eval_log["eval_seg_iou"],
                    eval_log["eval_inst_pair_iou"],
                    eval_log["eval_process_iou"],
                )
            )
            best_text = (
                "n/a"
                if best_metric_for_log is None
                else "{:.6f}".format(best_metric_for_log)
            )
            epoch_time_sec = time.time() - epoch_start
            logger.info(
                "[Epoch {epoch:03d}] train_loss={loss:.6f} seg={seg:.6f} "
                "inst={inst:.6f} proc={proc:.6f} "
                "train_seg_iou={train_seg_iou:.6f} "
                "train_inst_f1={train_inst_f1:.6f} "
                "train_proc_iou={train_proc_iou:.6f} {eval_text} "
                "best={best} backbone_lr={backbone_lr:.8f} "
                "head_lr={head_lr:.8f} time={time:.1f}s".format(
                    epoch=epoch,
                    loss=train_log["loss_total"],
                    seg=train_log["semantic_loss"],
                    inst=train_log["instance_loss"],
                    proc=train_log["process_loss"],
                    train_seg_iou=train_log["train_seg_iou"],
                    train_inst_f1=train_log["train_inst_f1"],
                    train_proc_iou=train_log["train_process_iou"],
                    eval_text=eval_text,
                    best=best_text,
                    backbone_lr=epoch_lrs["backbone"],
                    head_lr=epoch_lrs["heads"],
                    time=epoch_time_sec,
                )
            )

            summary.update(
                {
                    "best_epoch": best_epoch,
                    "best_segmentation_score": best_metric_for_log,
                    "best_semantic_iou": (
                        None
                        if best_candidate is None
                        else best_candidate["semantic_iou"]
                    ),
                    "best_instance_pair_iou": (
                        None
                        if best_candidate is None
                        else best_candidate["instance_pair_iou"]
                    ),
                    "best_process_iou": (
                        None
                        if best_candidate is None
                        else best_candidate["process_iou"]
                    ),
                    "best_eval_loss": (
                        None
                        if best_candidate is None
                        else best_candidate["eval_loss"]
                    ),
                    "last_epoch": epoch,
                    "last_train_loss": last_train_loss,
                    "last_eval_loss": last_eval_loss,
                    "last_epoch_time_sec": epoch_time_sec,
                    "status": "running",
                }
            )
            write_json(run_dir / "summary.json", summary)

        graph_store.ensure_loaded(test_ids)
        logger.info(
            "loaded_graph_count_with_test: {}".format(
                graph_store.loaded_graph_count
            )
        )
        logger.info(
            "graph_construction_count_with_test: {}".format(
                graph_store.graph_construction_count
            )
        )
        logger.info(
            "estimated_compact_tensor_bytes_with_test: {}".format(
                graph_store.estimated_tensor_bytes
            )
        )
        logger.info(
            "stream_scan_count_with_test: {}".format(
                graph_store.stream_scan_count
            )
        )
        final_test_dataset = MFInstSegPhysicalMessageDataset(
            root_dir=dataset,
            split=args.test_split,
            dataset_type=dataset_type,
            quality_stat_path=args.quality_stat_path,
            filelist_override=None,
            normalize=True,
            random_rotate=False,
            center_and_scale=False,
            graph_store=graph_store,
        )
        logger.info(
            "final_test_dataset_split: test (one-time final evaluation uses "
            "all {} samples from test.txt)".format(
                len(split_info["test_ids"])
            )
        )
        final_test_loader = final_test_dataset.get_dataloader(
            batch_size=args.batch_size,
            shuffle=False,
            drop_last=False,
            num_workers=args.num_workers,
            pin_memory=pin_memory,
        )

        if not best_model_path.is_file():
            raise FileNotFoundError(
                "Best checkpoint is required for one-time final test: {}".format(
                    best_model_path
                )
            )
        logger.info("Loading best checkpoint for final test: {}".format(best_model_path))
        best_payload = torch.load(best_model_path, map_location="cpu")
        validate_finetune_checkpoint(
            best_payload,
            expected_role="best",
        )
        model.load_state_dict(
            best_payload["model_state_dict"],
            strict=True,
        )
        del best_payload
        logger.info("final_test_checkpoint: {}".format(best_model_path))
        logger.info("------------- Now start final_test on test.txt -------------")
        final_confusion_matrices = {
            "semantic": make_confusion_matrix(n_classes),
            "process": make_confusion_matrix(2),
        }
        final_test_metrics = run_eval(
            model,
            final_test_loader,
            final_test_metrics_bundle,
            seg_loss,
            instance_loss,
            process_loss,
            device,
            loss_weights,
            use_autocast=args.amp,
            metric_prefix="test",
            detailed_confusion_matrices=final_confusion_matrices,
        )
        semantic_report = classification_metrics_from_confusion(
            final_confusion_matrices["semantic"],
            TINY_CLASS_NAMES,
        )
        process_class_names = ("rough", "finish")
        process_report = classification_metrics_from_confusion(
            final_confusion_matrices["process"],
            process_class_names,
        )
        instance_counts = final_test_metrics_bundle["inst_pair_counts"]
        instance_confusion_matrix = instance_confusion_matrix_from_counts(
            tp=instance_counts["tp"],
            fp=instance_counts["fp"],
            fn=instance_counts["fn"],
            tn=instance_counts["tn"],
        )
        final_test_metrics_out = {
            "split": "test",
            "initialization_mode": args.initialization_mode,
            "test_count": len(split_info["test_ids"]),
            "checkpoint_path": str(best_model_path),
            **final_test_metrics,
            "semantic_macro_precision": semantic_report["macro_precision"],
            "semantic_macro_recall": semantic_report["macro_recall"],
            "semantic_macro_f1": semantic_report["macro_f1"],
            "instance_pair_tn": int(instance_counts["tn"]),
            "instance_pair_fp": int(instance_counts["fp"]),
            "instance_pair_fn": int(instance_counts["fn"]),
            "instance_pair_tp": int(instance_counts["tp"]),
            "process_macro_precision": process_report["macro_precision"],
            "process_macro_recall": process_report["macro_recall"],
            "process_macro_f1": process_report["macro_f1"],
        }

        semantic_details = {
            "acc": float(final_test_metrics["test_seg_acc"]),
            "miou": float(final_test_metrics["test_seg_iou"]),
            **semantic_report,
        }
        instance_details = {
            "acc": float(final_test_metrics["test_inst_pair_acc"]),
            "miou": float(final_test_metrics["test_inst_pair_iou"]),
            "precision": float(final_test_metrics["test_inst_pair_precision"]),
            "recall": float(final_test_metrics["test_inst_pair_recall"]),
            "f1": float(final_test_metrics["test_inst_pair_f1"]),
            "iou": float(final_test_metrics["test_inst_pair_iou"]),
            "tn": int(instance_counts["tn"]),
            "fp": int(instance_counts["fp"]),
            "fn": int(instance_counts["fn"]),
            "tp": int(instance_counts["tp"]),
            "confusion_matrix": instance_confusion_matrix.tolist(),
        }
        process_details = {
            "acc": float(final_test_metrics["test_process_acc"]),
            "miou": float(final_test_metrics["test_process_iou"]),
            **process_report,
        }

        semantic_confusion_csv = (
            dirs["metrics"] / "semantic_confusion_matrix.csv"
        )
        semantic_confusion_png = (
            dirs["metrics"] / "semantic_confusion_matrix.png"
        )
        instance_confusion_csv = (
            dirs["metrics"] / "instance_confusion_matrix.csv"
        )
        instance_confusion_png = (
            dirs["metrics"] / "instance_confusion_matrix.png"
        )
        process_confusion_csv = (
            dirs["metrics"] / "process_confusion_matrix.csv"
        )
        process_confusion_png = (
            dirs["metrics"] / "process_confusion_matrix.png"
        )
        per_class_metrics_csv = (
            dirs["metrics"] / "final_test_per_class_metrics.csv"
        )

        write_confusion_matrix_csv(
            semantic_confusion_csv,
            final_confusion_matrices["semantic"],
            TINY_CLASS_NAMES,
        )
        write_confusion_matrix_csv(
            instance_confusion_csv,
            instance_confusion_matrix,
            ("different_instance", "same_instance"),
        )
        write_confusion_matrix_csv(
            process_confusion_csv,
            final_confusion_matrices["process"],
            process_class_names,
        )
        write_per_class_metrics_csv(
            per_class_metrics_csv,
            {
                "semantic": semantic_report,
                "process": process_report,
            },
        )
        png_saved = {
            "semantic": write_confusion_matrix_png(
                semantic_confusion_png,
                final_confusion_matrices["semantic"],
                TINY_CLASS_NAMES,
                title="Semantic Confusion Matrix (Counts)",
            ),
            "instance": write_confusion_matrix_png(
                instance_confusion_png,
                instance_confusion_matrix,
                ("different_instance", "same_instance"),
                title="Instance Pair Confusion Matrix (Counts)",
            ),
            "process": write_confusion_matrix_png(
                process_confusion_png,
                final_confusion_matrices["process"],
                process_class_names,
                title="Process Confusion Matrix (Counts)",
            ),
        }
        unavailable_png = [
            task_name for task_name, saved in png_saved.items() if not saved
        ]
        if unavailable_png:
            logger.warning(
                "matplotlib is unavailable; confusion PNG not saved for: {}".format(
                    ", ".join(unavailable_png)
                )
            )

        final_test_metrics_path = dirs["metrics"] / "final_test_metrics.json"
        final_test_metrics_json = {
            **final_test_metrics_out,
            "semantic": semantic_details,
            "instance": instance_details,
            "process": process_details,
            "artifacts": {
                "per_class_metrics_csv": str(per_class_metrics_csv),
                "semantic_confusion_matrix_csv": str(semantic_confusion_csv),
                "semantic_confusion_matrix_png": (
                    str(semantic_confusion_png) if png_saved["semantic"] else None
                ),
                "instance_confusion_matrix_csv": str(instance_confusion_csv),
                "instance_confusion_matrix_png": (
                    str(instance_confusion_png) if png_saved["instance"] else None
                ),
                "process_confusion_matrix_csv": str(process_confusion_csv),
                "process_confusion_matrix_png": (
                    str(process_confusion_png) if png_saved["process"] else None
                ),
            },
        }
        write_json(final_test_metrics_path, final_test_metrics_json)
        write_single_row_csv(final_test_metrics_csv, final_test_metrics_out)
        logger.info(
            "final_test_loss: {loss_total}, final_test_process_loss: {process_loss}, "
            "final_test_seg_acc: {test_seg_acc}, final_test_seg_iou: {test_seg_iou}, "
            "final_test_inst_pair_f1: {test_inst_pair_f1}, "
            "final_test_inst_pair_iou: {test_inst_pair_iou}, "
            "final_test_process_acc: {test_process_acc}, "
            "final_test_process_iou: {test_process_iou}".format(
                **final_test_metrics_out
            )
        )

        summary.update(
            {
                "best_epoch": best_epoch,
                "best_segmentation_score": float(
                    best_candidate["segmentation_score"]
                ),
                "best_semantic_iou": float(
                    best_candidate["semantic_iou"]
                ),
                "best_instance_pair_iou": float(
                    best_candidate["instance_pair_iou"]
                ),
                "best_process_iou": float(
                    best_candidate["process_iou"]
                ),
                "best_eval_loss": float(best_candidate["eval_loss"]),
                "last_checkpoint_path": str(last_model_path),
                "best_checkpoint_path": str(best_model_path),
                "final_test_metrics_path": str(final_test_metrics_path),
                "final_test_metrics_csv": str(final_test_metrics_csv),
                "final_test_metrics": final_test_metrics_out,
                "test_count": len(split_info["test_ids"]),
                "status": "complete",
                "finished_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
            }
        )
        write_json(run_dir / "summary.json", summary)

    except Exception as exc:
        summary.update(
            {
                "status": "failed",
                "error": str(exc),
                "finished_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
            }
        )
        write_json(run_dir / "summary.json", summary)
        raise


if __name__ == "__main__":
    main()
