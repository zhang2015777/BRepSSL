







from copy import deepcopy
from dataclasses import dataclass, replace
from functools import partial
from pathlib import Path
import json

import dgl
import torch
from torch.utils.data import Dataset, DataLoader

from models.graph_masking import (
    BATCH_TOPOLOGY_CACHE_ATTR,
    SINGLE_TOPOLOGY_CACHE_ATTR,
    build_batch_topology_cache,
    build_single_graph_topology_cache,
)
from utils.brep_data_io import (
    FORMAL_SPLIT_PROTOCOL,
    load_attr_statistics,
    load_one_graph,
    load_uv_statistics,
)
from utils.brep_model_input_view import (
    BRepModelInputStatistics,
    BRepModelInputView,
    build_brep_model_input_view,
    pin_brep_model_input_view,
    resolve_brep_model_input_statistics,
    validate_brep_model_input_device,
)
from utils.graph_json_stream import iter_graph_records, sha256_part_ids


SUPERVISED_GRAPH_KEYS = (
    "quality",
    "process_y",
    "seg_y",
    "bottom_y",
    "inst_y",
)

REQUIRED_GRAPH_KEYS = (
    "graph",
    "graph_face_attr",
    "graph_edge_attr",
    "graph_face_grid",
    "graph_edge_grid",
    "graph_edge_face_uv",
    "graph_edge_face_uv_valid",
)


def validate_brep_pretrain_filelist_override(
    split,
    filelist_override,
    formal_train_ids,
):
    
    if filelist_override is None:
        return None
    if split != "train":
        raise ValueError(
            "filelist_override is only supported for split='train'. "
            "eval and test must use their complete formal splits."
        )
    if isinstance(filelist_override, (str, bytes)):
        raise TypeError(
            "filelist_override must be a non-empty sequence of part IDs, "
            "not a single string"
        )
    try:
        values = list(filelist_override)
    except TypeError as exc:
        raise TypeError(
            "filelist_override must be a non-empty sequence of strings"
        ) from exc
    if not values:
        raise ValueError("filelist_override must be non-empty")
    if any(not isinstance(value, str) or not value.strip() for value in values):
        raise TypeError(
            "filelist_override entries must be non-empty strings"
        )
    values = [value.strip() for value in values]
    if len(values) != len(set(values)):
        raise ValueError("filelist_override must contain unique part IDs")
    formal_train_ids = list(formal_train_ids)
    formal_train_set = set(formal_train_ids)
    unknown = [value for value in values if value not in formal_train_set]
    if unknown:
        raise ValueError(
            "filelist_override contains IDs outside the formal train split: "
            f"{unknown[:20]}"
        )
    return values


@dataclass(frozen=True)
class BRepPretrainModelInputSample:
    part_id: str
    physical_graph: dgl.DGLGraph

    def __post_init__(self):
        if not isinstance(self.part_id, str) or not self.part_id.strip():
            raise ValueError("part_id must be a non-empty string")
        if not isinstance(self.physical_graph, dgl.DGLGraph):
            raise TypeError("physical_graph must be a dgl.DGLGraph")


@dataclass(frozen=True)
class BRepPretrainModelInputBatch:
    part_ids: tuple[str, ...]
    physical_topology_graph: dgl.DGLGraph
    model_input: BRepModelInputView

    def pin_memory(self):
        return pin_brep_pretrain_model_input_batch(self)


def pin_brep_pretrain_model_input_batch(batch):
    
    if not isinstance(batch, BRepPretrainModelInputBatch):
        raise TypeError("batch must be a BRepPretrainModelInputBatch")
    topology = batch.physical_topology_graph
    if topology.device.type != "cpu":
        raise ValueError("Only CPU batches can be pinned")
    if not topology.is_pinned():
        topology.pin_memory_()
    return BRepPretrainModelInputBatch(
        part_ids=tuple(batch.part_ids),
        physical_topology_graph=topology,
        model_input=pin_brep_model_input_view(batch.model_input),
    )


def move_brep_pretrain_model_input_batch(
    batch,
    device,
    *,
    non_blocking=False,
):
    
    if not isinstance(batch, BRepPretrainModelInputBatch):
        raise TypeError("batch must be a BRepPretrainModelInputBatch")
    device = torch.device(device)
    topology = batch.physical_topology_graph
    if not isinstance(topology, dgl.DGLGraph):
        raise TypeError("physical_topology_graph must be a dgl.DGLGraph")
    cache = getattr(topology, BATCH_TOPOLOGY_CACHE_ATTR, None)
    if not isinstance(cache, (list, tuple)):
        raise ValueError("physical_topology_graph is missing its batch cache")
    moved_cache = deepcopy(cache)

    moved_topology = topology.to(device)
    moved_topology.set_batch_num_nodes(
        topology.batch_num_nodes().to(device=device)
    )
    moved_topology.set_batch_num_edges(
        topology.batch_num_edges().to(device=device)
    )
    setattr(
        moved_topology,
        BATCH_TOPOLOGY_CACHE_ATTR,
        moved_cache,
    )
    cached_nodes = [int(record["node_count"]) for record in moved_cache]
    cached_edges = [int(record["edge_count"]) for record in moved_cache]
    actual_nodes = [
        int(value)
        for value in moved_topology.batch_num_nodes().detach().cpu().tolist()
    ]
    actual_edges = [
        int(value)
        for value in moved_topology.batch_num_edges().detach().cpu().tolist()
    ]
    if cached_nodes != actual_nodes or cached_edges != actual_edges:
        raise ValueError(
            "Moved physical topology cache does not match graph batch metadata"
        )

    model_input = batch.model_input
    message_view = model_input.message_view
    moved_message_graph = message_view.message_graph.to(device)
    moved_message_graph.set_batch_num_nodes(
        message_view.message_graph.batch_num_nodes().to(device=device)
    )
    moved_message_graph.set_batch_num_edges(
        message_view.message_graph.batch_num_edges().to(device=device)
    )
    if len(moved_message_graph.ndata) or len(moved_message_graph.edata):
        raise ValueError("Moved message graph must remain an empty data container")

    def move_tensor(value):
        return value.to(
            device=device,
            non_blocking=non_blocking,
            copy=True,
        )

    moved_message_view = replace(
        message_view,
        message_graph=moved_message_graph,
        message_edge_attr=move_tensor(message_view.message_edge_attr),
        message_edge_grid=move_tensor(message_view.message_edge_grid),
        message_edge_face_uv=move_tensor(
            message_view.message_edge_face_uv
        ),
        message_edge_face_uv_valid=move_tensor(
            message_view.message_edge_face_uv_valid
        ),
        message_to_physical_edge=move_tensor(
            message_view.message_to_physical_edge
        ),
        message_is_reverse=move_tensor(message_view.message_is_reverse),
        message_is_self_loop=move_tensor(
            message_view.message_is_self_loop
        ),
        physical_to_forward_message=move_tensor(
            message_view.physical_to_forward_message
        ),
        physical_to_reverse_message=move_tensor(
            message_view.physical_to_reverse_message
        ),
    )
    moved_model_input = replace(
        model_input,
        node_attr=move_tensor(model_input.node_attr),
        node_grid=move_tensor(model_input.node_grid),
        message_view=moved_message_view,
        physical_batch_num_nodes=move_tensor(
            model_input.physical_batch_num_nodes
        ),
        physical_batch_num_edges=move_tensor(
            model_input.physical_batch_num_edges
        ),
    )
    if moved_model_input.physical_num_nodes != moved_topology.num_nodes():
        raise ValueError("Moved model input and topology node counts differ")
    if moved_model_input.physical_num_edges != moved_topology.num_edges():
        raise ValueError("Moved model input and topology edge counts differ")
    moved_batch = BRepPretrainModelInputBatch(
        part_ids=tuple(batch.part_ids),
        physical_topology_graph=moved_topology,
        model_input=moved_model_input,
    )
    if moved_batch.physical_topology_graph.device != device:
        raise ValueError("physical_topology_graph is not on the requested device")
    validate_brep_model_input_device(moved_batch.model_input, device)
    return moved_batch


def collate_brep_pretrain_model_input(batch, *, statistics):
    if not batch:
        raise ValueError("physical_message_v1 batch must be non-empty")
    if not isinstance(statistics, BRepModelInputStatistics):
        raise TypeError("statistics must be a BRepModelInputStatistics")

    part_ids = []
    raw_physical_graphs = []
    seen_part_ids = set()
    for item_index, sample in enumerate(batch):
        if not isinstance(sample, BRepPretrainModelInputSample):
            raise TypeError(
                "physical_message_v1 batch items must be "
                f"BRepPretrainModelInputSample, got {type(sample)} at "
                f"index {item_index}"
            )
        part_id = sample.part_id
        if part_id in seen_part_ids:
            raise ValueError(
                f"physical_message_v1 batch contains duplicate part_id {part_id!r}"
            )
        seen_part_ids.add(part_id)

        graph = sample.physical_graph
        BRepPretrainDataset._validate_graph(part_id, graph)
        BRepPretrainDataset._ensure_unlabeled_graph(part_id, graph)

        single_cache = getattr(graph, SINGLE_TOPOLOGY_CACHE_ATTR, None)
        if not isinstance(single_cache, dict):
            raise ValueError(
                f"Graph {part_id} is missing its single-graph physical "
                "topology cache."
            )
        cached_nodes = int(single_cache.get("num_nodes", -1))
        cached_edges = int(single_cache.get("num_edges", -1))
        if cached_nodes != graph.num_nodes():
            raise ValueError(
                f"Graph {part_id} topology cache node count {cached_nodes} "
                f"does not match physical graph node count {graph.num_nodes()}."
            )
        if cached_edges != graph.num_edges():
            raise ValueError(
                f"Graph {part_id} topology cache edge count {cached_edges} "
                f"does not match physical graph edge count {graph.num_edges()}."
            )

        part_ids.append(part_id)
        raw_physical_graphs.append(graph)

    batch_topology_cache = build_batch_topology_cache(raw_physical_graphs)
    cached_node_counts = [
        int(record["node_count"]) for record in batch_topology_cache
    ]
    cached_edge_counts = [
        int(record["edge_count"]) for record in batch_topology_cache
    ]
    expected_node_counts = [
        graph.num_nodes() for graph in raw_physical_graphs
    ]
    expected_edge_counts = [
        graph.num_edges() for graph in raw_physical_graphs
    ]
    if cached_node_counts != expected_node_counts:
        raise ValueError(
            "Batch topology cache node counts do not match the physical graphs: "
            f"cache={cached_node_counts}, graphs={expected_node_counts}"
        )
    if cached_edge_counts != expected_edge_counts:
        raise ValueError(
            "Batch topology cache edge counts do not match the physical graphs: "
            f"cache={cached_edge_counts}, graphs={expected_edge_counts}"
        )

    raw_batched_graph = dgl.batch(raw_physical_graphs)
    model_input = build_brep_model_input_view(
        raw_batched_graph,
        statistics,
        physical_graph_is_standardized=False,
    )

    physical_src, physical_dst = raw_batched_graph.edges(order="eid")
    physical_topology_graph = dgl.graph(
        (physical_src, physical_dst),
        num_nodes=raw_batched_graph.num_nodes(),
        idtype=raw_batched_graph.idtype,
        device=raw_batched_graph.device,
    )
    physical_topology_graph.set_batch_num_nodes(
        raw_batched_graph.batch_num_nodes().to(raw_batched_graph.device)
    )
    physical_topology_graph.set_batch_num_edges(
        raw_batched_graph.batch_num_edges().to(raw_batched_graph.device)
    )
    if physical_topology_graph.num_nodes() != raw_batched_graph.num_nodes():
        raise RuntimeError("Pure physical topology graph changed the node count")
    if physical_topology_graph.num_edges() != raw_batched_graph.num_edges():
        raise RuntimeError(
            "Pure physical topology graph changed the physical edge count"
        )
    if (
        len(physical_topology_graph.ndata) != 0
        or len(physical_topology_graph.edata) != 0
    ):
        raise RuntimeError(
            "Pure physical topology graph unexpectedly contains feature data"
        )
    try:
        setattr(
            physical_topology_graph,
            BATCH_TOPOLOGY_CACHE_ATTR,
            batch_topology_cache,
        )
    except Exception as exc:
        raise TypeError(
            "DGLGraph does not support the batch topology cache attribute."
        ) from exc

    return BRepPretrainModelInputBatch(
        part_ids=tuple(part_ids),
        physical_topology_graph=physical_topology_graph,
        model_input=model_input,
    )


def _read_small_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _read_nonempty_unique_ids(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Required partition file not found: {path}")
    values = tuple(
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    if not values or len(values) != len(set(values)):
        raise ValueError(
            f"{path}: split must be non-empty and contain unique IDs"
        )
    return values


def _tensor_nbytes(tensor):
    return int(tensor.numel() * tensor.element_size())


def _cache_tensor_nbytes(value):
    if torch.is_tensor(value):
        return _tensor_nbytes(value)
    if isinstance(value, dict):
        return sum(_cache_tensor_nbytes(item) for item in value.values())
    if isinstance(value, (tuple, list, set)):
        return sum(_cache_tensor_nbytes(item) for item in value)
    return 0


def estimate_compact_graph_tensor_bytes(graph):
    total = sum(
        _tensor_nbytes(graph.ndata[key]) for key in graph.ndata.keys()
    )
    total += sum(
        _tensor_nbytes(graph.edata[key]) for key in graph.edata.keys()
    )
    id_element_size = torch.empty((), dtype=graph.idtype).element_size()
    total += int(2 * graph.num_edges() * id_element_size)
    cache = getattr(graph, SINGLE_TOPOLOGY_CACHE_ATTR, None)
    total += _cache_tensor_nbytes(cache)
    return total


def read_linux_process_memory_kib():
    path = Path("/proc/self/status")
    if not path.is_file():
        return None
    wanted = {"VmRSS", "VmHWM"}
    values = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            key, separator, remainder = line.partition(":")
            if separator and key in wanted:
                fields = remainder.strip().split()
                if fields:
                    values[key] = int(fields[0])
    except (OSError, ValueError):
        return None
    return values if wanted.issubset(values) else None


class BRepCompactGraphStore:
    

    def __init__(self, dataset_root, *, normalize=True):
        if normalize is not True:
            raise ValueError("formal physical-message input requires normalize=True")
        self.dataset_root = Path(dataset_root)
        self.graphs_path = self.dataset_root / "brep_graph" / "graphs.json"
        self.attr_stat_path = self.dataset_root / "brep_graph" / "attr_stat.json"
        self.uv_stat_path = self.dataset_root / "brep_graph" / "uv_stat.json"
        self.partition_dir = self.dataset_root / "MFInstseg_partition"
        self.partition_info_path = self.partition_dir / "partition_info.json"
        for path in (
            self.graphs_path,
            self.attr_stat_path,
            self.uv_stat_path,
            self.partition_info_path,
        ):
            if not path.is_file():
                raise FileNotFoundError(f"Required graph-store file not found: {path}")

        self.partition_info = _read_small_json(self.partition_info_path)
        if self.partition_info.get("split_protocol") != FORMAL_SPLIT_PROTOCOL:
            raise ValueError(
                f"{self.partition_info_path}: split_protocol must be "
                f"{FORMAL_SPLIT_PROTOCOL!r}"
            )
        if self.partition_info.get("test_split_enabled") is not True:
            raise ValueError(
                f"{self.partition_info_path}: test_split_enabled must be true"
            )
        self.partition_ids = {
            split: _read_nonempty_unique_ids(
                self.partition_dir / f"{split}.txt"
            )
            for split in ("train", "eval", "test")
        }
        for split, values in self.partition_ids.items():
            if self.partition_info.get(f"{split}_count") != len(values):
                raise ValueError(
                    f"{self.partition_info_path}: {split}_count mismatch"
                )
        for left, right in (
            ("train", "eval"),
            ("train", "test"),
            ("eval", "test"),
        ):
            if set(self.partition_ids[left]) & set(self.partition_ids[right]):
                raise ValueError(f"{left}/{right} partition files overlap")
        if self.partition_info.get("total_count") != sum(
            len(values) for values in self.partition_ids.values()
        ):
            raise ValueError(
                f"{self.partition_info_path}: total_count mismatch"
            )
        self.train_ids_sha256 = sha256_part_ids(self.partition_ids["train"])
        if (
            self.partition_info.get("train_ids_sha256")
            != self.train_ids_sha256
        ):
            raise ValueError(
                f"{self.partition_info_path}: train_ids_sha256 mismatch"
            )

        self.attr_stat = load_attr_statistics(
            self.attr_stat_path,
            self.train_ids_sha256,
        )
        self.uv_stat = load_uv_statistics(
            self.uv_stat_path,
            self.train_ids_sha256,
        )
        self.model_input_statistics = resolve_brep_model_input_statistics(
            self.attr_stat,
            self.uv_stat,
            device="cpu",
            dtype=torch.float32,
        )
        self._sample_by_id = {}
        self.stream_scan_count = 0
        self.estimated_tensor_bytes = 0
        self.graph_construction_count = 0

    @property
    def loaded_part_ids(self):
        return tuple(self._sample_by_id)

    @property
    def loaded_graph_count(self):
        return len(self._sample_by_id)

    def resolve_part_ids(
        self,
        *,
        split,
        filelist_override=None,
        max_samples=None,
    ):
        if split == "val":
            raise ValueError("val split is disabled; use split='eval'.")
        if split not in ("train", "eval", "test", "all"):
            raise ValueError(
                "split must be one of ('train','eval','test','all')"
            )
        override = validate_brep_pretrain_filelist_override(
            split,
            filelist_override,
            self.partition_ids["train"],
        )
        if split == "all":
            values = (
                self.partition_ids["train"]
                + self.partition_ids["eval"]
                + self.partition_ids["test"]
            )
        elif override is not None:
            values = tuple(override)
        else:
            values = self.partition_ids[split]
        if max_samples is not None:
            if (
                isinstance(max_samples, bool)
                or not isinstance(max_samples, int)
                or max_samples < 0
            ):
                raise ValueError("max_samples must be a non-negative integer or None")
            values = values[:max_samples]
        return tuple(values)

    def ensure_loaded(self, part_ids):
        requested = []
        seen = set()
        for part_id in part_ids:
            if not isinstance(part_id, str) or not part_id:
                raise TypeError("part_ids must contain non-empty strings")
            if part_id not in seen:
                requested.append(part_id)
                seen.add(part_id)
        missing = [
            part_id
            for part_id in requested
            if part_id not in self._sample_by_id
        ]
        if not missing:
            return
        missing_set = set(missing)
        self.stream_scan_count += 1
        for part_id, graph_data in iter_graph_records(self.graphs_path):
            if part_id not in missing_set:
                continue
            BRepPretrainDataset._validate_raw_graph(part_id, graph_data)
            loaded = load_one_graph(part_id, graph_data)
            graph = loaded["graph"]
            if graph.device.type != "cpu":
                raise ValueError("BRepCompactGraphStore only accepts CPU graphs")
            BRepPretrainDataset._validate_graph(part_id, graph)
            BRepPretrainDataset._ensure_unlabeled_graph(part_id, graph)
            topology_cache = build_single_graph_topology_cache(graph)
            setattr(graph, SINGLE_TOPOLOGY_CACHE_ATTR, topology_cache)
            sample = BRepPretrainModelInputSample(
                part_id=part_id,
                physical_graph=graph,
            )
            self._sample_by_id[part_id] = sample
            self.graph_construction_count += 1
            self.estimated_tensor_bytes += estimate_compact_graph_tensor_bytes(
                graph
            )
            missing_set.remove(part_id)
            del graph_data, loaded, graph, topology_cache, sample
            if not missing_set:
                break
        if missing_set:
            raise KeyError(
                "graphs.json is missing requested part IDs: "
                f"{sorted(missing_set)[:20]}"
            )

    def get_sample(self, part_id):
        if part_id not in self._sample_by_id:
            self.ensure_loaded((part_id,))
        return self._sample_by_id[part_id]

    def get_samples(self, part_ids):
        values = tuple(part_ids)
        self.ensure_loaded(values)
        return tuple(self._sample_by_id[part_id] for part_id in values)


class BRepPretrainDataset(Dataset):
    def __init__(
        self,
        dataset_root: str,
        split: str = "train",
        normalize: bool = True,
        max_samples: int = None,
        filelist_override=None,
        graph_store=None,
    ):
        super().__init__()
        self.dataset_root = Path(dataset_root)
        self.split = split
        self.normalize = normalize
        self.max_samples = max_samples
        self.filelist_override = filelist_override
        if normalize is not True:
            raise ValueError("formal physical-message input requires normalize=True")
        if graph_store is None:
            graph_store = BRepCompactGraphStore(
                self.dataset_root,
                normalize=True,
            )
        if not isinstance(graph_store, BRepCompactGraphStore):
            raise TypeError("graph_store must be a BRepCompactGraphStore")
        if graph_store.dataset_root.resolve() != self.dataset_root.resolve():
            raise ValueError("graph_store dataset_root does not match dataset_root")
        self.graph_store = graph_store
        self.graphs_path = graph_store.graphs_path
        self.attr_stat_path = graph_store.attr_stat_path
        self.uv_stat_path = graph_store.uv_stat_path
        self.partition_dir = graph_store.partition_dir
        self.partition_info_path = graph_store.partition_info_path
        self.partition_info = graph_store.partition_info
        self.partition_ids = graph_store.partition_ids
        self.train_ids_sha256 = graph_store.train_ids_sha256
        self.attr_stat = graph_store.attr_stat
        self.uv_stat = graph_store.uv_stat
        self.model_input_statistics = graph_store.model_input_statistics
        self.split_file = (
            None
            if split == "all" or filelist_override is not None
            else self.partition_dir / f"{split}.txt"
        )
        self.part_ids = graph_store.resolve_part_ids(
            split=split,
            filelist_override=filelist_override,
            max_samples=max_samples,
        )
        graph_store.ensure_loaded(self.part_ids)
        self.data = list(graph_store.get_samples(self.part_ids))
        self.num_graphs = len(self.data)
        print("BRepPretrainDataset:")
        print("  graphs_path: {}".format(self.graphs_path))
        print("  split: {}".format(self.split))
        print("  input_protocol: physical_message_v1")
        print("  loaded graph count: {}".format(self.num_graphs))
        print("  graph_store_loaded_before_dataloader: True")
        print(
            "  estimated_compact_tensor_bytes: {}".format(
                graph_store.estimated_tensor_bytes
            )
        )
        print("  stream_scan_count: {}".format(graph_store.stream_scan_count))

    @staticmethod
    def _parse_graph_item(item, idx):
        if isinstance(item, (list, tuple)) and len(item) == 2 and isinstance(item[1], dict):
            return str(item[0]), item[1]
        raise ValueError(
            f"graphs.json item {idx} has invalid format. Expected [part_id, graph_data], "
            f"got type={type(item)} head={str(item)[:200]}"
        )

    @staticmethod
    def _validate_raw_graph(part_id, graph_data):
        for key in REQUIRED_GRAPH_KEYS:
            if key not in graph_data:
                raise KeyError(f"Graph {part_id} missing required key '{key}'.")
        if not isinstance(graph_data["graph"], dict):
            raise ValueError(f"Graph {part_id} key 'graph' must be a dict.")
        if "num_nodes" not in graph_data["graph"]:
            raise KeyError(f"Graph {part_id} missing graph['num_nodes'].")
        if "edges" not in graph_data["graph"]:
            raise KeyError(f"Graph {part_id} missing graph['edges'].")

    @staticmethod
    def _validate_graph(part_id, graph):
        if "x" not in graph.ndata.keys():
            raise KeyError(f"Graph {part_id} missing graph.ndata['x'].")
        if "x" not in graph.edata.keys():
            raise KeyError(f"Graph {part_id} missing graph.edata['x'].")
        if "grid" not in graph.ndata.keys():
            raise KeyError(f"Graph {part_id} missing graph.ndata['grid'].")
        if "grid" not in graph.edata.keys():
            raise KeyError(f"Graph {part_id} missing graph.edata['grid'].")
        if "face_uv" not in graph.edata.keys():
            raise KeyError(f"Graph {part_id} missing graph.edata['face_uv'].")
        if "face_uv_valid" not in graph.edata.keys():
            raise KeyError(
                f"Graph {part_id} missing graph.edata['face_uv_valid']."
            )

        node_x = graph.ndata["x"]
        edge_x = graph.edata["x"]
        node_grid = graph.ndata["grid"]
        edge_grid = graph.edata["grid"]
        face_uv = graph.edata["face_uv"]
        face_uv_valid = graph.edata["face_uv_valid"]

        if node_x.dtype != torch.float32:
            raise TypeError(f"Graph {part_id} ndata['x'] dtype is {node_x.dtype}, expected torch.float32.")
        if edge_x.dtype != torch.float32:
            raise TypeError(f"Graph {part_id} edata['x'] dtype is {edge_x.dtype}, expected torch.float32.")
        if node_grid.dtype != torch.float32:
            raise TypeError(
                f"Graph {part_id} ndata['grid'] dtype is {node_grid.dtype}, expected torch.float32."
            )
        if edge_grid.dtype != torch.float32:
            raise TypeError(
                f"Graph {part_id} edata['grid'] dtype is {edge_grid.dtype}, expected torch.float32."
            )

        if node_x.dim() != 2 or node_x.shape[-1] != 16:
            raise ValueError(f"Graph {part_id} ndata['x'] shape {tuple(node_x.shape)}, expected [N, 16].")
        if edge_x.dim() != 2 or edge_x.shape[-1] != 16:
            raise ValueError(f"Graph {part_id} edata['x'] shape {tuple(edge_x.shape)}, expected [E, 16].")
        if node_grid.dim() != 4 or tuple(node_grid.shape[1:]) != (11, 5, 5):
            raise ValueError(
                f"Graph {part_id} ndata['grid'] shape {tuple(node_grid.shape)}, expected [N, 11, 5, 5]."
            )
        if edge_grid.dim() != 3 or tuple(edge_grid.shape[1:]) != (16, 5):
            raise ValueError(
                f"Graph {part_id} edata['grid'] shape {tuple(edge_grid.shape)}, expected [E, 16, 5]."
            )
        if face_uv.dtype != torch.float32 or face_uv.shape != (
            graph.num_edges(), 2, 5, 2
        ):
            raise ValueError(
                f"Graph {part_id} edata['face_uv'] must be float32 [E,2,5,2], "
                f"got dtype={face_uv.dtype}, shape={tuple(face_uv.shape)}"
            )
        if face_uv_valid.dtype != torch.bool or face_uv_valid.shape != (
            graph.num_edges(), 2, 5
        ):
            raise ValueError(
                f"Graph {part_id} edata['face_uv_valid'] must be bool [E,2,5], "
                f"got dtype={face_uv_valid.dtype}, shape={tuple(face_uv_valid.shape)}"
            )
        if node_x.shape[0] != graph.num_nodes():
            raise ValueError(
                f"Graph {part_id} has {node_x.shape[0]} face attrs but {graph.num_nodes()} graph nodes."
            )
        if node_grid.shape[0] != graph.num_nodes():
            raise ValueError(
                f"Graph {part_id} has {node_grid.shape[0]} face grids but {graph.num_nodes()} graph nodes."
            )
        if edge_x.shape[0] != graph.num_edges():
            raise ValueError(
                f"Graph {part_id} has {edge_x.shape[0]} edge attrs but {graph.num_edges()} graph edges."
            )
        if edge_grid.shape[0] != graph.num_edges():
            raise ValueError(
                f"Graph {part_id} has {edge_grid.shape[0]} edge grids but {graph.num_edges()} graph edges."
            )

    @staticmethod
    def _ensure_unlabeled_graph(part_id, graph):
        found = [
            key for key in SUPERVISED_GRAPH_KEYS if key in graph.ndata.keys()
        ]
        if found:
            raise ValueError(f"Graph {part_id} unexpectedly has supervised node keys: {found}")
        found = [
            key for key in SUPERVISED_GRAPH_KEYS if key in graph.edata.keys()
        ]
        if found:
            raise ValueError(f"Graph {part_id} unexpectedly has supervised edge keys: {found}")

    def __len__(self):
        return self.num_graphs

    def __getitem__(self, idx):
        return self.data[idx]

    def __repr__(self):
        return "BRepPretrainDataset(num_graphs={}, root={})".format(
            self.num_graphs,
            self.dataset_root,
        )

    def get_dataloader(
        self,
        batch_size: int,
        shuffle: bool = True,
        drop_last: bool = False,
        num_workers: int = 0,
        pin_memory: bool = True,
    ):
        if self.model_input_statistics is None:
            raise RuntimeError(
                "physical-message model input statistics are unavailable"
            )
        collate_fn = partial(
            collate_brep_pretrain_model_input,
            statistics=self.model_input_statistics,
        )

        loader_kwargs = dict(
            batch_size=batch_size,
            shuffle=shuffle,
            drop_last=drop_last,
            num_workers=num_workers,
            pin_memory=pin_memory,
            collate_fn=collate_fn,
        )

        if num_workers > 0:
            loader_kwargs["persistent_workers"] = True
            loader_kwargs["prefetch_factor"] = 2

        return DataLoader(self, **loader_kwargs)
