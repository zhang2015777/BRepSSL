

import json
from pathlib import Path

import numpy as np
import torch

from configs.main_experiment_config import FORMAL_SPLIT_PROTOCOL
from dataset.mfinstseg_label_protocol import (
    RAW_TO_TINY_CLASS,
    TINY_CLASS_NAMES,
    TINY_RAW_CLASS_IDS,
    VALID_PROCESS_TYPES,
    validate_mfinstseg_label_payload,
)


NUM_TINY_CLASSES = len(TINY_CLASS_NAMES)
TINY_REMAP = dict(RAW_TO_TINY_CLASS)
TINY_INVERSE_REMAP = {
    tiny_class: raw_class
    for raw_class, tiny_class in TINY_REMAP.items()
}


def remap_raw_class(raw_class):
    try:
        return TINY_REMAP[int(raw_class)]
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(
            f"raw class must be one of {TINY_RAW_CLASS_IDS}, got {raw_class!r}"
        ) from exc


def validate_quality_stat_arrays(mean, std, source):
    mean = np.asarray(mean, dtype=np.float32)
    std = np.asarray(std, dtype=np.float32)
    if mean.shape != (2,) or std.shape != (2,):
        raise ValueError(f"{source}: quality mean/std must have shape [2]")
    if not np.all(np.isfinite(mean)) or not np.all(np.isfinite(std)):
        raise ValueError(f"{source}: quality mean/std contain NaN or Inf")
    if np.any(std <= 0):
        raise ValueError(f"{source}: quality std must be positive")
    return mean, std


def validate_quality_stat_metadata(stat, source, train_ids_sha256):
    expected = {
        "stat_scope": "train_valid_machining_faces_only",
        "include_stock": False,
        "source_split": "train",
        "split_protocol": FORMAL_SPLIT_PROTOCOL,
        "train_ids_sha256": train_ids_sha256,
    }
    for key, value in expected.items():
        if stat.get(key) != value:
            raise ValueError(
                f"{source}: {key} must be {value!r}, got {stat.get(key)!r}"
            )
    if int(stat.get("num_values", 0)) <= 0:
        raise ValueError(f"{source}: num_values must be positive")


def load_quality_statistics(quality_stat_path, train_ids_sha256):
    path = Path(quality_stat_path)
    if not path.is_file():
        raise FileNotFoundError(f"quality statistics not found: {path}")
    with path.open("r", encoding="utf-8") as stream:
        stat = json.load(stream)
    validate_quality_stat_metadata(stat, str(path), train_ids_sha256)
    if "mean_quality" not in stat or "std_quality" not in stat:
        raise KeyError(f"{path}: missing mean_quality/std_quality")
    return validate_quality_stat_arrays(
        stat["mean_quality"],
        stat["std_quality"],
        str(path),
    )


def parse_supervised_labels(
    part_id,
    labels_data,
    *,
    num_nodes,
    quality_mean,
    quality_std,
):
    validated = validate_mfinstseg_label_payload(
        part_id,
        labels_data,
        num_nodes=num_nodes,
    )
    quality_mean, quality_std = validate_quality_stat_arrays(
        quality_mean,
        quality_std,
        "quality statistics",
    )
    quality = (
        validated["quality"].astype(np.float32) - quality_mean
    ) / quality_std
    if not np.all(np.isfinite(quality)):
        raise ValueError(f"part={part_id}: normalized quality is non-finite")
    return (
        torch.from_numpy(validated["tiny_seg"].copy()).to(torch.int64),
        torch.from_numpy(validated["inst"].copy()).to(torch.float32),
        torch.from_numpy(quality.copy()).to(torch.float32),
        torch.from_numpy(validated["process_type"].copy()).to(torch.int64),
    )
