

from dataclasses import dataclass
from functools import partial
import json
from pathlib import Path

import dgl
import torch
from torch.utils.data import DataLoader, Dataset

from dataloader.brep_pretrain import (
    BRepCompactGraphStore,
    BRepPretrainDataset,
    BRepPretrainModelInputBatch,
    BRepPretrainModelInputSample,
    collate_brep_pretrain_model_input,
    move_brep_pretrain_model_input_batch,
    pin_brep_pretrain_model_input_batch,
)
from dataloader.mfinstseg_protocol import (
    VALID_PROCESS_TYPES,
    load_quality_statistics,
    parse_supervised_labels,
)
from utils.brep_model_input_view import (
    BRepModelInputStatistics,
    BRepModelInputView,
)


@dataclass(frozen=True)
class BRepSupervisedModelInputSample:
    part_id: str
    geometry_sample: BRepPretrainModelInputSample
    seg_y: torch.Tensor
    inst_y: torch.Tensor
    quality: torch.Tensor
    process_y: torch.Tensor

    def __post_init__(self):
        if not isinstance(self.part_id, str) or not self.part_id.strip():
            raise ValueError("part_id must be a non-empty string")
        if not isinstance(
            self.geometry_sample,
            BRepPretrainModelInputSample,
        ):
            raise TypeError(
                "geometry_sample must be a BRepPretrainModelInputSample"
            )
        if self.geometry_sample.part_id != self.part_id:
            raise ValueError(
                "geometry_sample.part_id must equal the supervised part_id"
            )
        node_count = self.geometry_sample.physical_graph.num_nodes()
        _validate_supervised_tensors(
            self.part_id,
            node_count,
            self.seg_y,
            self.inst_y,
            self.quality,
            self.process_y,
        )


@dataclass(frozen=True)
class BRepSupervisedModelInputBatch:
    part_ids: tuple[str, ...]
    physical_topology_graph: dgl.DGLGraph
    model_input: BRepModelInputView
    seg_y: torch.Tensor
    inst_labels: torch.Tensor
    inst_masks: torch.Tensor
    quality: torch.Tensor
    process_y: torch.Tensor

    def pin_memory(self):
        return pin_brep_supervised_model_input_batch(self)


def pin_brep_supervised_model_input_batch(batch):
    
    if not isinstance(batch, BRepSupervisedModelInputBatch):
        raise TypeError("batch must be a BRepSupervisedModelInputBatch")
    geometry = pin_brep_pretrain_model_input_batch(
        BRepPretrainModelInputBatch(
            part_ids=batch.part_ids,
            physical_topology_graph=batch.physical_topology_graph,
            model_input=batch.model_input,
        )
    )

    def pin_tensor(value):
        if value.device.type != "cpu":
            raise ValueError("Only CPU label tensors can be pinned")
        return value if value.is_pinned() else value.pin_memory()

    return BRepSupervisedModelInputBatch(
        part_ids=tuple(batch.part_ids),
        physical_topology_graph=geometry.physical_topology_graph,
        model_input=geometry.model_input,
        seg_y=pin_tensor(batch.seg_y),
        inst_labels=pin_tensor(batch.inst_labels),
        inst_masks=pin_tensor(batch.inst_masks),
        quality=pin_tensor(batch.quality),
        process_y=pin_tensor(batch.process_y),
    )


def _validate_supervised_tensors(
    part_id,
    node_count,
    seg_y,
    inst_y,
    quality,
    process_y,
):
    expected = (
        ("seg_y", seg_y, torch.int64, (node_count,)),
        ("inst_y", inst_y, torch.float32, (node_count, node_count)),
        ("quality", quality, torch.float32, (node_count, 2)),
        ("process_y", process_y, torch.int64, (node_count,)),
    )
    for name, value, dtype, shape in expected:
        if not isinstance(value, torch.Tensor):
            raise TypeError(f"{part_id} {name} must be a torch.Tensor")
        if value.dtype != dtype:
            raise TypeError(
                f"{part_id} {name} must have dtype={dtype}, got {value.dtype}"
            )
        if tuple(value.shape) != shape:
            raise ValueError(
                f"{part_id} {name} must have shape {shape}, "
                f"got {tuple(value.shape)}"
            )
    for name, value in (("inst_y", inst_y), ("quality", quality)):
        if not torch.all(torch.isfinite(value)):
            raise ValueError(f"{part_id} {name} contains NaN or Inf")
    valid_process = torch.tensor(
        sorted(VALID_PROCESS_TYPES),
        dtype=process_y.dtype,
        device=process_y.device,
    )
    if process_y.numel() and not torch.all(
        torch.isin(process_y, valid_process)
    ):
        raise ValueError(
            f"{part_id} process_y contains values outside "
            f"{sorted(VALID_PROCESS_TYPES)}"
        )


def parse_mfinstseg_supervised_labels(
    part_id,
    labels_data,
    node_count,
    *,
    dataset_type,
    quality_mean,
    quality_std,
):
    if dataset_type != "tiny":
        raise ValueError("formal physical-message supervision requires tiny")
    return parse_supervised_labels(
        part_id,
        labels_data,
        num_nodes=node_count,
        quality_mean=quality_mean,
        quality_std=quality_std,
    )


def collate_mfinstseg_physical_message(batch, *, statistics):
    if not batch:
        raise ValueError("supervised physical-message batch must be non-empty")
    if not isinstance(statistics, BRepModelInputStatistics):
        raise TypeError("statistics must be a BRepModelInputStatistics")

    seen = set()
    geometry_samples = []
    for index, sample in enumerate(batch):
        if not isinstance(sample, BRepSupervisedModelInputSample):
            raise TypeError(
                "batch items must be BRepSupervisedModelInputSample, got "
                f"{type(sample)} at index {index}"
            )
        if sample.part_id in seen:
            raise ValueError(
                f"batch contains duplicate part_id {sample.part_id!r}"
            )
        seen.add(sample.part_id)
        node_count = sample.geometry_sample.physical_graph.num_nodes()
        _validate_supervised_tensors(
            sample.part_id,
            node_count,
            sample.seg_y,
            sample.inst_y,
            sample.quality,
            sample.process_y,
        )
        geometry_samples.append(sample.geometry_sample)

    geometry_batch = collate_brep_pretrain_model_input(
        geometry_samples,
        statistics=statistics,
    )
    seg_y = torch.cat([sample.seg_y for sample in batch], dim=0)
    quality = torch.cat([sample.quality for sample in batch], dim=0)
    process_y = torch.cat([sample.process_y for sample in batch], dim=0)
    max_nodes = max(sample.inst_y.shape[0] for sample in batch)
    inst_labels = torch.zeros(
        len(batch),
        max_nodes,
        max_nodes,
        dtype=torch.float32,
    )
    inst_masks = torch.zeros_like(inst_labels)
    for graph_index, sample in enumerate(batch):
        node_count = sample.inst_y.shape[0]
        inst_labels[graph_index, :node_count, :node_count] = sample.inst_y
        inst_masks[graph_index, :node_count, :node_count] = 1.0

    total_nodes = geometry_batch.model_input.physical_num_nodes
    if (
        seg_y.shape != (total_nodes,)
        or quality.shape != (total_nodes, 2)
        or process_y.shape != (total_nodes,)
        or geometry_batch.physical_topology_graph.num_nodes() != total_nodes
    ):
        raise ValueError("Supervised labels do not align with geometry nodes")
    expected_counts = tuple(sample.inst_y.shape[0] for sample in batch)
    actual_counts = tuple(
        int(value)
        for value in geometry_batch.model_input.physical_batch_num_nodes.tolist()
    )
    if actual_counts != expected_counts:
        raise ValueError(
            "Instance label sizes do not match physical batch node counts"
        )
    return BRepSupervisedModelInputBatch(
        part_ids=tuple(sample.part_id for sample in batch),
        physical_topology_graph=geometry_batch.physical_topology_graph,
        model_input=geometry_batch.model_input,
        seg_y=seg_y,
        inst_labels=inst_labels,
        inst_masks=inst_masks,
        quality=quality,
        process_y=process_y,
    )


def move_brep_supervised_model_input_batch(
    batch,
    device,
    *,
    non_blocking=False,
):
    if not isinstance(batch, BRepSupervisedModelInputBatch):
        raise TypeError("batch must be a BRepSupervisedModelInputBatch")
    geometry_batch = BRepPretrainModelInputBatch(
        part_ids=batch.part_ids,
        physical_topology_graph=batch.physical_topology_graph,
        model_input=batch.model_input,
    )
    moved_geometry = move_brep_pretrain_model_input_batch(
        geometry_batch,
        device,
        non_blocking=non_blocking,
    )

    def moved(value):
        return value.to(
            device=device,
            non_blocking=non_blocking,
            copy=True,
        )

    moved_batch = BRepSupervisedModelInputBatch(
        part_ids=tuple(batch.part_ids),
        physical_topology_graph=moved_geometry.physical_topology_graph,
        model_input=moved_geometry.model_input,
        seg_y=moved(batch.seg_y),
        inst_labels=moved(batch.inst_labels),
        inst_masks=moved(batch.inst_masks),
        quality=moved(batch.quality),
        process_y=moved(batch.process_y),
    )
    expected_device = torch.device(device)
    for value in (
        moved_batch.seg_y,
        moved_batch.inst_labels,
        moved_batch.inst_masks,
        moved_batch.quality,
        moved_batch.process_y,
    ):
        if value.device != expected_device:
            raise ValueError("Supervised batch tensor is on the wrong device")
    return moved_batch


class MFInstSegPhysicalMessageDataset(Dataset):
    

    def __init__(
        self,
        root_dir,
        split="train",
        dataset_type="tiny",
        quality_stat_path=None,
        filelist_override=None,
        max_samples=None,
        normalize=True,
        random_rotate=False,
        center_and_scale=False,
        graph_store=None,
    ):
        super().__init__()
        if normalize is not True:
            raise ValueError(
                "MFInstSegPhysicalMessageDataset requires normalize=True"
            )
        if random_rotate:
            raise ValueError(
                "physical_message_v1 does not support random rotation"
            )
        if center_and_scale:
            raise ValueError(
                "Formal B-Rep schema is already scaled offline; "
                "center_and_scale must be False."
            )
        if quality_stat_path is None:
            raise ValueError(
                "An explicit train-only quality_stat_path is required"
            )
        if dataset_type != "tiny":
            raise ValueError("formal physical-message supervision requires tiny")
        if graph_store is not None and not isinstance(
            graph_store,
            BRepCompactGraphStore,
        ):
            raise TypeError("graph_store must be a BRepCompactGraphStore")

        self.root_dir = Path(root_dir)
        self.dataset_type = dataset_type
        self.geometry_dataset = BRepPretrainDataset(
            dataset_root=self.root_dir,
            split=split,
            normalize=True,
            max_samples=max_samples,
            filelist_override=filelist_override,
            graph_store=graph_store,
        )
        self.graph_store = self.geometry_dataset.graph_store
        self.quality_stat_path = Path(quality_stat_path)
        self.quality_mean, self.quality_std = load_quality_statistics(
            self.quality_stat_path,
            self.geometry_dataset.train_ids_sha256,
        )
        self.data = []
        for geometry_sample in self.geometry_dataset.data:
            if geometry_sample is not self.graph_store.get_sample(
                geometry_sample.part_id
            ):
                raise RuntimeError(
                    "Supervised geometry must directly reference the shared store"
                )
            part_id = geometry_sample.part_id
            label_path = self.root_dir / "labels" / f"{part_id}.json"
            if not label_path.is_file():
                raise FileNotFoundError(
                    f"Label JSON not found for {part_id}: {label_path}"
                )
            with label_path.open("r", encoding="utf-8") as read_file:
                labels_data = json.load(read_file)
            labels = parse_mfinstseg_supervised_labels(
                part_id,
                labels_data,
                geometry_sample.physical_graph.num_nodes(),
                dataset_type=self.dataset_type,
                quality_mean=self.quality_mean,
                quality_std=self.quality_std,
            )
            self.data.append(
                BRepSupervisedModelInputSample(
                    part_id=part_id,
                    geometry_sample=geometry_sample,
                    seg_y=labels[0],
                    inst_y=labels[1],
                    quality=labels[2],
                    process_y=labels[3],
                )
            )

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]

    def get_dataloader(
        self,
        batch_size,
        shuffle=True,
        sampler=None,
        num_workers=0,
        drop_last=False,
        pin_memory=True,
    ):
        if shuffle and sampler is not None:
            raise ValueError("shuffle=True is incompatible with sampler")
        statistics = self.geometry_dataset.model_input_statistics
        if statistics is None:
            raise RuntimeError("Geometry model input statistics are unavailable")
        kwargs = {
            "batch_size": batch_size,
            "shuffle": shuffle,
            "sampler": sampler,
            "num_workers": num_workers,
            "drop_last": drop_last,
            "pin_memory": pin_memory,
            "collate_fn": partial(
                collate_mfinstseg_physical_message,
                statistics=statistics,
            ),
        }
        if num_workers > 0:
            kwargs["persistent_workers"] = True
            kwargs["prefetch_factor"] = 2
        return DataLoader(self, **kwargs)
