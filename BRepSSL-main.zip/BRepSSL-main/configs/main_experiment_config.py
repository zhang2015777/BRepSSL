

import os
from pathlib import Path, PureWindowsPath


FORMAL_PROJECT_ROOT = Path(__file__).resolve().parents[1]


def resolve_dataset_root():
    configured = os.environ.get("BREPSSL_DATA_ROOT", "../data3").strip()
    if not configured:
        raise ValueError(
            "BREPSSL_DATA_ROOT must be a non-empty path relative to the project root."
        )
    path = Path(configured).expanduser()
    if path.is_absolute() or PureWindowsPath(configured).anchor:
        raise ValueError(
            "BREPSSL_DATA_ROOT must be relative to the project root."
        )
    return (FORMAL_PROJECT_ROOT / path).resolve()


FORMAL_DATASET_ROOT = resolve_dataset_root()
FORMAL_STEP_ROOT = FORMAL_DATASET_ROOT / "steps"
FORMAL_LABEL_ROOT = FORMAL_DATASET_ROOT / "labels"
FORMAL_BREP_GRAPH_ROOT = FORMAL_DATASET_ROOT / "brep_graph"
FORMAL_PARTITION_ROOT = FORMAL_DATASET_ROOT / "MFInstseg_partition"
FORMAL_OUTPUT_ROOT = (
    FORMAL_PROJECT_ROOT / "outputs" / "data3_physical_message_5090"
)

FORMAL_TRAIN_PERCENTS = (0.1, 0.5, 1.0, 2.0, 5.0)
FORMAL_SPLIT_PROTOCOL = "train_eval_test_80_10_10_seed42"
FORMAL_INPUT_PROTOCOL = "physical_message_v1"
FORMAL_GRAPH_STORAGE_PROTOCOL = "compact_streamed_json_array_v1"
FORMAL_GRAPH_RUNTIME_PROTOCOL = "shared_on_demand_dgl_store_v1"
FORMAL_DEVICE = "cuda:0"
FORMAL_SEED = 42

EXTRACTION_WORKERS = 8

DETERMINISM_AUDIT_TARGET_COUNT = 32
DETERMINISM_AUDIT_IN_PROCESS_REPEATS = 2
DETERMINISM_AUDIT_FRESH_PROCESS_REPEATS = 2
DETERMINISM_AUDIT_RTOL = 1e-6
DETERMINISM_AUDIT_ATOL = 1e-7

PRETRAIN_EPOCHS = 400
PRETRAIN_BATCH_SIZE = 256
PRETRAIN_NUM_WORKERS = 4
PRETRAIN_EVAL_EVERY = 5
PRETRAIN_SAVE_LAST_EVERY = 10
PRETRAIN_MASK_RATIO = 0.6

FINETUNE_EPOCHS = 400
FINETUNE_BATCH_SIZE = 256
FINETUNE_NUM_WORKERS = 4
FINETUNE_EVAL_EVERY = 5
FINETUNE_SAVE_LAST_EVERY = 10
FREEZE_BACKBONE_EPOCHS = 10

AMP_ENABLED = True


PRETRAIN_MAIN_CONFIG = {
    "output_dir": str(FORMAL_OUTPUT_ROOT / "pretrain"),
    "run_name": "formal_pretrain",
    "graph_storage_protocol": FORMAL_GRAPH_STORAGE_PROTOCOL,
    "graph_runtime_protocol": FORMAL_GRAPH_RUNTIME_PROTOCOL,
    "epochs": PRETRAIN_EPOCHS,
    "batch_size": PRETRAIN_BATCH_SIZE,
    "lr": 1e-3,
    "weight_decay": 1e-4,
    "device": FORMAL_DEVICE,
    "num_workers": PRETRAIN_NUM_WORKERS,
    "pin_memory": True,
    "seed": FORMAL_SEED,
    "pretrain_train_split": "train",
    "pretrain_eval_split": "eval",
    "eval_every": PRETRAIN_EVAL_EVERY,
    "save_last_every": PRETRAIN_SAVE_LAST_EVERY,
    "normalize": True,
    "pretrain_method": (
        "physical_message_structured_mask_embedding_reconstruction_v1"
    ),
    "face_attr_dim": 16,
    "face_grid_channels": 11,
    "edge_attr_dim": 16,
    "edge_grid_channels": 16,
    "mask_ratio": PRETRAIN_MASK_RATIO,
    "mask_policy": "centered_graph_region_node_edge_mask",
    "mask_scope": "centered_region",
    "negative_edge_ratio": 1.0,
    "min_mask_nodes": 1,
    "min_mask_edges": 1,
    "node_loss_weight": 1.0,
    "edge_loss_weight": 1.0,
    "topology_loss_weight": 0.5,
    "decoder_drop": 0.3,
    "feat_smooth_l1_beta": 0.5,
    "learnable_loss_weighting": False,
    "eval_mask_seed": 424242,
    "amp": AMP_ENABLED,
}


FINETUNE_MAIN_CONFIG = {
    "output_dir": str(FORMAL_OUTPUT_ROOT / "finetune"),
    "pretrained_backbone": str(
        FORMAL_OUTPUT_ROOT / "pretrain" / "checkpoints" / "best_backbone.pth"
    ),
    "pretrained_strict": True,
    "quality_stat_path": str(FORMAL_BREP_GRAPH_ROOT / "quality_stat.json"),
    "input_protocol": FORMAL_INPUT_PROTOCOL,
    "graph_storage_protocol": FORMAL_GRAPH_STORAGE_PROTOCOL,
    "graph_runtime_protocol": FORMAL_GRAPH_RUNTIME_PROTOCOL,
    "backbone_architecture": "BRepPhysicalMessageBackbone",
    "backbone_checkpoint_format": "brep_physical_message_backbone_v1",
    "finetune_checkpoint_format": "brep_physical_message_finetune_v1",
    "split_protocol": FORMAL_SPLIT_PROTOCOL,
    "best_metric_name": "mean_eval_semantic_iou_and_instance_pair_iou",
    "device": FORMAL_DEVICE,
    "seed": FORMAL_SEED,
    "sample_seed": FORMAL_SEED,
    "num_workers": FINETUNE_NUM_WORKERS,
    "epochs": FINETUNE_EPOCHS,
    "batch_size": FINETUNE_BATCH_SIZE,
    "freeze_backbone_epochs": FREEZE_BACKBONE_EPOCHS,
    "backbone_lr": 1e-4,
    "head_lr": 1e-3,
    "weight_decay": 0.01,
    "head_hidden_dim": 256,
    "task_adapter_hidden_dim": 256,
    "task_adapter_depth": 2,
    "task_adapter_drop": 0.3,
    "task_adapter_init_scale": 0.1,
    "semantic_fusion_mode": "none",
    "semantic_fusion_direction": "none",
    "semantic_fusion_input": "none",
    "semantic_fusion_adaptation": "none",
    "semantic_fusion_output": (
        "independent_semantic_and_instance_task_features"
    ),
    "semantic_fusion_affects_instance_head": False,
    "semantic_fusion_affects_process_head": False,
    "quality_hidden_dim": 128,
    "quality_drop": 0.3,
    "process_head_depth": 3,
    "process_branch": "quality_only",
    "process_input": "normalized_[roughness,tolerance]",
    "process_backpropagates_to_backbone": False,
    "loss_weights": {
        "semantic": 1.0,
        "instance": 1.0,
        "process": 1.0,
    },
    "amp": AMP_ENABLED,
    "eval_every": FINETUNE_EVAL_EVERY,
    "save_last_every": FINETUNE_SAVE_LAST_EVERY,
    "train_split": "train",
    "eval_split": "eval",
    "test_split": "test",
}
